[
    {
        "date": "09/23/16",
        "opponent": "Furman Fall Classic ",
        "location": "Greenville, S.C.",
        "time": "All Day"
    },
    {
        "date": "10/05/16",
        "opponent": "ITA All-Americans",
        "location": "Pacific Palisades, California",
        "time": "All Day"
    },
    {
        "date": "10/07/16",
        "opponent": "June Stewart Invitational ",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "10/21/16",
        "opponent": "Ohio Valley Regionals ",
        "location": "Murfreesboro, Tenn.",
        "time": "All Day"
    },
    {
        "date": "10/28/16",
        "opponent": "Puerto Rico College Challenge ",
        "location": "Palmas del Mar, PR.",
        "time": "All Day"
    },
    {
        "date": "11/03/16",
        "opponent": "ITA National Indoor Intercollegiate Championships ",
        "location": "New York, N.Y.",
        "time": "All Day"
    },
    {
        "date": "01/20/17",
        "opponent": "Miami Invitational",
        "location": "Miami, Fla.",
        "time": "All Day"
    },
    {
        "date": "01/27/17",
        "opponent": "Kansas vs. Clemson",
        "location": "Nashville, Tenn.",
        "time": "10:00 a.m. CT"
    },
    {
        "date": " ",
        "opponent": " Virginia Tech",
        "location": "Nashville, Tenn.",
        "time": "W, 4-0"
    },
    {
        "date": "01/28/17",
        "opponent": "Clemson vs. Virginia Tech",
        "location": "Nashville, Tenn.",
        "time": "9:00 a.m. CT"
    },
    {
        "date": " ",
        "opponent": " Kansas",
        "location": "Nashville, Tenn.",
        "time": "W, 4-0"
    },
    {
        "date": "02/03/17",
        "opponent": " Northwestern",
        "location": "Nashville, Tenn.",
        "time": "W, 5-2"
    },
    {
        "date": "02/05/17",
        "opponent": " Ohio State",
        "location": "Nashville, Tenn.",
        "time": "L, 5-2"
    },
    {
        "date": "02/10/17",
        "opponent": " Texas Tech",
        "location": "New Haven, CT.",
        "time": "L, 4-2"
    },
    {
        "date": "02/11/17",
        "opponent": " Michigan",
        "location": "New Haven, CT.",
        "time": "L, 4-1"
    },
    {
        "date": "02/12/17",
        "opponent": " Duke",
        "location": "New Haven, CT.",
        "time": "W, 4-0"
    },
    {
        "date": "02/25/17",
        "opponent": " Saint Mary's",
        "location": "Moraga, Calif.",
        "time": "12:00 p.m. CT"
    },
    {
        "date": "02/26/17",
        "opponent": " Stanford",
        "location": "Palo Alto, Calif.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "03/03/17",
        "opponent": " Tennessee *",
        "location": "Knoxville, Tenn.",
        "time": "5:00 p.m. CT"
    },
    {
        "date": "03/05/17",
        "opponent": " Georgia *",
        "location": "Athens, Ga.",
        "time": "12:00 p.m. CT"
    },
    {
        "date": "03/10/17",
        "opponent": " Mississippi State *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/12/17",
        "opponent": " Ole Miss *",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "03/18/17",
        "opponent": " Kentucky *",
        "location": "Lexington, Ky.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/24/17",
        "opponent": " Auburn *",
        "location": "Auburn, Ala.",
        "time": "3:00 p.m. CT"
    },
    {
        "date": "03/26/17",
        "opponent": " Alabama *",
        "location": "Tuscaloosa, Ala.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "03/31/17",
        "opponent": " Missouri *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "04/02/17",
        "opponent": " Arkansas *",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "04/07/17",
        "opponent": " Texas A&M *",
        "location": "College Station, Texas",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "04/09/17",
        "opponent": " LSU *",
        "location": "Baton Rouge, La.",
        "time": "11:00 a.m. CT"
    },
    {
        "date": "04/14/17",
        "opponent": " South Carolina *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "04/16/17",
        "opponent": " Florida *",
        "location": "Nashville, Tenn.",
        "time": "11:00 a.m. CT"
    },
    {
        "date": "04/19/17",
        "opponent": "SEC Tournament",
        "location": "Nashville, Tenn.",
        "time": "ALL DAY"
    },
    {
        "date": "05/13/17",
        "opponent": "NCAA First and Second Rounds",
        "location": "TBA",
        "time": "TBA"
    },
    {
        "date": "05/19/17",
        "opponent": "NCAA Round of 16 - Final",
        "location": "Athens, Ga.",
        "time": "TBA"
    },
    {
        "date": "05/24/17",
        "opponent": "NCAA Individual Championship",
        "location": "Athens, Ga.",
        "time": "TBA"
    }
]