[
    {
        "date": "09/03/16",
        "opponent": "Belmont Opener",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "09/17/16",
        "opponent": "Commodore Classic",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "09/30/16",
        "opponent": "Notre Dame Invitational",
        "location": "South Bend, Ind.",
        "time": "All Day"
    },
    {
        "date": "10/14/16",
        "opponent": "Wisconsin Invitational",
        "location": "Madison, Wisc.",
        "time": "All Day"
    },
    {
        "date": "10/28/16",
        "opponent": "SEC Championships ",
        "location": "Fayetteville, Ark.",
        "time": "All Day"
    },
    {
        "date": "11/11/16",
        "opponent": "NCAA Regionals",
        "location": "Tallahassee, Fla.",
        "time": "All Day"
    },
    {
        "date": "11/19/16",
        "opponent": "NCAA Nationals",
        "location": "Terre Haute, Ind.",
        "time": "All Day"
    }
]