module.exports = {
	"rand" : { 
    "monday": "7:00am - 3:00pm",  
	"tuesday": "7:00am - 3:00pm and from 4:30pm - 7:30pm",
	"wednesday": "7:00am - 3:00pm and from 4:30pm - 7:30pm",
	"thursday":"7:00am - 3:00pm",
	"friday":"7:00am - 3:00pm",
	"saturday": "8:00am - 2:00pm",
	"sunday": "10:00am - 2:00pm"
    }
};