[
    {
        "date": "09/02/17",
        "opponent": " Middle Tennessee State",
        "location": "Murfreesboro, Tenn.",
        "time": "TBA"
    },
    {
        "date": "09/09/17",
        "opponent": " Alabama A&M",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    },
    {
        "date": "09/16/17",
        "opponent": " Kansas State",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    },
    {
        "date": "09/23/17",
        "opponent": " Alabama *",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    },
    {
        "date": "09/30/17",
        "opponent": " Florida *",
        "location": "Gainesville, Fla.",
        "time": "TBA"
    },
    {
        "date": "10/07/17",
        "opponent": " Georgia *",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    },
    {
        "date": "10/14/17",
        "opponent": " Ole Miss *",
        "location": "Oxford, Miss.",
        "time": "TBA"
    },
    {
        "date": "10/28/17",
        "opponent": " South Carolina *",
        "location": "Columbia, S.C.",
        "time": "TBA"
    },
    {
        "date": "11/04/17",
        "opponent": " Western Kentucky",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    },
    {
        "date": "11/11/17",
        "opponent": " Kentucky *",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    },
    {
        "date": "11/18/17",
        "opponent": " Missouri *",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    },
    {
        "date": "11/25/17",
        "opponent": " Tennessee *",
        "location": "Knoxville, Tenn.",
        "time": "TBA"
    }
]