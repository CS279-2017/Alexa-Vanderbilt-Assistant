[
    {
        "date": "08/09/16",
        "opponent": " SEMO ",
        "location": "Nashville, Tenn.",
        "time": "T, 0-0"
    },
    {
        "date": "08/13/16",
        "opponent": " Furman (Exhibition) ",
        "location": "Greenville, S.C.",
        "time": "L, 1-0"
    },
    {
        "date": "08/19/16",
        "opponent": " Miami (Oh)",
        "location": "Oxford, Ohio.",
        "time": "W, 2-1 (OT)"
    },
    {
        "date": "08/21/16",
        "opponent": " Lipscomb",
        "location": "Nashville, Tenn.",
        "time": "L, 2-0"
    },
    {
        "date": "08/25/16",
        "opponent": " Florida State",
        "location": "Nashville, Tenn.",
        "time": "L, 3-0"
    },
    {
        "date": "08/28/16",
        "opponent": " Jackson State",
        "location": "Nashville, Tenn.",
        "time": "W, 8-0"
    },
    {
        "date": "09/01/16",
        "opponent": " Murray State",
        "location": "Nashville, Tenn.",
        "time": "W, 4-0"
    },
    {
        "date": "09/04/16",
        "opponent": " San Francisco",
        "location": "Nashville, Tenn.",
        "time": "W, 2-1"
    },
    {
        "date": "09/09/16",
        "opponent": " Auburn *",
        "location": "Auburn, Ala.",
        "time": "L, 2-1"
    },
    {
        "date": "09/11/16",
        "opponent": " Northern Kentucky",
        "location": "Nashville, Tenn.",
        "time": "L, 1-0 (2OT)"
    },
    {
        "date": "09/18/16",
        "opponent": " Mississippi State *",
        "location": "Starkville, Miss.",
        "time": "W, 2-1 (2 OT)"
    },
    {
        "date": "09/22/16",
        "opponent": " Texas A&M *",
        "location": "Nashville, Tenn.",
        "time": "W, 2-0"
    },
    {
        "date": "09/25/16",
        "opponent": " LSU *",
        "location": "Nashville, Tenn.",
        "time": "W, 3-0"
    },
    {
        "date": "09/30/16",
        "opponent": " Tennessee *",
        "location": "Knoxville, Tenn.",
        "time": "W, 3-2 (2 OT)"
    },
    {
        "date": "10/06/16",
        "opponent": " Arkansas *",
        "location": "Fayetteville, Ark.",
        "time": "L, 4-0"
    },
    {
        "date": "10/09/16",
        "opponent": " Kentucky *",
        "location": "Nashville, Tenn.",
        "time": "T, 2-2"
    },
    {
        "date": "10/14/16",
        "opponent": " Missouri *",
        "location": "Columbia, Mo.",
        "time": "L, 2-1"
    },
    {
        "date": "10/20/16",
        "opponent": " South Carolina *",
        "location": "Nashville, Tenn.",
        "time": "L, 2-1 (OT)"
    },
    {
        "date": "10/23/16",
        "opponent": " Ole Miss *",
        "location": "Nashville, Tenn.",
        "time": "W, 4-1"
    },
    {
        "date": "10/27/16",
        "opponent": " Alabama *",
        "location": "Tuscaloosa, Ala.",
        "time": "L, 2-0"
    },
    {
        "date": "11/02/16",
        "opponent": " Arkansas",
        "location": "Orange Beach, Ala.",
        "time": "L, 1-0"
    },
    {
        "date": "03/19/17",
        "opponent": " Middle Tennessee State ",
        "location": "Murfreesboro, Tenn.",
        "time": "5:00 p.m. CT"
    },
    {
        "date": "03/25/17",
        "opponent": " Samford ",
        "location": "Birmingham, Ala.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "04/01/17",
        "opponent": " Louisville ",
        "location": "Murfreesboro, Tenn. - Richard Siegel Park",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "04/09/17",
        "opponent": " Ole Miss ",
        "location": "Murfreesboro, Tenn. - Richard Siegel Park",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "04/13/17",
        "opponent": " Lipscomb ",
        "location": "Nashville, Tenn.",
        "time": "7:30 p.m. CT"
    }
]