[
    {
        "date": "09/02/16",
        "opponent": "Carmel Cup ",
        "location": "Pebble Beach, Calif.",
        "time": "5th/8"
    },
    {
        "date": "09/03/16",
        "opponent": "Carmel Cup",
        "location": "Pebble Beach, Calif.",
        "time": "4th/8"
    },
    {
        "date": "09/04/16",
        "opponent": "Carmel Cup",
        "location": "Pebble Beach, Calif.",
        "time": "4th/8"
    },
    {
        "date": "10/02/16",
        "opponent": "Nike Collegiate Invitational",
        "location": "Fort Worth, Texas",
        "time": "2nd/15"
    },
    {
        "date": "10/03/16",
        "opponent": "Nike Collegiate Invitational",
        "location": "Fort Worth, Texas",
        "time": "1st/15"
    },
    {
        "date": "10/04/16",
        "opponent": "Nike Collegiate Invitational",
        "location": "Fort Worth, Texas",
        "time": "1st/15"
    },
    {
        "date": "10/16/16",
        "opponent": "Tavistock Collegiate Invitational",
        "location": "Windermere, Fla.",
        "time": "T-3rd/15"
    },
    {
        "date": "10/17/16",
        "opponent": "Tavistock Collegiate Invitational",
        "location": "Windermere, Fla.",
        "time": "2nd/15"
    },
    {
        "date": "10/18/16",
        "opponent": "Tavistock Collegiate Invitational",
        "location": "Windermere, Fla.",
        "time": "2nd/15"
    },
    {
        "date": "10/31/16",
        "opponent": "East Lake Cup",
        "location": "Atlanta, Ga.",
        "time": "1st/4"
    },
    {
        "date": "11/01/16",
        "opponent": "East Lake Cup",
        "location": "Atlanta, Ga.",
        "time": "L, 3-2"
    },
    {
        "date": "11/02/16",
        "opponent": "East Lake Cup",
        "location": "Atlanta, Ga.",
        "time": "L, 4-1"
    },
    {
        "date": "02/17/17",
        "opponent": "All-American Intercollegiate",
        "location": "Houston, Texas",
        "time": "T-5th/18"
    },
    {
        "date": "02/18/17",
        "opponent": "All-American Intercollegiate",
        "location": "Houston, Texas",
        "time": "2nd/18"
    },
    {
        "date": "02/19/17",
        "opponent": "All-American Intercollegiate",
        "location": "Houston, Texas",
        "time": "2nd/18"
    },
    {
        "date": "02/26/17",
        "opponent": "Querencia Cabo Intercollegiate",
        "location": "Los Cabos, Mexico",
        "time": "13th/15"
    },
    {
        "date": "02/27/17",
        "opponent": "Querencia Cabo Intercollegiate",
        "location": "Los Cabos, Mexico",
        "time": "All Day"
    },
    {
        "date": "02/28/17",
        "opponent": "Querencia Cabo Intercollegiate",
        "location": "Los Cabos, Mexico",
        "time": "All Day"
    },
    {
        "date": "03/17/17",
        "opponent": "Schenkel Invitational",
        "location": "Statesboro, Ga.",
        "time": "All Day"
    },
    {
        "date": "03/18/17",
        "opponent": "Schenkel Invitational",
        "location": "Statesboro, Ga.",
        "time": "All Day"
    },
    {
        "date": "03/19/17",
        "opponent": "Schenkel Invitational",
        "location": "Statesboro, Ga.",
        "time": "All Day"
    },
    {
        "date": "03/31/17",
        "opponent": "Mason Rudolph Championship",
        "location": "Franklin, Tenn.",
        "time": "All Day"
    },
    {
        "date": "04/01/17",
        "opponent": "Mason Rudolph Championship",
        "location": "Franklin, Tenn.",
        "time": "All Day"
    },
    {
        "date": "04/02/17",
        "opponent": "Mason Rudolph Championship",
        "location": "Franklin, Tenn.",
        "time": "All Day"
    },
    {
        "date": "04/21/17",
        "opponent": "SEC Championship",
        "location": "Sea Island, Ga.",
        "time": "All Day"
    },
    {
        "date": "04/22/17",
        "opponent": "SEC Championship",
        "location": "Sea Island, Ga.",
        "time": "All Day"
    },
    {
        "date": "04/23/17",
        "opponent": "SEC Championship",
        "location": "Sea Island, Ga.",
        "time": "All Day"
    },
    {
        "date": "04/24/17",
        "opponent": "SEC Championship",
        "location": "Sea Island, Ga.",
        "time": "All Day"
    },
    {
        "date": "05/15/17",
        "opponent": "NCAA Regionals",
        "location": "TBD",
        "time": "All Day"
    },
    {
        "date": "05/16/17",
        "opponent": "NCAA Regionals",
        "location": "TBD",
        "time": "All Day"
    },
    {
        "date": "05/17/17",
        "opponent": "NCAA Regionals",
        "location": "TBD",
        "time": "All Day"
    },
    {
        "date": "05/26/17",
        "opponent": "NCAA Championship",
        "location": "Sugar Grove, Ill.",
        "time": "All Day"
    },
    {
        "date": "05/27/17",
        "opponent": "NCAA Championship",
        "location": "Sugar Grove, Ill.",
        "time": "All Day"
    },
    {
        "date": "05/28/17",
        "opponent": "NCAA Championship",
        "location": "Sugar Grove, Ill.",
        "time": "All Day"
    },
    {
        "date": "05/29/17",
        "opponent": "NCAA Championship",
        "location": "Sugar Grove, Ill.",
        "time": "All Day"
    },
    {
        "date": "05/30/17",
        "opponent": "NCAA Championship",
        "location": "Sugar Grove, Ill.",
        "time": "All Day"
    },
    {
        "date": "05/31/17",
        "opponent": "NCAA Championship",
        "location": "Sugar Grove, Ill.",
        "time": "All Day"
    }
]