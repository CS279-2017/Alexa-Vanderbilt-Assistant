[
    {
        "date": "02/16/17",
        "opponent": " San Diego",
        "location": "San Diego, Calif.",
        "time": "L, 3-2"
    },
    {
        "date": "02/17/17",
        "opponent": " San Diego",
        "location": "San Diego, Calif.",
        "time": "W, 8-2"
    },
    {
        "date": "02/19/17",
        "opponent": " San Diego",
        "location": "San Diego, Calif.",
        "time": "W, 11-1"
    },
    {
        "date": "02/22/17",
        "opponent": " Evansville",
        "location": "Nashville, Tenn.",
        "time": "W, 7-4"
    },
    {
        "date": "02/24/17",
        "opponent": " UIC",
        "location": "Nashville, Tenn.",
        "time": "L, 5-3 (10)"
    },
    {
        "date": "02/25/17",
        "opponent": " UIC",
        "location": "Nashville, Tenn.",
        "time": "W, 6-2"
    },
    {
        "date": "02/26/17",
        "opponent": " UIC",
        "location": "Nashville, Tenn.",
        "time": "L, 5-2 (11)"
    },
    {
        "date": "02/28/17",
        "opponent": " Southeastern Louisiana",
        "location": "Nashville, Tenn.",
        "time": "W, 9-6"
    },
    {
        "date": "03/01/17",
        "opponent": " Southeastern Louisiana",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/03/17",
        "opponent": " Cal State Northridge",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/04/17",
        "opponent": " Cal State Northridge",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/05/17",
        "opponent": " Cal State Northridge",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "03/07/17",
        "opponent": " Central Arkansas",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/08/17",
        "opponent": " Central Arkansas",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/10/17",
        "opponent": " Saint Mary's",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/11/17",
        "opponent": " Saint Mary's",
        "location": "Nashville, Tenn.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "03/12/17",
        "opponent": " Saint Mary's",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "03/14/17",
        "opponent": " Western Kentucky",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "03/17/17",
        "opponent": " Ole Miss *",
        "location": "Oxford, Miss.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "03/18/17",
        "opponent": " Ole Miss *",
        "location": "Oxford, Miss.",
        "time": "1:30 p.m. CT"
    },
    {
        "date": "03/19/17",
        "opponent": " Ole Miss *",
        "location": "Oxford, Miss.",
        "time": "3:00 p.m. CT"
    },
    {
        "date": "03/21/17",
        "opponent": " Belmont",
        "location": "Nashville, Tenn. (First Tennessee Park)",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "03/24/17",
        "opponent": " Texas A&M *",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "03/25/17",
        "opponent": " Texas A&M *",
        "location": "Nashville, Tenn.",
        "time": "7:00 p.m. CT"
    },
    {
        "date": "03/26/17",
        "opponent": " Texas A&M *",
        "location": "Nashville, Tenn.",
        "time": "3:00 p.m. CT"
    },
    {
        "date": "03/28/17",
        "opponent": " Lipscomb",
        "location": "Nashville, Tenn. (First Tennessee Park)",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "03/31/17",
        "opponent": " Kentucky *",
        "location": "Lexington, Ky.",
        "time": "5:30 p.m. CT"
    },
    {
        "date": "04/01/17",
        "opponent": " Kentucky *",
        "location": "Lexington, Ky.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "04/02/17",
        "opponent": " Kentucky *",
        "location": "Lexington, Ky.",
        "time": "12:00 p.m. CT"
    },
    {
        "date": "04/04/17",
        "opponent": " Tennessee-Martin",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "04/06/17",
        "opponent": " South Carolina *",
        "location": "Columbia, S.C.",
        "time": "6:00 p.m. CT"
    },
    {
        "date": "04/07/17",
        "opponent": " South Carolina ",
        "location": "Columbia, S.C.",
        "time": "6:00 p.m. CT"
    },
    {
        "date": "04/08/17",
        "opponent": " South Carolina *",
        "location": "Columbia, S.C.",
        "time": "11:00 a.m. CT"
    },
    {
        "date": "04/11/17",
        "opponent": " Tennessee Tech",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "04/13/17",
        "opponent": " Florida *",
        "location": "Nashville, Tenn.",
        "time": "8:00 p.m. CT"
    },
    {
        "date": "04/14/17",
        "opponent": " Florida *",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "04/15/17",
        "opponent": " Florida *",
        "location": "Nashville, Tenn.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "04/18/17",
        "opponent": " Middle Tennessee State",
        "location": "Murfreesboro, Tenn.",
        "time": "6:00 p.m. CT"
    },
    {
        "date": "04/21/17",
        "opponent": " Georgia *",
        "location": "Athens, Ga.",
        "time": "6:00 p.m. CT"
    },
    {
        "date": "04/22/17",
        "opponent": " Georgia *",
        "location": "Athens, Ga.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "04/23/17",
        "opponent": " Georgia *",
        "location": "Athens, Ga.",
        "time": "12:00 p.m. CT"
    },
    {
        "date": "04/28/17",
        "opponent": " Tennessee *",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "04/29/17",
        "opponent": " Tennessee *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "04/30/17",
        "opponent": " Tennessee *",
        "location": "Nashville, Tenn.",
        "time": "3:00 p.m. CT"
    },
    {
        "date": "05/02/17",
        "opponent": " Austin Peay",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "05/05/17",
        "opponent": " Missouri *",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "05/06/17",
        "opponent": " Missouri *",
        "location": "Nashville, Tenn.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "05/07/17",
        "opponent": " Missouri *",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "05/09/17",
        "opponent": " Louisville",
        "location": "Louisville, Ky.",
        "time": "6:00 p.m. CT"
    },
    {
        "date": "05/12/17",
        "opponent": " Arkansas *",
        "location": "Fayetteville, Ark.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "05/13/17",
        "opponent": " Arkansas *",
        "location": "Fayetteville, Ark.",
        "time": "6:00 p.m. CT"
    },
    {
        "date": "05/14/17",
        "opponent": " Arkansas *",
        "location": "Fayetteville, Ark.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "05/16/17",
        "opponent": " Middle Tennessee State",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "05/18/17",
        "opponent": " Alabama *",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "05/19/17",
        "opponent": " Alabama *",
        "location": "Nashville, Tenn.",
        "time": "6:30 p.m. CT"
    },
    {
        "date": "05/20/17",
        "opponent": " Alabama *",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    }
]