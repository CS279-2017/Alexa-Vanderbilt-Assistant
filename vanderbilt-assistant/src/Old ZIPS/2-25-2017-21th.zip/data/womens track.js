[
    {
        "date": "07/01/16",
        "opponent": "U.S. Olympic Trials (July 1-10)",
        "location": "Eugene, Ore.",
        "time": "All Day"
    },
    {
        "date": "12/03/16",
        "opponent": "Vanderbilt Opener",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "01/13/17",
        "opponent": "Commodore Invitational",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "01/14/17",
        "opponent": "Commodore Invitational",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "01/20/17",
        "opponent": "Vanderbilt Invitational",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "01/21/17",
        "opponent": "Vanderbilt Invitational",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/03/17",
        "opponent": "Notre Dame Invitational",
        "location": "South Bend, Ind.",
        "time": "All Day"
    },
    {
        "date": "02/04/17",
        "opponent": "Notre Dame Invitational",
        "location": "South Bend, Ind.",
        "time": "All Day"
    },
    {
        "date": "02/10/17",
        "opponent": "Music City Challenge",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/11/17",
        "opponent": "Music City Challenge",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/24/17",
        "opponent": "SEC Indoor Championships",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/25/17",
        "opponent": "SEC Indoor Championships",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "03/10/17",
        "opponent": "NCAA Division I Indoor Championships",
        "location": "College Station, Tx.",
        "time": "All Day"
    },
    {
        "date": "03/11/17",
        "opponent": "NCAA Division I Indoor Championships",
        "location": "College Station, Tx.",
        "time": "All Day"
    },
    {
        "date": "03/17/17",
        "opponent": "Yellow Jacket Invitational",
        "location": "Atlanta, Ga.",
        "time": "All Day"
    },
    {
        "date": "03/31/17",
        "opponent": "Florida Relays",
        "location": "Gainesville, Fla.",
        "time": "All Day"
    },
    {
        "date": " ",
        "opponent": "Stanford Invitational",
        "location": "Palo Alto, Calif.",
        "time": "All Day"
    },
    {
        "date": "04/01/17",
        "opponent": "Florida Relays",
        "location": "Gainesville, Fla.",
        "time": "All Day"
    },
    {
        "date": " ",
        "opponent": "Stanford Invitational",
        "location": "Palo Alto, Calif.",
        "time": "All Day"
    },
    {
        "date": "04/06/17",
        "opponent": "Tennessee Relays",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "04/07/17",
        "opponent": "Tennessee Relays",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "04/08/17",
        "opponent": "Tennessee Relays",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "04/21/17",
        "opponent": "Virginia Invitational",
        "location": "Charlottesville, Va.",
        "time": "All Day"
    },
    {
        "date": "04/22/17",
        "opponent": "Virginia Invitational",
        "location": "Charlottesville, Va.",
        "time": "All Day"
    },
    {
        "date": "04/28/17",
        "opponent": "LSU Relays",
        "location": "Baton Rouge, La.",
        "time": "All Day"
    },
    {
        "date": "04/29/17",
        "opponent": "LSU Relays",
        "location": "Baton Rouge, La.",
        "time": "All Day"
    },
    {
        "date": "05/06/17",
        "opponent": "Tennessee Challenge",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "05/11/17",
        "opponent": "SEC Championships",
        "location": "Columbia, S.C.",
        "time": "All Day"
    },
    {
        "date": "05/12/17",
        "opponent": "SEC Championships",
        "location": "Columbia, S.C.",
        "time": "All Day"
    },
    {
        "date": "05/13/17",
        "opponent": "SEC Championships",
        "location": "Columbia, S.C.",
        "time": "All Day"
    },
    {
        "date": "05/25/17",
        "opponent": "NCAA Preliminaries",
        "location": "Lexington, Ky.",
        "time": "All Day"
    },
    {
        "date": "05/26/17",
        "opponent": "NCAA Preliminaries",
        "location": "Lexington, Ky.",
        "time": "All Day"
    },
    {
        "date": "05/27/17",
        "opponent": "NCAA Preliminaries",
        "location": "Lexington, Ky.",
        "time": "All Day"
    },
    {
        "date": "06/07/17",
        "opponent": "NCAA Finals",
        "location": "Eugene, Ore.",
        "time": "All Day"
    },
    {
        "date": "06/08/17",
        "opponent": "NCAA Finals",
        "location": "Eugene, Ore.",
        "time": "All Day"
    },
    {
        "date": "06/09/17",
        "opponent": "NCAA Finals",
        "location": "Eugene, Ore.",
        "time": "All Day"
    },
    {
        "date": "06/10/17",
        "opponent": "NCAA Finals",
        "location": "Eugene, Ore.",
        "time": "All Day"
    },
    {
        "date": "06/22/17",
        "opponent": "USATF Championships",
        "location": "Sacramento, Calif.",
        "time": "All Day"
    },
    {
        "date": "06/23/17",
        "opponent": "USATF Championships",
        "location": "Sacramento, Calif.",
        "time": "All Day"
    },
    {
        "date": "06/24/17",
        "opponent": "USATF Championships",
        "location": "Sacramento, Calif.",
        "time": "All Day"
    },
    {
        "date": "06/25/17",
        "opponent": "USATF Championships",
        "location": "Sacramento, Calif.",
        "time": "All Day"
    }
]