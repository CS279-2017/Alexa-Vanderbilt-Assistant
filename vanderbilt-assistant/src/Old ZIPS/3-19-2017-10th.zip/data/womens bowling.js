[
    {
        "date": "11/04/16",
        "opponent": "Track Kat Clash",
        "location": "Houston, Texas",
        "time": "All Day"
    },
    {
        "date": "11/05/16",
        "opponent": "Track Kat Clash",
        "location": "Houston, Texas",
        "time": "All Day"
    },
    {
        "date": "11/06/16",
        "opponent": "Track Kat Clash",
        "location": "Houston, Texas",
        "time": "All Day"
    },
    {
        "date": "11/11/16",
        "opponent": "Warhawk Classic",
        "location": "Kenosha, Wis.",
        "time": "All Day"
    },
    {
        "date": "11/12/16",
        "opponent": "Warhawk Classic",
        "location": "Kenosha, Wis.",
        "time": "All Day"
    },
    {
        "date": "11/13/16",
        "opponent": "Warhawk Classic",
        "location": "Kenosha, Wis.",
        "time": "All Day"
    },
    {
        "date": "12/02/16",
        "opponent": "Tulane Invitational",
        "location": "New Orleans, La.",
        "time": "All Day"
    },
    {
        "date": "12/03/16",
        "opponent": "Tulane Invitational",
        "location": "New Orleans, La.",
        "time": "All Day"
    },
    {
        "date": "12/04/16",
        "opponent": "Tulane Invitational",
        "location": "New Orleans, La.",
        "time": "All Day"
    },
    {
        "date": "01/13/17",
        "opponent": "Mid Winter Invitational",
        "location": "Jonesboro, Ark.",
        "time": "6th, 4,633"
    },
    {
        "date": "01/14/17",
        "opponent": "Mid Winter Invitational",
        "location": "Jonesboro, Ark.",
        "time": "5th, 9298"
    },
    {
        "date": "01/15/17",
        "location": "Jonesboro, Ark.",
        "time": "All Day"
    },
    {
        "date": "01/20/17",
        "location": "Reading, Pa.",
        "time": "All Day"
    },
    {
        "date": "01/21/17",
        "location": "Reading, Pa.",
        "time": "All Day"
    },
    {
        "date": "01/22/17",
        "location": "Reading, Pa.",
        "time": "All Day"
    },
    {
        "date": "01/27/17",
        "opponent": "Prairie View A&M Invitational",
        "location": "Arlington, Texas",
        "time": "All Day"
    },
    {
        "date": "01/28/17",
        "location": "Arlington, Texas",
        "time": "All Day"
    },
    {
        "date": "01/29/17",
        "location": "Arlington, Texas",
        "time": "All Day"
    },
    {
        "date": "02/10/17",
        "location": "Conroe, Texas",
        "time": "All Day"
    },
    {
        "date": "02/11/17",
        "location": "Conroe, Texas",
        "time": "All Day"
    },
    {
        "date": "02/12/17",
        "location": "Conroe, Texas",
        "time": "All Day"
    },
    {
        "date": "03/03/17",
        "opponent": "Hawk Flight",
        "location": "Egg Harbor, N.J.",
        "time": "All Day"
    },
    {
        "date": "03/04/17",
        "opponent": "Hawk Flight",
        "location": "Egg Harbor, N.J.",
        "time": "All Day"
    },
    {
        "date": "03/05/17",
        "opponent": "Hawk Flight",
        "location": "Egg Harbor, N.J.",
        "time": "All Day"
    },
    {
        "date": "03/17/17",
        "opponent": " Columbia 300 Music City Classic",
        "location": "Smyrna, Tenn.",
        "time": "All Day"
    },
    {
        "date": "03/18/17",
        "opponent": " Columbia 300 Music City Classic",
        "location": "Smyrna, Tenn.",
        "time": "All Day"
    },
    {
        "date": "03/19/17",
        "opponent": " Columbia 300 Music City Classic",
        "location": "Smyrna, Tenn.",
        "time": "All Day"
    },
    {
        "date": "03/25/17",
        "opponent": "Southland Conference ",
        "location": "Jonesboro, Ark.",
        "time": "All Day"
    },
    {
        "date": "03/26/17",
        "opponent": "Southland Conference ",
        "location": "Jonesboro, Ark.",
        "time": "All Day"
    },
    {
        "date": "04/13/17",
        "opponent": "NCAA Championships",
        "location": "Baton Rouge, La.",
        "time": "All Day"
    },
    {
        "date": "04/14/17",
        "opponent": "NCAA Championships",
        "location": "Baton Rouge, La.",
        "time": "All Day"
    },
    {
        "date": "04/15/17",
        "opponent": "NCAA Championships",
        "location": "Baton Rouge, La.",
        "time": "All Day"
    }
]