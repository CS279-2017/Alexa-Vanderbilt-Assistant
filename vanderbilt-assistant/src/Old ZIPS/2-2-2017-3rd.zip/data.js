module.exports = {
	"rand" : { 
	"0": "10:00am - 2:00pm",
    "1": "7:00am - 3:00pm",  
	"2": "7:00am - 3:00pm and from 4:30pm - 7:30pm",
	"3": "7:00am - 3:00pm and from 4:30pm - 7:30pm",
	"4":"7:00am - 3:00pm",
	"5":"7:00am - 3:00pm",
	"6": "8:00am - 2:00pm"
    }
};