[
    {
        "date": "09/06/16",
        "opponent": "Fall Kickoff",
        "location": "Duluth, Ga.",
        "time": "T-3rd/8"
    },
    {
        "date": "09/16/16",
        "opponent": "Mason Rudolph Championship",
        "location": "Franklin, Tenn.",
        "time": "T-8th/15"
    },
    {
        "date": "09/17/16",
        "opponent": "Mason Rudolph Championship",
        "location": "Franklin, Tenn.",
        "time": "8th/15"
    },
    {
        "date": "09/18/16",
        "opponent": "Mason Rudolph Championship",
        "location": "Franklin, Tenn.",
        "time": "7th/15"
    },
    {
        "date": "10/03/16",
        "opponent": "Windy City Collegiate Classic",
        "location": "Golf, Ill.",
        "time": "14th/14"
    },
    {
        "date": "10/04/16",
        "opponent": "Windy City Collegiate Classic",
        "location": "Golf, Ill.",
        "time": "13th/14"
    },
    {
        "date": "10/14/16",
        "opponent": "Ruth's Chris Tar Heel Invitational",
        "location": "Chapel Hill, N.C.",
        "time": "T-10th/18"
    },
    {
        "date": "10/15/16",
        "opponent": "Ruth's Chris Tar Heel Invitational",
        "location": "Chapel Hill, N.C.",
        "time": "12th/18"
    },
    {
        "date": "10/16/16",
        "opponent": "Ruth's Chris Tar Heel Invitational",
        "location": "Chapel Hill, N.C.",
        "time": "13th/18"
    },
    {
        "date": "10/23/16",
        "opponent": "Las Vegas Collegiate Showdown",
        "location": "Boulder City, Nevada",
        "time": "9th/19"
    },
    {
        "date": "10/24/16",
        "opponent": "Las Vegas Collegiate Showdown",
        "location": "Boulder City, Nevada",
        "time": "Cancelled"
    },
    {
        "date": "10/25/16",
        "opponent": "Las Vegas Collegiate Showdown",
        "location": "Boulder City, Nevada",
        "time": "6th/19"
    },
    {
        "date": "02/12/17",
        "opponent": "Lady Puerto Rico Classic",
        "location": "Rio Grande, Puerto Rico",
        "time": "T-13/15"
    },
    {
        "date": "02/13/17",
        "opponent": "Lady Puerto Rico Classic",
        "location": "Rio Grande, Puerto Rico",
        "time": "14th/15"
    },
    {
        "date": "02/14/17",
        "opponent": "Lady Puerto Rico Classic",
        "location": "Rio Grande, Puerto Rico",
        "time": "12th/15"
    },
    {
        "date": "03/03/17",
        "opponent": "Darius Rucker Intercollegiate",
        "location": "Hilton Head, S.C.",
        "time": "All Day"
    },
    {
        "date": "03/04/17",
        "opponent": "Darius Rucker Intercollegiate",
        "location": "Hilton Head, S.C.",
        "time": "All Day"
    },
    {
        "date": "03/05/17",
        "opponent": "Darius Rucker Intercollegiate",
        "location": "Hilton Head, S.C.",
        "time": "All Day"
    },
    {
        "date": "03/17/17",
        "opponent": "Clover Cup",
        "location": "Mesa, Ariz.",
        "time": "All Day"
    },
    {
        "date": "03/18/17",
        "opponent": "Clover Cup",
        "location": "Mesa, Ariz.",
        "time": "All Day"
    },
    {
        "date": "03/19/17",
        "opponent": "Clover Cup",
        "location": "Mesa, Ariz.",
        "time": "All Day"
    },
    {
        "date": "03/31/17",
        "opponent": "Clemson Invitational",
        "location": "Sunset, S.C.",
        "time": "All Day"
    },
    {
        "date": "04/01/17",
        "opponent": "Clemson Invitational",
        "location": "Sunset, S.C.",
        "time": "All Day"
    },
    {
        "date": "04/02/17",
        "opponent": "Clemson Invitational",
        "location": "Sunset, S.C.",
        "time": "All Day"
    },
    {
        "date": "04/21/17",
        "opponent": "SEC Championship",
        "location": "Birmingham, Ala.",
        "time": "All Day"
    },
    {
        "date": "04/22/17",
        "opponent": "SEC Championship",
        "location": "Birmingham, Ala.",
        "time": "All Day"
    },
    {
        "date": "04/23/17",
        "opponent": "SEC Championship",
        "location": "Birmingham, Ala.",
        "time": "All Day"
    },
    {
        "date": "05/08/17",
        "opponent": "NCAA Regionals",
        "location": "TBD",
        "time": "All Day"
    },
    {
        "date": "05/09/17",
        "opponent": "NCAA Regionals",
        "location": "TBD",
        "time": "All Day"
    },
    {
        "date": "05/10/17",
        "opponent": "NCAA Regionals",
        "location": "TBD",
        "time": "All Day"
    }
]