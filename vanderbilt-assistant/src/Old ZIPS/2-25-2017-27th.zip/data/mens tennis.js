[
    {
        "date": "09/23/16",
        "opponent": "Southern Intercollegiates ",
        "location": "Athens, Ga.",
        "time": "TBA"
    },
    {
        "date": "10/01/16",
        "opponent": "ITA All-Americans ",
        "location": "Tulsa, Okla.",
        "time": "TBA"
    },
    {
        "date": "10/07/16",
        "opponent": "GT Invitational ",
        "location": "Atlanta, Ga.",
        "time": "TBA"
    },
    {
        "date": "10/20/16",
        "opponent": "ITA Ohio Valley Regionals ",
        "location": "Knoxville, Tenn.",
        "time": "W, 0-0"
    },
    {
        "date": "10/28/16",
        "opponent": "Commodore Scramble ",
        "location": "Nashville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "11/04/16",
        "opponent": "SEC Fall Classic ",
        "location": "Tuscaloosa, Ala.",
        "time": "TBA"
    },
    {
        "date": "01/15/17",
        "opponent": " Northwestern",
        "location": "Nashville, Tenn.",
        "time": "L, 4-3"
    },
    {
        "date": " ",
        "opponent": " Belmont",
        "location": "Nashville, Tenn.",
        "time": "W, 4-0"
    },
    {
        "date": "01/20/17",
        "opponent": " Middle Tennessee State",
        "location": "Nashville, Tenn.",
        "time": "W, 4-0"
    },
    {
        "date": " ",
        "opponent": " Lipscomb",
        "location": "Nashville, Tenn.",
        "time": "W, 4-0"
    },
    {
        "date": "01/22/17",
        "opponent": " Penn",
        "location": "Nashville, Tenn.",
        "time": "W, 6-1"
    },
    {
        "date": " ",
        "opponent": " Georgia State",
        "location": "Nashville, Tenn.",
        "time": "W, 4-2"
    },
    {
        "date": "01/27/17",
        "opponent": " Penn State",
        "location": "Chapel Hill, N.C.",
        "time": "W, 4-1"
    },
    {
        "date": "01/28/17",
        "opponent": " North Carolina",
        "location": "Chapel Hill, N.C.",
        "time": "L, 4-1"
    },
    {
        "date": "02/03/17",
        "opponent": " Virginia",
        "location": "Nashville, Tenn.",
        "time": "L, 4-3"
    },
    {
        "date": "02/04/17",
        "opponent": " Western Michigan",
        "location": "Nashville, Tenn.",
        "time": "W, 5-2"
    },
    {
        "date": "02/05/17",
        "opponent": " Texas Tech",
        "location": "Nashville, Tenn.",
        "time": "W, 5-2"
    },
    {
        "date": "02/27/17",
        "opponent": " North Carolina",
        "location": "Nashville, Tenn.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "03/03/17",
        "opponent": " Georgia *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/05/17",
        "opponent": " Tennessee *",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "03/10/17",
        "opponent": " Texas A&M *",
        "location": "College Station, Texas",
        "time": "6:00 p.m. CT"
    },
    {
        "date": "03/12/17",
        "opponent": " LSU *",
        "location": "Baton Rouge, La.",
        "time": "11:30 a.m. CT"
    },
    {
        "date": "03/16/17",
        "opponent": " Mississippi State *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/18/17",
        "opponent": " Auburn *",
        "location": "Nashville, Tenn.",
        "time": "12:00 p.m. CT"
    },
    {
        "date": " ",
        "opponent": " Illinois State",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "03/24/17",
        "opponent": " South Carolina *",
        "location": "Columbia, S.C.",
        "time": "5:00 p.m. CT"
    },
    {
        "date": "03/26/17",
        "opponent": " Florida *",
        "location": "Gainesville, Fla.",
        "time": "12:00 p.m. CT"
    },
    {
        "date": "03/30/17",
        "opponent": " Kentucky *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "04/07/17",
        "opponent": " Alabama *",
        "location": "Nashville, Tenn.",
        "time": "4:00 p.m. CT"
    },
    {
        "date": "04/14/17",
        "opponent": " Ole Miss *",
        "location": "Oxford, Miss.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "04/16/17",
        "opponent": " Arkansas *",
        "location": "Fayetteville, Ark.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": "04/26/17",
        "opponent": "SEC Tournament",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "05/12/17",
        "opponent": "NCAA First and Second Rounds",
        "location": "TBA",
        "time": "TBA"
    },
    {
        "date": "05/18/17",
        "opponent": "NCAA Round of 16 - Final",
        "location": "Athens, Ga.",
        "time": "TBA"
    },
    {
        "date": "05/24/17",
        "opponent": "NCAA Individual Championship",
        "location": "Athens, Ga.",
        "time": "TBA"
    }
]