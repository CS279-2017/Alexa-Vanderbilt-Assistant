[
    {
        "date": "11/11/16",
        "opponent": " Marquette",
        "location": "Annapolis, Md.",
        "time": "L, 95-71"
    },
    {
        "date": "11/15/16",
        "opponent": " Belmont",
        "location": "Nashville, Tenn.",
        "time": "W, 80-66"
    },
    {
        "date": "11/18/16",
        "opponent": " Norfolk State",
        "location": "Nashville, Tenn.",
        "time": "W, 75-52"
    },
    {
        "date": "11/21/16",
        "opponent": " Bucknell",
        "location": "Nashville, Tenn.",
        "time": "L, 75-72"
    },
    {
        "date": "11/24/16",
        "opponent": " Butler",
        "location": "Las Vegas, Nev.",
        "time": "L, 76-66"
    },
    {
        "date": "11/25/16",
        "opponent": " Santa Clara",
        "location": "Las Vegas, Nev.",
        "time": "W, 76-66"
    },
    {
        "date": "11/29/16",
        "opponent": " Tennessee State",
        "location": "Nashville, Tenn.",
        "time": "W, 83-59"
    },
    {
        "date": "12/03/16",
        "opponent": " Minnesota",
        "location": "Sioux Falls, S.D.",
        "time": "L, 56-52"
    },
    {
        "date": "12/06/16",
        "opponent": " High Point",
        "location": "Nashville, Tenn.",
        "time": "W, 90-63"
    },
    {
        "date": "12/08/16",
        "opponent": " Middle Tennessee State",
        "location": "Murfreesboro, Tenn.",
        "time": "L, 71-48"
    },
    {
        "date": "12/17/16",
        "opponent": " Chattanooga",
        "location": "Nashville, Tenn.",
        "time": "W, 76-74"
    },
    {
        "date": "12/21/16",
        "opponent": " Dayton",
        "location": "Dayton, Ohio",
        "time": "L, 68-63"
    },
    {
        "date": "12/29/16",
        "opponent": " LSU ",
        "location": "Baton Rouge, La.",
        "time": "W, 96-89"
    },
    {
        "date": "01/04/17",
        "opponent": " Auburn ",
        "location": "Nashville, Tenn.",
        "time": "W, 80-61"
    },
    {
        "date": "01/07/17",
        "opponent": " Alabama ",
        "location": "Tuscaloosa, Ala.",
        "time": "L, 59-56"
    },
    {
        "date": "01/10/17",
        "opponent": " Kentucky ",
        "location": "Nashville, Tenn.",
        "time": "L, 87-81"
    },
    {
        "date": "01/14/17",
        "opponent": " Tennessee ",
        "location": "Nashville, Tenn.",
        "time": "L, 87-75"
    },
    {
        "date": "01/17/17",
        "opponent": " Georgia ",
        "location": "Athens, Ga.",
        "time": "L, 76-68"
    },
    {
        "date": "01/21/17",
        "opponent": " Florida ",
        "location": "Gainesville, Fla.",
        "time": "W, 68-66"
    },
    {
        "date": "01/24/17",
        "opponent": " Arkansas ",
        "location": "Nashville, Tenn.",
        "time": "L, 71-70"
    },
    {
        "date": "01/28/17",
        "opponent": " Iowa State",
        "location": "Nashville, Tenn.",
        "time": "W, 84-78"
    },
    {
        "date": "01/31/17",
        "opponent": " Texas A&M ",
        "location": "College Station, Texas",
        "time": "W, 68-54"
    },
    {
        "date": "02/04/17",
        "opponent": " Ole Miss ",
        "location": "Nashville, Tenn.",
        "time": "L, 81-74"
    },
    {
        "date": "02/07/17",
        "opponent": " Arkansas ",
        "location": "Fayetteville, Ark.",
        "time": "W, 72-59"
    },
    {
        "date": "02/11/17",
        "opponent": " Missouri ",
        "location": "Columbia, Mo.",
        "time": "L, 72-52"
    },
    {
        "date": "02/16/17",
        "opponent": " Texas A&M ",
        "location": "Nashville, Tenn.",
        "time": "W, 72-67"
    },
    {
        "date": "02/18/17",
        "opponent": " South Carolina ",
        "location": "Nashville, Tenn.",
        "time": "W, 71-62"
    },
    {
        "date": "02/22/17",
        "opponent": " Tennessee ",
        "location": "Knoxville, Tenn.",
        "time": "W, 67-56"
    },
    {
        "date": "02/25/17",
        "opponent": " Mississippi State ",
        "location": "Nashville, Tenn.",
        "time": "3:00 p.m. CT"
    },
    {
        "date": "02/28/17",
        "opponent": " Kentucky ",
        "location": "Lexington, Ky.",
        "time": "8:00 p.m. CT"
    },
    {
        "date": "03/04/17",
        "opponent": " Florida ",
        "location": "Nashville, Tenn.",
        "time": "1:00 p.m. CT"
    },
    {
        "date": " ",
        "opponent": "SEC Tournament (March 8-12)",
        "location": "Nashville, Tenn.",
        "time": "TBA"
    }
]