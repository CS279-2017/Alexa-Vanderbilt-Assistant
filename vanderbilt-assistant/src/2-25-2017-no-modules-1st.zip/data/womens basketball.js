[
    {
        "date": "10/30/16",
        "opponent": " Bellarmine (exhibition) ",
        "location": "Nashville, Tenn.",
        "time": "W, 97-63"
    },
    {
        "date": "11/06/16",
        "opponent": " Union (exhibition) ",
        "location": "Nashville, Tenn.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "11/11/16",
        "opponent": " Kennesaw State",
        "location": "Nashville, Tenn.",
        "time": "W, 86-54"
    },
    {
        "date": "11/13/16",
        "opponent": " Indiana",
        "location": "Bloomington, Ind.",
        "time": "L, 94-61"
    },
    {
        "date": "11/16/16",
        "opponent": " Drexel",
        "location": "Nashville, Tenn.",
        "time": "W, 73-63"
    },
    {
        "date": "11/20/16",
        "opponent": " Duke",
        "location": "Nashville, Tenn.",
        "time": "W, 77-73"
    },
    {
        "date": "11/22/16",
        "opponent": " Robert Morris",
        "location": "Nashville, Tenn.",
        "time": "W, 75-59"
    },
    {
        "date": "11/27/16",
        "opponent": " UT Martin",
        "location": "Martin, Tenn.",
        "time": "W, 79-77"
    },
    {
        "date": "12/02/16",
        "opponent": " Air Force",
        "location": "Colorado Springs, Colo.",
        "time": "W, 75-49"
    },
    {
        "date": "12/03/16",
        "opponent": " SIUE",
        "location": "Colorado Springs, Colo.",
        "time": "W, 73-63"
    },
    {
        "date": "12/05/16",
        "opponent": " Tulane",
        "location": "Nashville, Tenn.",
        "time": "W, 74-63"
    },
    {
        "date": "12/08/16",
        "opponent": " ETSU",
        "location": "Johnson City, Tenn.",
        "time": "W, 80-72"
    },
    {
        "date": "12/18/16",
        "opponent": " Tennessee Tech",
        "location": "Nashville, Tenn.",
        "time": "W, 89-57"
    },
    {
        "date": "12/21/16",
        "opponent": " Louisville",
        "location": "Nashville, Tenn.",
        "time": "L, 78-66"
    },
    {
        "date": "12/28/16",
        "opponent": " Memphis",
        "location": "Memphis, Tenn.",
        "time": "L, 75-59"
    },
    {
        "date": "01/02/17",
        "opponent": " Texas A&M ",
        "location": "College Station, Texas",
        "time": "L, 77-72"
    },
    {
        "date": "01/05/17",
        "opponent": " Tennessee ",
        "location": "Nashville, Tenn.",
        "time": "L, 70-57"
    },
    {
        "date": "01/08/17",
        "opponent": " Georgia ",
        "location": "Athens, Ga.",
        "time": "L, 70-68"
    },
    {
        "date": "01/12/17",
        "opponent": " Auburn ",
        "location": "Nashville, Tenn.",
        "time": "L, 64-59"
    },
    {
        "date": "01/15/17",
        "opponent": " Missouri ",
        "location": "Nashville, Tenn.",
        "time": "L, 74-68"
    },
    {
        "date": "01/19/17",
        "opponent": " Arkansas ",
        "location": "Fayetteville, Ark.",
        "time": "L, 59-56"
    },
    {
        "date": "01/22/17",
        "opponent": " Tennessee ",
        "location": "Knoxville, Tenn.",
        "time": "L, 91-63"
    },
    {
        "date": "01/26/17",
        "opponent": " Alabama ",
        "location": "Nashville, Tenn.",
        "time": "W, 87-80"
    },
    {
        "date": "01/29/17",
        "opponent": " Florida ",
        "location": "Nashville, Tenn.",
        "time": "L, 93-73"
    },
    {
        "date": "02/05/17",
        "opponent": " Kentucky ",
        "location": "Lexington, Ky.",
        "time": "L, 71-63"
    },
    {
        "date": "02/09/17",
        "opponent": " Mississippi State ",
        "location": "Starkville, Miss.",
        "time": "L, 86-41"
    },
    {
        "date": "02/13/17",
        "opponent": " LSU ",
        "location": "Nashville, Tenn.",
        "time": "W, 70-68"
    },
    {
        "date": "02/16/17",
        "opponent": " South Carolina ",
        "location": "Columbia, S.C.",
        "time": "L, 82-51"
    },
    {
        "date": "02/19/17",
        "opponent": " Ole Miss ",
        "location": "Nashville, Tenn.",
        "time": "W, 85-67"
    },
    {
        "date": "02/23/17",
        "opponent": " Arkansas ",
        "location": "Nashville, Tenn.",
        "time": "W, 66-64"
    },
    {
        "date": "02/26/17",
        "opponent": " LSU ",
        "location": "Baton Rouge, La.",
        "time": "12:00 p.m. CT"
    }
]