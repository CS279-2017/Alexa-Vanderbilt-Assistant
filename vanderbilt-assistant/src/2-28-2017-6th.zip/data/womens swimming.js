[
    {
        "date": "09/23/16",
        "opponent": " LSU ",
        "location": "Nashville, Tenn.",
        "time": "L, 200-61"
    },
    {
        "date": "09/30/16",
        "opponent": " Alabama/West Florida ",
        "location": "Tuscaloosa, Ala.",
        "time": "L 200.5-85.5, W 193-101"
    },
    {
        "date": "10/14/16",
        "opponent": " San Diego State/UC San Diego",
        "location": "San Diego, Calif.",
        "time": "L 168-94, L 151-143"
    },
    {
        "date": "11/04/16",
        "opponent": " Tennessee ",
        "location": "Nashville, Tenn.",
        "time": "L, 148-113"
    },
    {
        "date": "11/18/16",
        "opponent": "Houston Invitational",
        "location": "Houston, Texas",
        "time": "9th, 138 points"
    },
    {
        "date": "11/19/16",
        "opponent": "Houston Invitational",
        "location": "Houston, Texas",
        "time": "9th, 367 points"
    },
    {
        "date": "11/20/16",
        "opponent": "Houston Invitational",
        "location": "Houston, Texas",
        "time": "9th, 554 points"
    },
    {
        "date": "12/17/16",
        "opponent": " Campbell",
        "location": "Nashville, Tenn.",
        "time": "W, 144.5-117.5"
    },
    {
        "date": "01/20/17",
        "opponent": "Arkansas/Houston ",
        "location": "Nashville, Tenn.",
        "time": "2:00 p.m. CT"
    },
    {
        "date": "01/21/17",
        "opponent": "Arkansas/Houston (Senior Day) ",
        "location": "Nashville, Tenn.",
        "time": "L, 193-119; L, 163-152"
    },
    {
        "date": "01/28/17",
        "opponent": " Marshall",
        "location": "Huntington, W.V.",
        "time": "L, 146-116"
    },
    {
        "date": "02/14/17",
        "opponent": "SEC Championships ",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/15/17",
        "opponent": "SEC Championships ",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/16/17",
        "opponent": "SEC Championships",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/17/17",
        "opponent": "SEC Championships ",
        "location": "Knoxville, Tenn.",
        "time": "All Day"
    },
    {
        "date": "02/18/17",
        "opponent": "SEC Championships ",
        "location": "Knoxville, Tenn.",
        "time": "12th, 104 Points"
    },
    {
        "date": "02/24/17",
        "opponent": "Last Chance Meet",
        "location": "TBA",
        "time": "TBA"
    },
    {
        "date": "02/25/17",
        "opponent": "Last Chance Meet",
        "location": "TBA",
        "time": "TBA"
    },
    {
        "date": "03/16/17",
        "opponent": "NCAA Championships",
        "location": "Indianapolis, Ind.",
        "time": "All Day"
    },
    {
        "date": "03/17/17",
        "opponent": "NCAA Championships",
        "location": "Indianapolis, Ind.",
        "time": "All Day"
    },
    {
        "date": "03/18/17",
        "opponent": "NCAA Championships",
        "location": "Indianapolis, Ind.",
        "time": "All Day"
    }
]