[
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-19T11:00:00\">Sunday, March 19, 2017 (11:00 AM)</span> - <span class=\"dtend\" title=\"2017-03-26T14:00:00\">Sunday, March 26, 2017 (2:00 PM)</span></b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "title": "Cereal Sundays",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-19T11:00:00\">Sunday, March 19, 2017 (11:00 AM)</span> - <span class=\"dtend\" title=\"2017-03-26T14:00:00\">Sunday, March 26, 2017 (2:00 PM)</span></b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "categories": [],
        "location": "Moore College Faculty Director Apartment (Smith 502)",
        "description": "Stop by Dr. L';s apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out! "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-20T12:00:00\">Monday, March 20, 2017 (12:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-24T15:00:00\">Friday, March 24, 2017 (3:00 PM)</span></b> <div>Location: <span class=\"location\">Library Lawn</span></div> <div class=\"description\"><p>We will be building 3 mini houses to display on library lawn that tell the stories of Habitat homeowners on their roofs in order to raise awareness about poverty housing and the help that Habitat gives.</p></div>",
        "title": "KEFI Art Display",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-20T12:00:00\">Monday, March 20, 2017 (12:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-24T15:00:00\">Friday, March 24, 2017 (3:00 PM)</span></b> <div>Location: <span class=\"location\">Library Lawn</span></div> <div class=\"description\"><p>We will be building 3 mini houses to display on library lawn that tell the stories of Habitat homeowners on their roofs in order to raise awareness about poverty housing and the help that Habitat gives.</p></div>",
        "categories": [
            "Service & Philanthropy",
            "The Ingram Commons",
            "Visual Arts",
            "Volunteer Opportunities Calendar"
        ],
        "location": "Library Lawn",
        "description": "We will be building 3 mini houses to display on library lawn that tell the stories of Habitat homeowners on their roofs in order to raise awareness about poverty housing and the help that Habitat gives. "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt</span></div> <div class=\"description\"><p>Find the Senior Class Fund at the Alumni Association's Grad Fair to make your gift!</p></div>",
        "title": "Alumni Association Grad Fair",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt</span></div> <div class=\"description\"><p>Find the Senior Class Fund at the Alumni Association's Grad Fair to make your gift!</p></div>",
        "categories": [],
        "location": "Sarratt",
        "description": "Find the Senior Class Fund at the Alumni Association';s Grad Fair to make your gift! "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Promenade</span></div> <div class=\"description\"><p>**Seniors** Join us Tuesday March 21 &amp; Wednesday, March 22 from 10am to 2pm for Grad Fair on the Sarratt Promenade.&nbsp;</p>\r\n<p>- Order regalia and get all your Commencement details</p>\r\n<p>-Snag your Life After Vanderbilt Guide</p>\r\n<p>-Take yearbook photos, browse class rings and the bookstore's graduation goods</p>\r\n<p>-Learn about becoming an alumni interviewer and volunteering with the Office of Admissions</p>\r\n<p>-Plug into the Vanderbilt Alumni Chapter network in your new city</p>\r\n<p>- Get advice from the Vanderbilt Center for Student Professional Development</p>\r\n<p>-Learn about Young Alumni discounts and benefits and how to support Commodore Athletics with the National Commodore Club</p>\r\n<p>-Leave your mark with the Senior Class Fund</p>\r\n<p>-Pick up FREE Ice Cream!!</p>\r\n<p>&nbsp;</p></div>",
        "title": "Grad Fair",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Promenade</span></div> <div class=\"description\"><p>**Seniors** Join us Tuesday March 21 &amp; Wednesday, March 22 from 10am to 2pm for Grad Fair on the Sarratt Promenade.&nbsp;</p>\r\n<p>- Order regalia and get all your Commencement details</p>\r\n<p>-Snag your Life After Vanderbilt Guide</p>\r\n<p>-Take yearbook photos, browse class rings and the bookstore's graduation goods</p>\r\n<p>-Learn about becoming an alumni interviewer and volunteering with the Office of Admissions</p>\r\n<p>-Plug into the Vanderbilt Alumni Chapter network in your new city</p>\r\n<p>- Get advice from the Vanderbilt Center for Student Professional Development</p>\r\n<p>-Learn about Young Alumni discounts and benefits and how to support Commodore Athletics with the National Commodore Club</p>\r\n<p>-Leave your mark with the Senior Class Fund</p>\r\n<p>-Pick up FREE Ice Cream!!</p>\r\n<p>&nbsp;</p></div>",
        "categories": [],
        "location": "Sarratt Promenade",
        "description": "**Seniors** Join us Tuesday March 21 &; Wednesday, March 22 from 10am to 2pm for Grad Fair on the Sarratt Promenade. ; - Order regalia and get all your Commencement details -Snag your Life After Vanderbilt Guide -Take yearbook photos, browse class rings and the bookstore';s graduation goods -Learn about becoming an alumni interviewer and volunteering with the Office of Admissions -Plug into the Vanderbilt Alumni Chapter network in your new city - Get advice from the Vanderbilt Center for Student Professional Development -Learn about Young Alumni discounts and benefits and how to support Commodore Athletics with the National Commodore Club -Leave your mark with the Senior Class Fund -Pick up FREE Ice Cream!!  ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">DNR</span></div> <div class=\"description\"><p>Variations will sing in DNR with other VPAC groups</p></div>",
        "title": "Variations at VPAC Main Attraction",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">DNR</span></div> <div class=\"description\"><p>Variations will sing in DNR with other VPAC groups</p></div>",
        "categories": [],
        "location": "DNR",
        "description": "Variations will sing in DNR with other VPAC groups "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">BCC</span></div> <div class=\"description\"><p>An annual event bringing together students and faculty for food, conversation, and new connections. The Pink Lemonade Luncheon serves to encourage new connections and mentorship between students and faculty.&nbsp;</p></div>",
        "title": "Pink Lemonade Luncheon",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">BCC</span></div> <div class=\"description\"><p>An annual event bringing together students and faculty for food, conversation, and new connections. The Pink Lemonade Luncheon serves to encourage new connections and mentorship between students and faculty.&nbsp;</p></div>",
        "categories": [],
        "location": "BCC",
        "description": "An annual event bringing together students and faculty for food, conversation, and new connections. The Pink Lemonade Luncheon serves to encourage new connections and mentorship between students and faculty. ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Hyatt Room 144</span></div> <div class=\"description\"><p>Professor <a href=\"http://www.law.unc.edu/faculty/directory/flattvictorb/\">Victor Flatt</a>, <a href=\"http://www.law.unc.edu/\">University of North Carolina School of Law</a>, presents \"What Happened in North Carolina: The Role of Lawyers and the Rule of Law in Governance.&nbsp;</p>\r\n<p>Flatt will speak to the recent political changes in North Carolina and how those changes impact multiple areas of current issues the state faces.</p>\r\n<p>Sponsored by the <a href=\"https://law.vanderbilt.edu/academics/academic-programs/environmental-law/index.php\">Energy, Environment, and Land Use Program</a>. Lunch will be served.&nbsp;</p></div>",
        "title": "What Happened in North Carolina: The Role of Lawyers and the Rule in Governance",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Hyatt Room 144</span></div> <div class=\"description\"><p>Professor <a href=\"http://www.law.unc.edu/faculty/directory/flattvictorb/\">Victor Flatt</a>, <a href=\"http://www.law.unc.edu/\">University of North Carolina School of Law</a>, presents \"What Happened in North Carolina: The Role of Lawyers and the Rule of Law in Governance.&nbsp;</p>\r\n<p>Flatt will speak to the recent political changes in North Carolina and how those changes impact multiple areas of current issues the state faces.</p>\r\n<p>Sponsored by the <a href=\"https://law.vanderbilt.edu/academics/academic-programs/environmental-law/index.php\">Energy, Environment, and Land Use Program</a>. Lunch will be served.&nbsp;</p></div>",
        "categories": [
            "Political",
            "Environmental/Sustainability",
            "Academic",
            "Law School"
        ],
        "location": "Hyatt Room 144",
        "description": "Professor [Victor Flatt] (http://www.law.unc.edu/faculty/directory/flattvictorb/) , [University of North Carolina School of Law] (http://www.law.unc.edu/) , presents \";What Happened in North Carolina: The Role of Lawyers and the Rule of Law in Governance. ; Flatt will speak to the recent political changes in North Carolina and how those changes impact multiple areas of current issues the state faces. Sponsored by the [Energy, Environment, and Land Use Program] (https://law.vanderbilt.edu/academics/academic-programs/environmental-law/index.php) . Lunch will be served. ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 411A-D</span></div> <div class=\"description\"><p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "title": "SNMA Health Disparities Week",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 411A-D</span></div> <div class=\"description\"><p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall Room 411A-D",
        "description": "The Vanderbilt Chapter of the ;SNMA is pleased to invite you to the ;2017 Health Disparities Week. Every year, the ;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt ;a week of events centered on a variety of health disparities topics. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 419</span></div> <div class=\"description\"><p>Join the Oncology Interest Group for a lunch hour on patient and research advocacy! We will have a panel featuring perspectives from faculty members in medical oncology and cancer biology research, as well as patient advocates from the VICC Research Advocacy Team.</p>\r\n<p>Lunch will be provided for those who RSVP. Hope to see you there!</p></div>",
        "title": "Oncology Interest Group - Patient and Research Advocacy",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 419</span></div> <div class=\"description\"><p>Join the Oncology Interest Group for a lunch hour on patient and research advocacy! We will have a panel featuring perspectives from faculty members in medical oncology and cancer biology research, as well as patient advocates from the VICC Research Advocacy Team.</p>\r\n<p>Lunch will be provided for those who RSVP. Hope to see you there!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "LH 419",
        "description": "Join the Oncology Interest Group for a lunch hour on patient and research advocacy! We will have a panel featuring perspectives from faculty members in medical oncology and cancer biology research, as well as patient advocates from the VICC Research Advocacy Team. Lunch will be provided for those who RSVP. Hope to see you there! "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">(Moore Room) Vanderbilt Law School</span></div> <div class=\"description\"><p>The primary elections of 2016 exposed conflict within the Republican Party. This party-conflict was symptomatic of the decline of fusionism that had united traditionalist&nbsp;and social conservatism&nbsp;with political and economic right-libertarianism in a philosophical and political coalition that had operated since the 1950s. &nbsp;With fusionism fracturing, Donald Trump emerged as the Republican party front-runner and the winner of the 2016 presidential election. In recent months, journalists and pundits have sought to make sense of \"Trumpism\": the principles guiding the President and his supporters. This new Trumpism has defied easy categorization within the framework of traditional conservative principles, leaving many to question whether Trumpism is indeed compatible with conservatism.</p>\r\n<p>David Azerrad of the Heritage Foundation will come to Vanderbilt Law to discuss Trumpism and Conservatism. This lunch-time discussion will examine the phenomenon of Trumpism and consider Trumpism's divergence from and compatibility with conservative principles.&nbsp;</p>\r\n<p>Azerrad is the director of Heritage's B. Kenneth Simon Center for Principles and Politics where he teaches the tenets of the American political tradition to policymakers, political leaders and the public, while connecting the nation&rsquo;s first principles to the thorny questions of the day.&nbsp;His writings have appeared in various publications and online outlets, including The Claremont Review of Books, The Weekly Standard, National Affairs, First Things, The Times (of London), Real Clear Politics, National Review Online, The Washington Times, The Federalist,&nbsp;Public Discourse, The National Interest,&nbsp;and Interpretation: A Journal of Political Philosophy.&nbsp;</p>\r\n<p>This event is sponsored by the Federalist Society, and is free and open to the public. Lunch will be provided.</p></div>",
        "title": "Trumpism and Conservatism: Is the Phenomenon of Trumpism Compatible with Conservative Principles?",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">(Moore Room) Vanderbilt Law School</span></div> <div class=\"description\"><p>The primary elections of 2016 exposed conflict within the Republican Party. This party-conflict was symptomatic of the decline of fusionism that had united traditionalist&nbsp;and social conservatism&nbsp;with political and economic right-libertarianism in a philosophical and political coalition that had operated since the 1950s. &nbsp;With fusionism fracturing, Donald Trump emerged as the Republican party front-runner and the winner of the 2016 presidential election. In recent months, journalists and pundits have sought to make sense of \"Trumpism\": the principles guiding the President and his supporters. This new Trumpism has defied easy categorization within the framework of traditional conservative principles, leaving many to question whether Trumpism is indeed compatible with conservatism.</p>\r\n<p>David Azerrad of the Heritage Foundation will come to Vanderbilt Law to discuss Trumpism and Conservatism. This lunch-time discussion will examine the phenomenon of Trumpism and consider Trumpism's divergence from and compatibility with conservative principles.&nbsp;</p>\r\n<p>Azerrad is the director of Heritage's B. Kenneth Simon Center for Principles and Politics where he teaches the tenets of the American political tradition to policymakers, political leaders and the public, while connecting the nation&rsquo;s first principles to the thorny questions of the day.&nbsp;His writings have appeared in various publications and online outlets, including The Claremont Review of Books, The Weekly Standard, National Affairs, First Things, The Times (of London), Real Clear Politics, National Review Online, The Washington Times, The Federalist,&nbsp;Public Discourse, The National Interest,&nbsp;and Interpretation: A Journal of Political Philosophy.&nbsp;</p>\r\n<p>This event is sponsored by the Federalist Society, and is free and open to the public. Lunch will be provided.</p></div>",
        "categories": [
            "Law School"
        ],
        "location": "(Moore Room) Vanderbilt Law School",
        "description": "The primary elections of 2016 exposed conflict within the Republican Party. This party-conflict was symptomatic of the decline of fusionism that had united traditionalist ;and social conservatism ;with political and economic right-libertarianism in a philosophical and political coalition that had operated since the 1950s.  ;With fusionism fracturing, Donald Trump emerged as the Republican party front-runner and the winner of the 2016 presidential election. In recent months, journalists and pundits have sought to make sense of \";Trumpism\";: the principles guiding the President and his supporters. This new Trumpism has defied easy categorization within the framework of traditional conservative principles, leaving many to question whether Trumpism is indeed compatible with conservatism. David Azerrad of the Heritage Foundation will come to Vanderbilt Law to discuss Trumpism and Conservatism. This lunch-time discussion will examine the phenomenon of Trumpism and consider Trumpism';s divergence from and compatibility with conservative principles. ; Azerrad is the director of Heritage';s B. Kenneth Simon Center for Principles and Politics where he teaches the tenets of the American political tradition to policymakers, political leaders and the public, while connecting the nation&#x2019;s first principles to the thorny questions of the day. ;His writings have appeared in various publications and online outlets, including The Claremont Review of Books, The Weekly Standard, National Affairs, First Things, The Times (of London), Real Clear Politics, National Review Online, The Washington Times, The Federalist, ;Public Discourse, The National Interest, ;and Interpretation: A Journal of Political Philosophy. ; This event is sponsored by the Federalist Society, and is free and open to the public. Lunch will be provided. "
    },
    {
        "time": "12:08:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:08:00\">12:08 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">BCC</span></div> <div class=\"description\"><p>An annual event bringing together students and faculty for food, fellowship, conversation, and mentorship. With a brief speech on mentorship, the event focuses on encouraging new connections between students and faculty outside of the classroom in order to foster mentorship.&nbsp;</p></div>",
        "title": "Pink Lemonade Luncheon",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:08:00\">12:08 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">BCC</span></div> <div class=\"description\"><p>An annual event bringing together students and faculty for food, fellowship, conversation, and mentorship. With a brief speech on mentorship, the event focuses on encouraging new connections between students and faculty outside of the classroom in order to foster mentorship.&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Faculty Engagement"
        ],
        "location": "BCC",
        "description": "An annual event bringing together students and faculty for food, fellowship, conversation, and mentorship. With a brief speech on mentorship, the event focuses on encouraging new connections between students and faculty outside of the classroom in order to foster mentorship. ; "
    },
    {
        "time": "13:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "GME - Healthy Behaviors",
            "Greek Member Experience",
            "My Vanderbilt Experience",
            "MVE - Health & Wellness Track",
            "Health & Wellness"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "13:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 216/220</span></div> <div class=\"description\"><p>This training takes an in-depth look at the importance of facilitating difficult conversations to promoting awareness of difference, minimizing the occurrence of micro- and macro-aggressions, and appreciating diversity in all its forms. This training also explores the equally critical work of recovering from the mistakes and bumps that inevitably occur on the road to greater competence and inclusivity.</p></div>",
        "title": "Difficult Conversations: Signature Training (2)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 216/220</span></div> <div class=\"description\"><p>This training takes an in-depth look at the importance of facilitating difficult conversations to promoting awareness of difference, minimizing the occurrence of micro- and macro-aggressions, and appreciating diversity in all its forms. This training also explores the equally critical work of recovering from the mistakes and bumps that inevitably occur on the road to greater competence and inclusivity.</p></div>",
        "categories": [
            "Greek Member Experience",
            "My Vanderbilt Experience",
            "MVE - Cultural Awareness Track",
            "GME - Diversity & Inclusion",
            "Diversity & Inclusion"
        ],
        "location": "Sarratt 216/220",
        "description": "This training takes an in-depth look at the importance of facilitating difficult conversations to promoting awareness of difference, minimizing the occurrence of micro- and macro-aggressions, and appreciating diversity in all its forms. This training also explores the equally critical work of recovering from the mistakes and bumps that inevitably occur on the road to greater competence and inclusivity. "
    },
    {
        "time": "13:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen Graduate School of Management - Dean's Conference Room (2nd Floor)</span></div> <div class=\"description\"><p>Join the Turner Family Center for Social Ventures for a lunch discussion with Dr. Tim Jones, the State Epidemiologist at the Tennessee Department of Health. This event will kick off the TFC&rsquo;s Trek to East Tennessee, where students will meet with companies and community organizations engaged in rural poverty alleviation, especially around education and the opioid epidemic. Dr. Jones is responsible for the state of Tennessee&rsquo;s public health surveillance and outbreak preparedness efforts and led Tennessee&rsquo;s efforts to combat prescription drug addiction.</p>\r\n<p>All are welcome, not just those participating in the Trek.&nbsp;</p></div>",
        "title": "Lunch & Learn with TN State Epidemiologist, Dr. Tim Jones",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen Graduate School of Management - Dean's Conference Room (2nd Floor)</span></div> <div class=\"description\"><p>Join the Turner Family Center for Social Ventures for a lunch discussion with Dr. Tim Jones, the State Epidemiologist at the Tennessee Department of Health. This event will kick off the TFC&rsquo;s Trek to East Tennessee, where students will meet with companies and community organizations engaged in rural poverty alleviation, especially around education and the opioid epidemic. Dr. Jones is responsible for the state of Tennessee&rsquo;s public health surveillance and outbreak preparedness efforts and led Tennessee&rsquo;s efforts to combat prescription drug addiction.</p>\r\n<p>All are welcome, not just those participating in the Trek.&nbsp;</p></div>",
        "categories": [],
        "location": "Owen Graduate School of Management - Dean's Conference Room (2nd Floor)",
        "description": "Join the Turner Family Center for Social Ventures for a lunch discussion with Dr. Tim Jones, the State Epidemiologist at the Tennessee Department of Health. This event will kick off the TFC&#x2019;s Trek to East Tennessee, where students will meet with companies and community organizations engaged in rural poverty alleviation, especially around education and the opioid epidemic. Dr. Jones is responsible for the state of Tennessee&#x2019;s public health surveillance and outbreak preparedness efforts and led Tennessee&#x2019;s efforts to combat prescription drug addiction. All are welcome, not just those participating in the Trek. ; "
    },
    {
        "time": "13:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:30:00\">10:30 PM</span>)</b> <div>Location: <span class=\"location\">Sounds Stadium</span></div> <div class=\"description\"><p>VPB will be sending students to the sounds stadium</p></div>",
        "title": "Sounds Game",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:30:00\">10:30 PM</span>)</b> <div>Location: <span class=\"location\">Sounds Stadium</span></div> <div class=\"description\"><p>VPB will be sending students to the sounds stadium</p></div>",
        "categories": [],
        "location": "Sounds Stadium",
        "description": "VPB will be sending students to the sounds stadium "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Big Man on Campus: Zeta Tau Alpha's annual philanthropy event!</p></div>",
        "title": "Big Man on Campus (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Big Man on Campus: Zeta Tau Alpha's annual philanthropy event!</p></div>",
        "categories": [
            "Service & Philanthropy"
        ],
        "location": "Student Life Center",
        "description": "Cancelled  Big Man on Campus: Zeta Tau Alpha';s annual philanthropy event! "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Buttrick 301</span></div> <div class=\"description\">Cancelled <br/><br/> <p>The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &ndash; resulting in the reduction of violence. This educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) as well as&nbsp;introduces and develops skills needed for bystander intervention strategies.</p></div>",
        "title": "Green Dot Bystander Intervention Training (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Buttrick 301</span></div> <div class=\"description\">Cancelled <br/><br/> <p>The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &ndash; resulting in the reduction of violence. This educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) as well as&nbsp;introduces and develops skills needed for bystander intervention strategies.</p></div>",
        "categories": [
            "Health & Wellness",
            "MVE - Culture of Care Track",
            "Greek Member Experience",
            "My Vanderbilt Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Buttrick 301",
        "description": "Cancelled  The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &#x2013; resulting in the reduction of violence. This educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) as well as ;introduces and develops skills needed for bystander intervention strategies. "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">RLH 412</span></div> <div class=\"description\"><p>Current 4th year students who recently matched into Dermatology will be available to share their advice and answer questions. Topics will be geared toward&nbsp;3rd year students with an interest in applying to Derm, but all are welcome!</p>\r\n<p>Light snacks will be provided!</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p></div>",
        "title": "Derm Interest Group: Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">RLH 412</span></div> <div class=\"description\"><p>Current 4th year students who recently matched into Dermatology will be available to share their advice and answer questions. Topics will be geared toward&nbsp;3rd year students with an interest in applying to Derm, but all are welcome!</p>\r\n<p>Light snacks will be provided!</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "RLH 412",
        "description": "Current 4th year students who recently matched into Dermatology will be available to share their advice and answer questions. Topics will be geared toward ;3rd year students with an interest in applying to Derm, but all are welcome! Light snacks will be provided!  ;  ; "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall, Room 415 A-C</span></div> <div class=\"description\"><p>Come learn about the process of applying to residency in Ophthalmology! We will go over SF Match, ERAS, letters of recommendation, interviews etc. All are welcome, though much of this information will be geared toward current VMS III applying this upcoming summer. For VMS I/II, this can be a great way to learn about the process for coming years. There will be PIZZA!!!&nbsp;</p></div>",
        "title": "OIG: Ophthalmology Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall, Room 415 A-C</span></div> <div class=\"description\"><p>Come learn about the process of applying to residency in Ophthalmology! We will go over SF Match, ERAS, letters of recommendation, interviews etc. All are welcome, though much of this information will be geared toward current VMS III applying this upcoming summer. For VMS I/II, this can be a great way to learn about the process for coming years. There will be PIZZA!!!&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall, Room 415 A-C",
        "description": "Come learn about the process of applying to residency in Ophthalmology! We will go over SF Match, ERAS, letters of recommendation, interviews etc. All are welcome, though much of this information will be geared toward current VMS III applying this upcoming summer. For VMS I/II, this can be a great way to learn about the process for coming years. There will be PIZZA!!! ; "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:15:00\">7:15 PM</span>)</b> <div>Location: <span class=\"location\">TBD</span></div> <div class=\"description\"><p>Rising Dragon IIIs,</p>\r\n<p>Time to register for the immersion phase!</p>\r\n<p>CiM will put on a workshop explaining the bare bones of the process (time to register etc). However, you will <span style=\"text-decoration: underline;\">definitely</span> have many specific questions about the process. Please come meet with your Dragon SAAs on Tuesday March 21st, where we can individually go over your schedule with you, recommend combinations between courses/LC/FHD, and help you maximize efficiency and efficacy of your schedule.</p>\r\n<p>This will be a SUPER HIGH YIELD event. Please take advantage.</p>\r\n<p>Thanks!</p>\r\n<p>Your Dragon SAAs</p></div>",
        "title": "Chapman VMS II: Immersion Phase Mentoring Session",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:15:00\">7:15 PM</span>)</b> <div>Location: <span class=\"location\">TBD</span></div> <div class=\"description\"><p>Rising Dragon IIIs,</p>\r\n<p>Time to register for the immersion phase!</p>\r\n<p>CiM will put on a workshop explaining the bare bones of the process (time to register etc). However, you will <span style=\"text-decoration: underline;\">definitely</span> have many specific questions about the process. Please come meet with your Dragon SAAs on Tuesday March 21st, where we can individually go over your schedule with you, recommend combinations between courses/LC/FHD, and help you maximize efficiency and efficacy of your schedule.</p>\r\n<p>This will be a SUPER HIGH YIELD event. Please take advantage.</p>\r\n<p>Thanks!</p>\r\n<p>Your Dragon SAAs</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "TBD",
        "description": "Rising Dragon IIIs, Time to register for the immersion phase! CiM will put on a workshop explaining the bare bones of the process (time to register etc). However, you will definitely have many specific questions about the process. Please come meet with your Dragon SAAs on Tuesday March 21st, where we can individually go over your schedule with you, recommend combinations between courses/LC/FHD, and help you maximize efficiency and efficacy of your schedule. This will be a SUPER HIGH YIELD event. Please take advantage. Thanks! Your Dragon SAAs "
    },
    {
        "time": "17:08:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:08:00\">5:08 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt University</span></div> <div class=\"description\"><p>Join the Elegant Eta Beta Chapter as we provide an educational (and fun) event focused on&nbsp;fiscal responsibility as it relates to&nbsp;the&nbsp;Black Family.&nbsp;Attendees will leave this event having a better&nbsp;understanding of budgeting and basic financial planning. Food will be served.</p></div>",
        "title": "One Cent, Two Cents, Old Cents, New Cents: AKAnomics",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:08:00\">5:08 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt University</span></div> <div class=\"description\"><p>Join the Elegant Eta Beta Chapter as we provide an educational (and fun) event focused on&nbsp;fiscal responsibility as it relates to&nbsp;the&nbsp;Black Family.&nbsp;Attendees will leave this event having a better&nbsp;understanding of budgeting and basic financial planning. Food will be served.</p></div>",
        "categories": [],
        "location": "Vanderbilt University",
        "description": "Join the Elegant Eta Beta Chapter as we provide an educational (and fun) event focused on ;fiscal responsibility as it relates to ;the ;Black Family. ;Attendees will leave this event having a better ;understanding of budgeting and basic financial planning. Food will be served. "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Ingram Hall</span></div> <div class=\"description\"><p>Momentum presents their annual installment of dance performances. This show, entirely student choreographed and performed, attempts to not only entertain, but to express for the Vanderbilt community and beyond some of the universal and personal experiences our choreographers felt compelled to share.&nbsp;</p></div>",
        "title": "Momentum Dance Company Spring Show",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Ingram Hall</span></div> <div class=\"description\"><p>Momentum presents their annual installment of dance performances. This show, entirely student choreographed and performed, attempts to not only entertain, but to express for the Vanderbilt community and beyond some of the universal and personal experiences our choreographers felt compelled to share.&nbsp;</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Ingram Hall",
        "description": "Momentum presents their annual installment of dance performances. This show, entirely student choreographed and performed, attempts to not only entertain, but to express for the Vanderbilt community and beyond some of the universal and personal experiences our choreographers felt compelled to share. ; "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Chi Omega house</span></div> <div class=\"description\"><p>Author and speaker Lauren Cook is coming to our chapter to discuss how to conduct one's self in the professional world with strong leadership and confidence while also remaining positive and practicing self-care. Ultimately, the event focuses on the professional development of our members but also incorporates positive mental health practice as well.</p></div>",
        "title": "Self-Care in the Professional World",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Chi Omega house</span></div> <div class=\"description\"><p>Author and speaker Lauren Cook is coming to our chapter to discuss how to conduct one's self in the professional world with strong leadership and confidence while also remaining positive and practicing self-care. Ultimately, the event focuses on the professional development of our members but also incorporates positive mental health practice as well.</p></div>",
        "categories": [
            "Career Development",
            "Health & Wellness"
        ],
        "location": "Chi Omega house",
        "description": "Author and speaker Lauren Cook is coming to our chapter to discuss how to conduct one';s self in the professional world with strong leadership and confidence while also remaining positive and practicing self-care. Ultimately, the event focuses on the professional development of our members but also incorporates positive mental health practice as well. "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "title": "Vandy Wesley Weekly Dinner and Community",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "categories": [
            "Health & Wellness",
            "Religious/Spiritual"
        ],
        "location": "Div School Reading Room (through the courtyard next to Benton Chapel)",
        "description": "Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond.  ;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community.  ; All are welcome!! "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\"><p>Big Man on Campus: Zeta Tau Alpha's annual philanthropy event</p>\r\n<p>&nbsp;</p>\r\n<p>Come see your favorite men on campus compete in beauty and talent competitions to be named Vanderbilt's \"Big Man on Campus\"</p></div>",
        "title": "Big Man on Campus",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\"><p>Big Man on Campus: Zeta Tau Alpha's annual philanthropy event</p>\r\n<p>&nbsp;</p>\r\n<p>Come see your favorite men on campus compete in beauty and talent competitions to be named Vanderbilt's \"Big Man on Campus\"</p></div>",
        "categories": [
            "Service & Philanthropy",
            "Greek Member Experience",
            "GME - Community Impact"
        ],
        "location": "Student Life Center",
        "description": "Big Man on Campus: Zeta Tau Alpha';s annual philanthropy event  ; Come see your favorite men on campus compete in beauty and talent competitions to be named Vanderbilt';s \";Big Man on Campus\"; "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Center</span></div> <div class=\"description\"><p>A discussion regarding the origins of homelessness and methods for curbing it.</p></div>",
        "title": "Homelessness Speaks: A discussion of tackling homelessness with Dr. Shinn",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Center</span></div> <div class=\"description\"><p>A discussion regarding the origins of homelessness and methods for curbing it.</p></div>",
        "categories": [
            "Service & Philanthropy",
            "Greek Member Experience",
            "GME - Faculty Engagement"
        ],
        "location": "Kissam Center",
        "description": "A discussion regarding the origins of homelessness and methods for curbing it. "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Morgan Reading Room</span></div> <div class=\"description\"><p>Dean Beasley will host a lecture and discussion on 'fake news' - its history and effect on mainstream media. Hors d'oeuvres will be served to those who stay for the discussion.&nbsp;</p></div>",
        "title": "Fake News with Dean Beasley",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Morgan Reading Room</span></div> <div class=\"description\"><p>Dean Beasley will host a lecture and discussion on 'fake news' - its history and effect on mainstream media. Hors d'oeuvres will be served to those who stay for the discussion.&nbsp;</p></div>",
        "categories": [],
        "location": "Morgan Reading Room",
        "description": "Dean Beasley will host a lecture and discussion on ';fake news'; - its history and effect on mainstream media. Hors d';oeuvres will be served to those who stay for the discussion. ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Room 428 LH</span></div> <div class=\"description\"><p>Join the Neurology Interest Group for our post-match meeting to learn more about why to choose a career in neurology and how to be successful in the neurology match!&nbsp; Soda and Pizza will be provided!</p></div>",
        "title": "CiM: Neurology Interest Group Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Room 428 LH</span></div> <div class=\"description\"><p>Join the Neurology Interest Group for our post-match meeting to learn more about why to choose a career in neurology and how to be successful in the neurology match!&nbsp; Soda and Pizza will be provided!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Room 428 LH",
        "description": "Join the Neurology Interest Group for our post-match meeting to learn more about why to choose a career in neurology and how to be successful in the neurology match! ; Soda and Pizza will be provided! "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 407A-D</span></div> <div class=\"description\"><p>Please join us for the General Surgery Interest Group Post-Match Meeting!</p>\r\n<p>VMSIV's matching into general surgery will be there to talk about the application and interview process.</p>\r\n<p>Food and drinks provided!</p></div>",
        "title": "General Surgery Interest Group: Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 407A-D</span></div> <div class=\"description\"><p>Please join us for the General Surgery Interest Group Post-Match Meeting!</p>\r\n<p>VMSIV's matching into general surgery will be there to talk about the application and interview process.</p>\r\n<p>Food and drinks provided!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "LH 407A-D",
        "description": "Please join us for the General Surgery Interest Group Post-Match Meeting! VMSIV';s matching into general surgery will be there to talk about the application and interview process. Food and drinks provided! "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room TBD</span></div> <div class=\"description\"><p>CiM and AANS Medical Student Chapter present the Post-Match Meeting!&nbsp;</p>\r\n<p>Come and chat with our recently matched students into Neurosurgery to pick their brains and to get insight into their journey to the match as well as sage advice!&nbsp;</p></div>",
        "title": "Neurosurgery Interest Group Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room TBD</span></div> <div class=\"description\"><p>CiM and AANS Medical Student Chapter present the Post-Match Meeting!&nbsp;</p>\r\n<p>Come and chat with our recently matched students into Neurosurgery to pick their brains and to get insight into their journey to the match as well as sage advice!&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall Room TBD",
        "description": "CiM and AANS Medical Student Chapter present the Post-Match Meeting! ; Come and chat with our recently matched students into Neurosurgery to pick their brains and to get insight into their journey to the match as well as sage advice! ; "
    },
    {
        "time": "18:30:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:30:00\">6:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Board of Trust Room</span></div> <div class=\"description\"><p>Join us for dinner and discussion with&nbsp;individuals deeply impacted by the refugee crisis from the broader Nashville community.</p></div>",
        "title": "Roundtable Dinner & Discussion with Refugees",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:30:00\">6:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Board of Trust Room</span></div> <div class=\"description\"><p>Join us for dinner and discussion with&nbsp;individuals deeply impacted by the refugee crisis from the broader Nashville community.</p></div>",
        "categories": [],
        "location": "Student Life Center Board of Trust Room",
        "description": "Join us for dinner and discussion with ;individuals deeply impacted by the refugee crisis from the broader Nashville community. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Furman 114 </span></div> <div class=\"description\"><p><span style=\"font-weight: 400;\">\"Hidden No More: The Politics Behind White Fragility\", is an event centered upon the silencing, expunging and whitewashing of Black history. Additionally, it will expose the political ambitions behind the erasure of Black history and its ties to White supremacy. </span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-weight: 400;\">The success of the critically-acclaimed film &ldquo;Hidden Figures&rdquo; has shed a new light on the silencing of Black history. The film is centered around three African-American female &ldquo;computers&rdquo; who worked for NASA and were ultimately responsible for launching the first men into space.</span> <span style=\"font-weight: 400;\">This historical account, along with countless others, have been intentionally obscured and even erased to prevent the empowerment and visibility of Black achievement in America. Even upon the release of the movie and telling of the Black women&rsquo;s stories, some scenes gave White characters larger positions in the overcoming of the struggles experienced by the women in an attempt to de-antagonize White Americans. Throughout this event, instances such as this will be exposed along with the reasoning behind the choices to make such blatant changes to delete or dilute Black storylines as they pertain to American history.</span></p></div>",
        "title": "Hidden No More: The Politics Behind White Fragility",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Furman 114 </span></div> <div class=\"description\"><p><span style=\"font-weight: 400;\">\"Hidden No More: The Politics Behind White Fragility\", is an event centered upon the silencing, expunging and whitewashing of Black history. Additionally, it will expose the political ambitions behind the erasure of Black history and its ties to White supremacy. </span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-weight: 400;\">The success of the critically-acclaimed film &ldquo;Hidden Figures&rdquo; has shed a new light on the silencing of Black history. The film is centered around three African-American female &ldquo;computers&rdquo; who worked for NASA and were ultimately responsible for launching the first men into space.</span> <span style=\"font-weight: 400;\">This historical account, along with countless others, have been intentionally obscured and even erased to prevent the empowerment and visibility of Black achievement in America. Even upon the release of the movie and telling of the Black women&rsquo;s stories, some scenes gave White characters larger positions in the overcoming of the struggles experienced by the women in an attempt to de-antagonize White Americans. Throughout this event, instances such as this will be exposed along with the reasoning behind the choices to make such blatant changes to delete or dilute Black storylines as they pertain to American history.</span></p></div>",
        "categories": [],
        "location": "Furman 114 ",
        "description": "\";Hidden No More: The Politics Behind White Fragility\";, is an event centered upon the silencing, expunging and whitewashing of Black history. Additionally, it will expose the political ambitions behind the erasure of Black history and its ties to White supremacy.   ; The success of the critically-acclaimed film &#x201C;Hidden Figures&#x201D; has shed a new light on the silencing of Black history. The film is centered around three African-American female &#x201C;computers&#x201D; who worked for NASA and were ultimately responsible for launching the first men into space. This historical account, along with countless others, have been intentionally obscured and even erased to prevent the empowerment and visibility of Black achievement in America. Even upon the release of the movie and telling of the Black women&#x2019;s stories, some scenes gave White characters larger positions in the overcoming of the struggles experienced by the women in an attempt to de-antagonize White Americans. Throughout this event, instances such as this will be exposed along with the reasoning behind the choices to make such blatant changes to delete or dilute Black storylines as they pertain to American history. "
    },
    {
        "time": "19:30:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">SLC</span></div> <div class=\"description\"><p>Variations will perform at ZTA's Philanthropy Event</p></div>",
        "title": "ZTA's Big Man on Campus",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">SLC</span></div> <div class=\"description\"><p>Variations will perform at ZTA's Philanthropy Event</p></div>",
        "categories": [],
        "location": "SLC",
        "description": "Variations will perform at ZTA';s Philanthropy Event "
    },
    {
        "time": "19:30:00",
        "date": "2017-03-21",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:45:00\">9:45 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Kaleigh Bangor and Adam Merki, graduate students in German Studies</p>\r\n<p><strong>Germany </strong>(1991) Dir: Heiner Carow. Carow (<em>Coming Out, The Legend of Paul and Paula)</em>&nbsp;explores the dramatic reality of romantic relationships in a divided Germany in <em>Die Verfehlung </em>(<em>The Mistake. </em>Carow&rsquo;s retrospective look into East German life reveals a world of surveillance, isolation, desperation, and revenge in the German Democratic Republic.&nbsp;German with English subtitles. 105 min. DVD. <em>Presented in collaboration with the department of German, Russian, and East European Studies Department</em>. Film on loan from the <em>DEFA Film Library </em>at University of Massachusetts, Amherst.</p></div>",
        "title": "iLens: The Mistake (Die Verfehlung)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-21\">Tuesday, March 21, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:45:00\">9:45 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Kaleigh Bangor and Adam Merki, graduate students in German Studies</p>\r\n<p><strong>Germany </strong>(1991) Dir: Heiner Carow. Carow (<em>Coming Out, The Legend of Paul and Paula)</em>&nbsp;explores the dramatic reality of romantic relationships in a divided Germany in <em>Die Verfehlung </em>(<em>The Mistake. </em>Carow&rsquo;s retrospective look into East German life reveals a world of surveillance, isolation, desperation, and revenge in the German Democratic Republic.&nbsp;German with English subtitles. 105 min. DVD. <em>Presented in collaboration with the department of German, Russian, and East European Studies Department</em>. Film on loan from the <em>DEFA Film Library </em>at University of Massachusetts, Amherst.</p></div>",
        "categories": [
            "Performing Arts",
            "Political",
            "Graduate/Professional Students",
            "Film/Movie",
            "Visual Arts",
            "International"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by Kaleigh Bangor and Adam Merki, graduate students in German Studies Germany (1991) Dir: Heiner Carow. Carow (Coming Out, The Legend of Paul and Paula) ;explores the dramatic reality of romantic relationships in a divided Germany in Die Verfehlung (The Mistake. Carow&#x2019;s retrospective look into East German life reveals a world of surveillance, isolation, desperation, and revenge in the German Democratic Republic. ;German with English subtitles. 105 min. DVD. Presented in collaboration with the department of German, Russian, and East European Studies Department. Film on loan from the DEFA Film Library at University of Massachusetts, Amherst. "
    },
    {
        "time": "09:15:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Promenade</span></div> <div class=\"description\"><p>**Seniors** Join us Tuesday March 21 &amp; Wednesday, March 22 from 10am to 2pm for Grad Fair on the Sarratt Promenade.&nbsp;</p>\r\n<p>- Order regalia and get all your Commencement details</p>\r\n<p>-Snag your Life After Vanderbilt Guide</p>\r\n<p>-Take yearbook photos, browse class rings and the bookstore's graduation goods</p>\r\n<p>-Learn about becoming an alumni interviewer and volunteering with the Office of Admissions</p>\r\n<p>-Plug into the Vanderbilt Alumni Chapter network in your new city</p>\r\n<p>- Get advice from the Vanderbilt Center for Student Professional Development</p>\r\n<p>-Learn about Young Alumni discounts and benefits and how to support Commodore Athletics with the National Commodore Club</p>\r\n<p>-Leave your mark with the Senior Class Fund</p>\r\n<p>-Pick up FREE Ice Cream!!</p>\r\n<p>&nbsp;</p></div>",
        "title": "Grad Fair",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Promenade</span></div> <div class=\"description\"><p>**Seniors** Join us Tuesday March 21 &amp; Wednesday, March 22 from 10am to 2pm for Grad Fair on the Sarratt Promenade.&nbsp;</p>\r\n<p>- Order regalia and get all your Commencement details</p>\r\n<p>-Snag your Life After Vanderbilt Guide</p>\r\n<p>-Take yearbook photos, browse class rings and the bookstore's graduation goods</p>\r\n<p>-Learn about becoming an alumni interviewer and volunteering with the Office of Admissions</p>\r\n<p>-Plug into the Vanderbilt Alumni Chapter network in your new city</p>\r\n<p>- Get advice from the Vanderbilt Center for Student Professional Development</p>\r\n<p>-Learn about Young Alumni discounts and benefits and how to support Commodore Athletics with the National Commodore Club</p>\r\n<p>-Leave your mark with the Senior Class Fund</p>\r\n<p>-Pick up FREE Ice Cream!!</p>\r\n<p>&nbsp;</p></div>",
        "categories": [],
        "location": "Sarratt Promenade",
        "description": "**Seniors** Join us Tuesday March 21 &; Wednesday, March 22 from 10am to 2pm for Grad Fair on the Sarratt Promenade. ; - Order regalia and get all your Commencement details -Snag your Life After Vanderbilt Guide -Take yearbook photos, browse class rings and the bookstore';s graduation goods -Learn about becoming an alumni interviewer and volunteering with the Office of Admissions -Plug into the Vanderbilt Alumni Chapter network in your new city - Get advice from the Vanderbilt Center for Student Professional Development -Learn about Young Alumni discounts and benefits and how to support Commodore Athletics with the National Commodore Club -Leave your mark with the Senior Class Fund -Pick up FREE Ice Cream!!  ; "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Promenade</span></div> <div class=\"description\"><p>Find the Senior Class Fund at the Alumni Association Grad Fair in Sarratt Promenade!</p></div>",
        "title": "Alumni Association Grad Fair",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Promenade</span></div> <div class=\"description\"><p>Find the Senior Class Fund at the Alumni Association Grad Fair in Sarratt Promenade!</p></div>",
        "categories": [],
        "location": "Sarratt Promenade",
        "description": "Find the Senior Class Fund at the Alumni Association Grad Fair in Sarratt Promenade! "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">ESB</span></div> <div class=\"description\"><p>Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events</p></div>",
        "title": "M.E. Graduate Student Seminar",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">ESB</span></div> <div class=\"description\"><p>Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events</p></div>",
        "categories": [],
        "location": "ESB",
        "description": "Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM.</p>\r\n<p>Join us as we \"live among the psalms\" in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God's presence, and a blessing.</p>\r\n<p>&nbsp;</p></div>",
        "title": "One Psalm",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM.</p>\r\n<p>Join us as we \"live among the psalms\" in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God's presence, and a blessing.</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Religious/Spiritual"
        ],
        "location": "Benton Chapel",
        "description": "The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM. Join us as we \";live among the psalms\"; in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God';s presence, and a blessing.  ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\"><p>Love Indian cuisine, but think it may be too difficult to prepare? Kalyani and Venkataraman Amarnath are back by demand following their popular demonstration in June of last year. Once again they will share additional favorite native recipes chosen for ease of preparation, as well as taste. At this session, you will receive tips on Indian spices and best places to purchase recipe ingredients in the Nashville area. This presentation will be in held in the Vanderbilt Recreation and Wellness Center demonstration kitchen Wednesday, March 22nd at noon.</p></div>",
        "title": "Vandy Cooks-Indian Food Made Easy",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\"><p>Love Indian cuisine, but think it may be too difficult to prepare? Kalyani and Venkataraman Amarnath are back by demand following their popular demonstration in June of last year. Once again they will share additional favorite native recipes chosen for ease of preparation, as well as taste. At this session, you will receive tips on Indian spices and best places to purchase recipe ingredients in the Nashville area. This presentation will be in held in the Vanderbilt Recreation and Wellness Center demonstration kitchen Wednesday, March 22nd at noon.</p></div>",
        "categories": [
            "Health & Wellness"
        ],
        "location": "Vanderbilt Recreation and Wellness Center",
        "description": "Love Indian cuisine, but think it may be too difficult to prepare? Kalyani and Venkataraman Amarnath are back by demand following their popular demonstration in June of last year. Once again they will share additional favorite native recipes chosen for ease of preparation, as well as taste. At this session, you will receive tips on Indian spices and best places to purchase recipe ingredients in the Nashville area. This presentation will be in held in the Vanderbilt Recreation and Wellness Center demonstration kitchen Wednesday, March 22nd at noon. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 407A-D</span></div> <div class=\"description\">Cancelled <br/><br/> <p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "title": "SNMA Health Disparities Week (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 407A-D</span></div> <div class=\"description\">Cancelled <br/><br/> <p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall Room 407A-D",
        "description": "Cancelled  The Vanderbilt Chapter of the ;SNMA is pleased to invite you to the ;2017 Health Disparities Week. Every year, the ;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt ;a week of events centered on a variety of health disparities topics. "
    },
    {
        "time": "15:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Cultivating Wellbeing focuses on the interdependent relationship of wellness dimensions that can ultimately lead students, over a period of time, to a consistently healthy lifestyle. Students will have the opportunity to explore social wellness, occupational wellness, intellectual wellness, emotional wellness, physical wellness, and spiritual wellness. Throughout the session, students will also self-reflect on how they currently cultivate habits of each of the wellness dimensions, and they will engage in an activity to see how <em>well </em>they are . Ultimately, students will become more aware of how they can nurture various relationships, become more accountable for financial decisions, recognize whether or not career ambitions are personally satisfying, face adversity and challenges head on, implement healthy exercise and dietary habits, improve sleep quality, and examine their values, ethics, and core beliefs.</p></div>",
        "title": "Cultivating Wellbeing",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Cultivating Wellbeing focuses on the interdependent relationship of wellness dimensions that can ultimately lead students, over a period of time, to a consistently healthy lifestyle. Students will have the opportunity to explore social wellness, occupational wellness, intellectual wellness, emotional wellness, physical wellness, and spiritual wellness. Throughout the session, students will also self-reflect on how they currently cultivate habits of each of the wellness dimensions, and they will engage in an activity to see how <em>well </em>they are . Ultimately, students will become more aware of how they can nurture various relationships, become more accountable for financial decisions, recognize whether or not career ambitions are personally satisfying, face adversity and challenges head on, implement healthy exercise and dietary habits, improve sleep quality, and examine their values, ethics, and core beliefs.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - Health & Wellness Track",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Cultivating Wellbeing focuses on the interdependent relationship of wellness dimensions that can ultimately lead students, over a period of time, to a consistently healthy lifestyle. Students will have the opportunity to explore social wellness, occupational wellness, intellectual wellness, emotional wellness, physical wellness, and spiritual wellness. Throughout the session, students will also self-reflect on how they currently cultivate habits of each of the wellness dimensions, and they will engage in an activity to see how well they are . Ultimately, students will become more aware of how they can nurture various relationships, become more accountable for financial decisions, recognize whether or not career ambitions are personally satisfying, face adversity and challenges head on, implement healthy exercise and dietary habits, improve sleep quality, and examine their values, ethics, and core beliefs. "
    },
    {
        "time": "15:30:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance Room 036</span></div> <div class=\"description\"><p>Featuring Major General Tom Ayres. Major General Ayres is the Deputy Judge Advocate General of the United States Army. Prior to his position as Deputy Judge Advocate General, Ayres served as the Commander of the U.S. Army Legal Services Agency and Chief Judge of the U.S. Army Court of Appeals. He is a graduate of the United States Military Academy and received his JD from the University of Pennsylvania School of Law.</p>\r\n<p>Sponsored by the <a href=\"https://law.vanderbilt.edu/academics/academic-programs/international-legal-studies/index.php\">International Legal Studies Program</a>.&nbsp;</p></div>",
        "title": "The fight against ISIS and the Refugee Crisis in Syria - Can the Laws of War Cope?",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance Room 036</span></div> <div class=\"description\"><p>Featuring Major General Tom Ayres. Major General Ayres is the Deputy Judge Advocate General of the United States Army. Prior to his position as Deputy Judge Advocate General, Ayres served as the Commander of the U.S. Army Legal Services Agency and Chief Judge of the U.S. Army Court of Appeals. He is a graduate of the United States Military Academy and received his JD from the University of Pennsylvania School of Law.</p>\r\n<p>Sponsored by the <a href=\"https://law.vanderbilt.edu/academics/academic-programs/international-legal-studies/index.php\">International Legal Studies Program</a>.&nbsp;</p></div>",
        "categories": [
            "Academic",
            "International",
            "Law School"
        ],
        "location": "Renaissance Room 036",
        "description": "Featuring Major General Tom Ayres. Major General Ayres is the Deputy Judge Advocate General of the United States Army. Prior to his position as Deputy Judge Advocate General, Ayres served as the Commander of the U.S. Army Legal Services Agency and Chief Judge of the U.S. Army Court of Appeals. He is a graduate of the United States Military Academy and received his JD from the University of Pennsylvania School of Law. Sponsored by the [International Legal Studies Program] (https://law.vanderbilt.edu/academics/academic-programs/international-legal-studies/index.php) . ; "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">407CD Light Hall</span></div> <div class=\"description\"><p>Emergency Medicine Post-Match Meeting</p></div>",
        "title": "Emergency Medicine Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">407CD Light Hall</span></div> <div class=\"description\"><p>Emergency Medicine Post-Match Meeting</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "407CD Light Hall",
        "description": "Emergency Medicine Post-Match Meeting "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 412</span></div> <div class=\"description\"><p>Come hear from our senior medical students about their experiences on the interview trail for both diagnostic and interventional radiology. All years are welcome to attend---it's never too early to start getting an idea of how to prepare for applications and interview season. This year is the first time we have students interviewing for spots in integrated IR residencies, so that will be a particular topic of discussion.&nbsp;</p>\r\n<p>We plan to have free food for all attendees, so please RSVP if you plan to attend.</p></div>",
        "title": "Radiology & IR Interest Group: Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 412</span></div> <div class=\"description\"><p>Come hear from our senior medical students about their experiences on the interview trail for both diagnostic and interventional radiology. All years are welcome to attend---it's never too early to start getting an idea of how to prepare for applications and interview season. This year is the first time we have students interviewing for spots in integrated IR residencies, so that will be a particular topic of discussion.&nbsp;</p>\r\n<p>We plan to have free food for all attendees, so please RSVP if you plan to attend.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall 412",
        "description": "Come hear from our senior medical students about their experiences on the interview trail for both diagnostic and interventional radiology. All years are welcome to attend---it';s never too early to start getting an idea of how to prepare for applications and interview season. This year is the first time we have students interviewing for spots in integrated IR residencies, so that will be a particular topic of discussion. ; We plan to have free food for all attendees, so please RSVP if you plan to attend. "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 325</span></div> <div class=\"description\"><p>Want alumni advice on your interest to pursue careers in Entrepreneurship? Or maybe you&rsquo;re unsure of what working in this industry would look like? Well, here&rsquo;s your chance to find out more!<br /><br />Your Vanderbilt Alumni Association presents &ldquo;Opening Dores&rdquo; dinners -- informal, on-campus dinners with students and alumni to get real-world advice and to network.<br /><br />Dinner on us!<br /><br />Seating is limited, so sign up quickly!<br /><br />For reservations, email drew.webb@vanderbilt.edu&nbsp;(Note: you must receive a confirmation email for admittance.)<br /><br />Sponsored by your Vanderbilt Alumni Association</p></div>",
        "title": "Opening Dores:  Entrepreneurship",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 325</span></div> <div class=\"description\"><p>Want alumni advice on your interest to pursue careers in Entrepreneurship? Or maybe you&rsquo;re unsure of what working in this industry would look like? Well, here&rsquo;s your chance to find out more!<br /><br />Your Vanderbilt Alumni Association presents &ldquo;Opening Dores&rdquo; dinners -- informal, on-campus dinners with students and alumni to get real-world advice and to network.<br /><br />Dinner on us!<br /><br />Seating is limited, so sign up quickly!<br /><br />For reservations, email drew.webb@vanderbilt.edu&nbsp;(Note: you must receive a confirmation email for admittance.)<br /><br />Sponsored by your Vanderbilt Alumni Association</p></div>",
        "categories": [
            "Career Development"
        ],
        "location": "Sarratt 325",
        "description": "Want alumni advice on your interest to pursue careers in Entrepreneurship? Or maybe you&#x2019;re unsure of what working in this industry would look like? Well, here&#x2019;s your chance to find out more! Your Vanderbilt Alumni Association presents &#x201C;Opening Dores&#x201D; dinners -- informal, on-campus dinners with students and alumni to get real-world advice and to network. Dinner on us! Seating is limited, so sign up quickly! For reservations, email drew.webb@vanderbilt.edu ;(Note: you must receive a confirmation email for admittance.) Sponsored by your Vanderbilt Alumni Association "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Room 309 Buttrick Hall</span></div> <div class=\"description\"><p><strong>Come practice public speaking in a safe and fun environment!</strong> The MC of the meeting, the toastmaster, leads us through the evening&rsquo;s events while educating and entertaining everyone with facts/stories that coincide with a theme that he/she has chosen. Themes can range from Waffle House to zoning issues and everywhere in-between. The first half of the meeting consists of prepared speeches followed by an impromptu speaking section where everyone has the opportunity to participate. The second half of the meeting is run by the general evaluator and the evaluation team. The evaluation team gives positive criticism and encouragement to both individuals and the group as a whole. They provide us with specific advice, so we can actively improve our public speaking skills. Meetings are on the 2nd and 4th Wednesday of each month at 6pm in the 3rd floor of Buttrick hall. All in the Vanderbilt community and greater Nashville community are welcome to join!</p></div>",
        "title": "Vanderbilt Toastmasters General Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Room 309 Buttrick Hall</span></div> <div class=\"description\"><p><strong>Come practice public speaking in a safe and fun environment!</strong> The MC of the meeting, the toastmaster, leads us through the evening&rsquo;s events while educating and entertaining everyone with facts/stories that coincide with a theme that he/she has chosen. Themes can range from Waffle House to zoning issues and everywhere in-between. The first half of the meeting consists of prepared speeches followed by an impromptu speaking section where everyone has the opportunity to participate. The second half of the meeting is run by the general evaluator and the evaluation team. The evaluation team gives positive criticism and encouragement to both individuals and the group as a whole. They provide us with specific advice, so we can actively improve our public speaking skills. Meetings are on the 2nd and 4th Wednesday of each month at 6pm in the 3rd floor of Buttrick hall. All in the Vanderbilt community and greater Nashville community are welcome to join!</p></div>",
        "categories": [],
        "location": "Room 309 Buttrick Hall",
        "description": "Come practice public speaking in a safe and fun environment! The MC of the meeting, the toastmaster, leads us through the evening&#x2019;s events while educating and entertaining everyone with facts/stories that coincide with a theme that he/she has chosen. Themes can range from Waffle House to zoning issues and everywhere in-between. The first half of the meeting consists of prepared speeches followed by an impromptu speaking section where everyone has the opportunity to participate. The second half of the meeting is run by the general evaluator and the evaluation team. The evaluation team gives positive criticism and encouragement to both individuals and the group as a whole. They provide us with specific advice, so we can actively improve our public speaking skills. Meetings are on the 2nd and 4th Wednesday of each month at 6pm in the 3rd floor of Buttrick hall. All in the Vanderbilt community and greater Nashville community are welcome to join! "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">4th Floor Light Hall</span></div> <div class=\"description\"><p>Annual post-match meeting to learn about the application process and the specialty in general.</p></div>",
        "title": "Orthopedic Interest Group: Post Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">4th Floor Light Hall</span></div> <div class=\"description\"><p>Annual post-match meeting to learn about the application process and the specialty in general.</p></div>",
        "categories": [],
        "location": "4th Floor Light Hall",
        "description": "Annual post-match meeting to learn about the application process and the specialty in general. "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall (Room TBD)</span></div> <div class=\"description\"><p>Considering a career in anesthesiology? Join the Anesthesiology Interest Group for a Q&amp;A&nbsp;with VMS-4&nbsp;anesthesiology applicants to hear their&nbsp;insights on deciding on a career in anesthesia, building&nbsp;a competitive application,&nbsp;and navigating the application process.</p>\r\n<p>Whether you're a VMS-1/2 exploring&nbsp;anesthesiology among several options or a VMS-3 preparing for the upcoming application cycle, we invite you to come learn more about what anesthesiology involves, whether it's the right fit for you, and what you can do at each stage of medical school to position yourself for success!</p>\r\n<p>Dinner will be provided for&nbsp;all attendees, courtesy of the Department of Anesthesiology and Careers in Medicine.</p></div>",
        "title": "Anesthesiology Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall (Room TBD)</span></div> <div class=\"description\"><p>Considering a career in anesthesiology? Join the Anesthesiology Interest Group for a Q&amp;A&nbsp;with VMS-4&nbsp;anesthesiology applicants to hear their&nbsp;insights on deciding on a career in anesthesia, building&nbsp;a competitive application,&nbsp;and navigating the application process.</p>\r\n<p>Whether you're a VMS-1/2 exploring&nbsp;anesthesiology among several options or a VMS-3 preparing for the upcoming application cycle, we invite you to come learn more about what anesthesiology involves, whether it's the right fit for you, and what you can do at each stage of medical school to position yourself for success!</p>\r\n<p>Dinner will be provided for&nbsp;all attendees, courtesy of the Department of Anesthesiology and Careers in Medicine.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall (Room TBD)",
        "description": "Considering a career in anesthesiology? Join the Anesthesiology Interest Group for a Q&;A ;with VMS-4 ;anesthesiology applicants to hear their ;insights on deciding on a career in anesthesia, building ;a competitive application, ;and navigating the application process. Whether you';re a VMS-1/2 exploring ;anesthesiology among several options or a VMS-3 preparing for the upcoming application cycle, we invite you to come learn more about what anesthesiology involves, whether it';s the right fit for you, and what you can do at each stage of medical school to position yourself for success! Dinner will be provided for ;all attendees, courtesy of the Department of Anesthesiology and Careers in Medicine. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Commons MPR</span></div> <div class=\"description\"><p>This event will have a panel of Peabody College alumni who have careers in Nashville. The alumni will talk about their experiences and give advice to current students about graduating and pursing career with their degrees.&nbsp;</p></div>",
        "title": "Alumni Networking Event",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Commons MPR</span></div> <div class=\"description\"><p>This event will have a panel of Peabody College alumni who have careers in Nashville. The alumni will talk about their experiences and give advice to current students about graduating and pursing career with their degrees.&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Personal Development"
        ],
        "location": "Commons MPR",
        "description": "This event will have a panel of Peabody College alumni who have careers in Nashville. The alumni will talk about their experiences and give advice to current students about graduating and pursing career with their degrees. ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\"><p>Annual Derby Days Dance Competition</p></div>",
        "title": "Derby Days Dance Competition",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\"><p>Annual Derby Days Dance Competition</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Community Impact"
        ],
        "location": "Student Life Center",
        "description": "Annual Derby Days Dance Competition "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Stevenson 4327</span></div> <div class=\"description\"><p><span style=\"font-weight: 400;\">Topics Discussed:</span></p>\r\n<ol>\r\n<li style=\"font-weight: 400;\"><span style=\"font-weight: 400;\">Alumni speaker - their experience in the industry</span></li>\r\n<li style=\"font-weight: 400;\"><span style=\"font-weight: 400;\">Upperclassmen Q&amp;A Panel - share experience in the industry</span></li>\r\n<li style=\"font-weight: 400;\">Networking Session</li>\r\n</ol>\r\n<p>Free Chick-Fil-A will be provided!</p></div>",
        "title": "Main Kickoff: Wall Street 101 - An Introduction into Finance and Vanderbilt Recruiting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Stevenson 4327</span></div> <div class=\"description\"><p><span style=\"font-weight: 400;\">Topics Discussed:</span></p>\r\n<ol>\r\n<li style=\"font-weight: 400;\"><span style=\"font-weight: 400;\">Alumni speaker - their experience in the industry</span></li>\r\n<li style=\"font-weight: 400;\"><span style=\"font-weight: 400;\">Upperclassmen Q&amp;A Panel - share experience in the industry</span></li>\r\n<li style=\"font-weight: 400;\">Networking Session</li>\r\n</ol>\r\n<p>Free Chick-Fil-A will be provided!</p></div>",
        "categories": [],
        "location": "Stevenson 4327",
        "description": "Topics Discussed: 1--Alumni speaker - their experience in the industry  2--Upperclassmen Q&;A Panel - share experience in the industry  3--Networking Session  Free Chick-Fil-A will be provided! "
    },
    {
        "time": "19:30:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Multipurpose Room C210</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Join Vanderbilt and community activists to discuss effective means to fight for refugees and other marginalized groups of Nashville. The current administration is throwing new challenges at us, and it is imperative that we learn how to organize resistance.&nbsp;</p></div>",
        "title": "Defending Our Neighbors: Pro-refugee Activism (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Multipurpose Room C210</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Join Vanderbilt and community activists to discuss effective means to fight for refugees and other marginalized groups of Nashville. The current administration is throwing new challenges at us, and it is imperative that we learn how to organize resistance.&nbsp;</p></div>",
        "categories": [
            "Diversity & Inclusion",
            "Political",
            "GME - Diversity & Inclusion",
            "Greek Member Experience",
            "International"
        ],
        "location": "Kissam Multipurpose Room C210",
        "description": "Cancelled  Join Vanderbilt and community activists to discuss effective means to fight for refugees and other marginalized groups of Nashville. The current administration is throwing new challenges at us, and it is imperative that we learn how to organize resistance. ; "
    },
    {
        "time": "19:30:00",
        "date": "2017-03-22",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Jennifer Fay, Associate Professor and Director of Cinema &amp; Media Arts, and Anand Taneja, Assiatant Professor of Religious Studies.</p>\r\n<p><strong>Iran (2011) </strong>Dir: Asghar Farhadi. Set in contemporary Iran, <em>A Separation</em> has been celebrated as one of the best films of 2011 (winning the Academy Award for Best Foreign Language Film). It concerns the dissolution of a marriage, the stress of caring for an elderly family member, and the drama of class and religious difference. Farsi with English Subtitles. 123 min. 35mm. <em>Presented in collaboration with Cinema &amp; Media Arts</em></p></div>",
        "title": "iLens: A Separation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-22\">Wednesday, March 22, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Jennifer Fay, Associate Professor and Director of Cinema &amp; Media Arts, and Anand Taneja, Assiatant Professor of Religious Studies.</p>\r\n<p><strong>Iran (2011) </strong>Dir: Asghar Farhadi. Set in contemporary Iran, <em>A Separation</em> has been celebrated as one of the best films of 2011 (winning the Academy Award for Best Foreign Language Film). It concerns the dissolution of a marriage, the stress of caring for an elderly family member, and the drama of class and religious difference. Farsi with English Subtitles. 123 min. 35mm. <em>Presented in collaboration with Cinema &amp; Media Arts</em></p></div>",
        "categories": [
            "Film/Movie",
            "Visual Arts",
            "Religious/Spiritual",
            "International"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by Jennifer Fay, Associate Professor and Director of Cinema &; Media Arts, and Anand Taneja, Assiatant Professor of Religious Studies. Iran (2011) Dir: Asghar Farhadi. Set in contemporary Iran, A Separation has been celebrated as one of the best films of 2011 (winning the Academy Award for Best Foreign Language Film). It concerns the dissolution of a marriage, the stress of caring for an elderly family member, and the drama of class and religious difference. Farsi with English Subtitles. 123 min. 35mm. Presented in collaboration with Cinema &; Media Arts "
    },
    {
        "time": "09:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "Health & Wellness",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Library Lawn</span></div> <div class=\"description\"><p>Join Lori Cowan, Vanderbilt Recreation and Wellness Center Group Fitness Coordinator, for a 45 minute outdoor yoga class that will rejuvenate and de-stress you while providing opportunity for you to enjoy spring weather in Tennessee. Class equipment will be provided.</p></div>",
        "title": "Yoga on the Lawn",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Library Lawn</span></div> <div class=\"description\"><p>Join Lori Cowan, Vanderbilt Recreation and Wellness Center Group Fitness Coordinator, for a 45 minute outdoor yoga class that will rejuvenate and de-stress you while providing opportunity for you to enjoy spring weather in Tennessee. Class equipment will be provided.</p></div>",
        "categories": [
            "Health & Wellness"
        ],
        "location": "Library Lawn",
        "description": "Join Lori Cowan, Vanderbilt Recreation and Wellness Center Group Fitness Coordinator, for a 45 minute outdoor yoga class that will rejuvenate and de-stress you while providing opportunity for you to enjoy spring weather in Tennessee. Class equipment will be provided. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Atrium</span></div> <div class=\"description\"><p>The Engineering Council will be holding a de-stress event for all engineering students.</p></div>",
        "title": "March De-Stress Event",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Atrium</span></div> <div class=\"description\"><p>The Engineering Council will be holding a de-stress event for all engineering students.</p></div>",
        "categories": [],
        "location": "Featheringill Atrium",
        "description": "The Engineering Council will be holding a de-stress event for all engineering students. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 411A-D</span></div> <div class=\"description\"><p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "title": "SNMA Health Disparities Week",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 411A-D</span></div> <div class=\"description\"><p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall Room 411A-D",
        "description": "The Vanderbilt Chapter of the ;SNMA is pleased to invite you to the ;2017 Health Disparities Week. Every year, the ;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt ;a week of events centered on a variety of health disparities topics. "
    },
    {
        "time": "15:15:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - Health & Wellness Track",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "16:30:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:30:00\">4:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">The Pub at Overcup Oak </span></div> <div class=\"description\"><p>Come join Habitat for Humanity at the Pub on March 23rd from 4:30-7pm to hear the tallest of members of Nashville's community suffering from homelessness and poverty, along with Habitat homeowners.&nbsp;</p></div>",
        "title": "Pub Live: Hidden Voices of Nashville",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:30:00\">4:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">The Pub at Overcup Oak </span></div> <div class=\"description\"><p>Come join Habitat for Humanity at the Pub on March 23rd from 4:30-7pm to hear the tallest of members of Nashville's community suffering from homelessness and poverty, along with Habitat homeowners.&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience",
            "MVE - Cultural Awareness Track",
            "GME - Community Impact",
            "My Vanderbilt Experience",
            "Political",
            "Diversity & Inclusion",
            "Performing Arts"
        ],
        "location": "The Pub at Overcup Oak ",
        "description": "Come join Habitat for Humanity at the Pub on March 23rd from 4:30-7pm to hear the tallest of members of Nashville';s community suffering from homelessness and poverty, along with Habitat homeowners. ; "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-23T17:00:00\">Thursday, March 23, 2017 (5:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-23T23:00:00\">Thursday, March 23, 2017 (11:00 PM)</span></b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\"><p>The Vanderbilt Recreation and Wellness Center (VRWC) welcomes you to join our Game Night during March Madness!<br /><br />We will have the March Madness games showing, along with Xbox One&rsquo;s to play NBA 2k17 and FIFA 2017. Following open free play we will have a FIFA Tournament for Gamestop Gift Cards. Pizza and prizes will be available for those who come by. Games will be on starting at 5pm and will run until the end of the tournament. Google Virtual Reality goggles and Just Dance will be available for free-play as well.<br /><br />Contact: Wade Evans, (615) 343-8185 for more information.<br />wade.e.evans@vanderbilt.ed<wbr />u</p></div>",
        "title": "Game Night at the VRWC",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-23T17:00:00\">Thursday, March 23, 2017 (5:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-23T23:00:00\">Thursday, March 23, 2017 (11:00 PM)</span></b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\"><p>The Vanderbilt Recreation and Wellness Center (VRWC) welcomes you to join our Game Night during March Madness!<br /><br />We will have the March Madness games showing, along with Xbox One&rsquo;s to play NBA 2k17 and FIFA 2017. Following open free play we will have a FIFA Tournament for Gamestop Gift Cards. Pizza and prizes will be available for those who come by. Games will be on starting at 5pm and will run until the end of the tournament. Google Virtual Reality goggles and Just Dance will be available for free-play as well.<br /><br />Contact: Wade Evans, (615) 343-8185 for more information.<br />wade.e.evans@vanderbilt.ed<wbr />u</p></div>",
        "categories": [
            "Health & Wellness",
            "My Vanderbilt Experience",
            "MVE - Dores After Dark Track"
        ],
        "location": "Vanderbilt Recreation and Wellness Center",
        "description": "The Vanderbilt Recreation and Wellness Center (VRWC) welcomes you to join our Game Night during March Madness! We will have the March Madness games showing, along with Xbox One&#x2019;s to play NBA 2k17 and FIFA 2017. Following open free play we will have a FIFA Tournament for Gamestop Gift Cards. Pizza and prizes will be available for those who come by. Games will be on starting at 5pm and will run until the end of the tournament. Google Virtual Reality goggles and Just Dance will be available for free-play as well. Contact: Wade Evans, (615) 343-8185 for more information. wade.e.evans@vanderbilt.edu "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">419 A/B Light Hall</span></div> <div class=\"description\"><p>The fourth years have matched into the wonderful (read: best) speciality - PEDIATRICS! Come hang out, eat some food, and listen to our endless wisdom about matching into peds while it's still fresh in our minds.&nbsp;</p>\r\n<p>We will have a panel of 4th years who have matched into pediatrics to answer any and all questions about the pathway to pediatrics. This meeting is open to students from ALL years who are interested in pediatrics (no committment necessary! :)&nbsp;</p></div>",
        "title": "Pediatrics Interest Group: Post-Match meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">419 A/B Light Hall</span></div> <div class=\"description\"><p>The fourth years have matched into the wonderful (read: best) speciality - PEDIATRICS! Come hang out, eat some food, and listen to our endless wisdom about matching into peds while it's still fresh in our minds.&nbsp;</p>\r\n<p>We will have a panel of 4th years who have matched into pediatrics to answer any and all questions about the pathway to pediatrics. This meeting is open to students from ALL years who are interested in pediatrics (no committment necessary! :)&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "419 A/B Light Hall",
        "description": "The fourth years have matched into the wonderful (read: best) speciality - PEDIATRICS! Come hang out, eat some food, and listen to our endless wisdom about matching into peds while it';s still fresh in our minds. ; We will have a panel of 4th years who have matched into pediatrics to answer any and all questions about the pathway to pediatrics. This meeting is open to students from ALL years who are interested in pediatrics (no committment necessary! :) ; "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall</span></div> <div class=\"description\"><div align=\"center\">\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Vanderbilt Medical School's Radiation Oncology Interest Group invites you to our <strong>post-Match</strong> meeting on:</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\"><strong>Thursday, March 23rd @ 5pm</strong></font></font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\"><strong>Light Hall Room 411A-C</strong></font></font></div>\r\n</div>\r\n<div align=\"center\">&nbsp;</div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Interested in Radiation Oncology? Ever even heard of it? &nbsp;Want to learn about this often <strong><span style=\"text-decoration: underline;\">undiscovered gem</span></strong> of a specialty?</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Want to hear what the away rotation, application and interview processes are like?</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">&nbsp;</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Come join us for </font><font size=\"2\" face=\"Calibri,sans-serif\">beverages and snacks (provided by the interest group leaders), and learn about the field of radiation oncology&rsquo;s application process. This exciting specialty provides a unique and interesting combination of meaningful patient interaction, face-to-face patient care, and incredible technology. Radiation oncologists utilize cutting edge techniques to treat cancers all over the body for both curative and palliative purposes.&nbsp;</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">&nbsp;</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">We are excited to have you come join us!</font></div></div>",
        "title": "Radiation Oncology Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall</span></div> <div class=\"description\"><div align=\"center\">\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Vanderbilt Medical School's Radiation Oncology Interest Group invites you to our <strong>post-Match</strong> meeting on:</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\"><strong>Thursday, March 23rd @ 5pm</strong></font></font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\"><strong>Light Hall Room 411A-C</strong></font></font></div>\r\n</div>\r\n<div align=\"center\">&nbsp;</div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Interested in Radiation Oncology? Ever even heard of it? &nbsp;Want to learn about this often <strong><span style=\"text-decoration: underline;\">undiscovered gem</span></strong> of a specialty?</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Want to hear what the away rotation, application and interview processes are like?</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">&nbsp;</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">Come join us for </font><font size=\"2\" face=\"Calibri,sans-serif\">beverages and snacks (provided by the interest group leaders), and learn about the field of radiation oncology&rsquo;s application process. This exciting specialty provides a unique and interesting combination of meaningful patient interaction, face-to-face patient care, and incredible technology. Radiation oncologists utilize cutting edge techniques to treat cancers all over the body for both curative and palliative purposes.&nbsp;</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">&nbsp;</font></div>\r\n<div align=\"center\"><font size=\"2\" face=\"Calibri,sans-serif\">We are excited to have you come join us!</font></div></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall",
        "description": "Vanderbilt Medical School';s Radiation Oncology Interest Group invites you to our post-Match meeting on: Thursday, March 23rd @ 5pm Light Hall Room 411A-C  ; Interested in Radiation Oncology? Ever even heard of it?  ;Want to learn about this often undiscovered gem of a specialty? Want to hear what the away rotation, application and interview processes are like?  ; Come join us for beverages and snacks (provided by the interest group leaders), and learn about the field of radiation oncology&#x2019;s application process. This exciting specialty provides a unique and interesting combination of meaningful patient interaction, face-to-face patient care, and incredible technology. Radiation oncologists utilize cutting edge techniques to treat cancers all over the body for both curative and palliative purposes. ;  ; We are excited to have you come join us! "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">3rd floor Light Hall couches, North lobby side</span></div> <div class=\"description\"><p>Come knit and crochet with VMS Knits for (K)Nashville! We create various projects for underserved communities in Nashville, such as our Shade Tree patients. No knitting/crocheting experience necessary, and we provide all the supplies. Hope to see you there!</p></div>",
        "title": "VMS Knits weekly meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">3rd floor Light Hall couches, North lobby side</span></div> <div class=\"description\"><p>Come knit and crochet with VMS Knits for (K)Nashville! We create various projects for underserved communities in Nashville, such as our Shade Tree patients. No knitting/crocheting experience necessary, and we provide all the supplies. Hope to see you there!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "3rd floor Light Hall couches, North lobby side",
        "description": "Come knit and crochet with VMS Knits for (K)Nashville! We create various projects for underserved communities in Nashville, such as our Shade Tree patients. No knitting/crocheting experience necessary, and we provide all the supplies. Hope to see you there! "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">College Halls at Kissam, Moore Great Room</span></div> <div class=\"description\"><p>Come out to Kissam for food and music!</p></div>",
        "title": "Collaborative event ft. The Ransom Notes from University of Chicago",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">College Halls at Kissam, Moore Great Room</span></div> <div class=\"description\"><p>Come out to Kissam for food and music!</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "College Halls at Kissam, Moore Great Room",
        "description": "Come out to Kissam for food and music! "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom</span></div> <div class=\"description\"><p>&nbsp;</p>\r\n<p>The Vanderbilt Office of University Chaplain and Religious Life, and the Vanderbilt Interfaith Council have partnered with the organizers of Nashville&rsquo;s Premiere&nbsp;<a href=\"http://www.interfaithoneness.org/\">Interfaith Oneness Music Festival</a>&nbsp;to put together an exciting new performance opportunity on campus.&nbsp;</p>\r\n<p><strong>Building Bridges&nbsp;</strong>is an interfaith celebration that aims to bring people of various religions and backgrounds together to express their faiths through artistic performance. The goal of this celebration is to showcase how art can be a bridge that connects diverse people together regardless of the differences in their spiritual beliefs, and to emphasize the respect for humanity that unites all faiths and religions. This event will also connect our campus to the greater Nashville community by inviting professional and semi-professional groups from our wonderful city to join us in this celebration. We hope to demonstrate our commitment to diversity and interfaith understanding beyond the boundaries of our campus.</p>\r\n<p>&nbsp;Performances do not need to be outwardly religious and may include music, dancing, spoken word, or any form of artistic performance that highlights community, unity and human connection.</p>\r\n<p>The performance is scheduled to take place on<strong>&nbsp;Thursday March 23<sup>rd</sup></strong>&nbsp;in the Student Life Center Ballroom and is open and free to the public.&nbsp;<strong>Dinner</strong>&nbsp;featuring foods from multiple faith traditions will be served at 6:00 PM and&nbsp;<strong>performances start at 6:15 PM</strong></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p></div>",
        "title": "Building Bridges: an Interfaith Celebration of Uni...",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom</span></div> <div class=\"description\"><p>&nbsp;</p>\r\n<p>The Vanderbilt Office of University Chaplain and Religious Life, and the Vanderbilt Interfaith Council have partnered with the organizers of Nashville&rsquo;s Premiere&nbsp;<a href=\"http://www.interfaithoneness.org/\">Interfaith Oneness Music Festival</a>&nbsp;to put together an exciting new performance opportunity on campus.&nbsp;</p>\r\n<p><strong>Building Bridges&nbsp;</strong>is an interfaith celebration that aims to bring people of various religions and backgrounds together to express their faiths through artistic performance. The goal of this celebration is to showcase how art can be a bridge that connects diverse people together regardless of the differences in their spiritual beliefs, and to emphasize the respect for humanity that unites all faiths and religions. This event will also connect our campus to the greater Nashville community by inviting professional and semi-professional groups from our wonderful city to join us in this celebration. We hope to demonstrate our commitment to diversity and interfaith understanding beyond the boundaries of our campus.</p>\r\n<p>&nbsp;Performances do not need to be outwardly religious and may include music, dancing, spoken word, or any form of artistic performance that highlights community, unity and human connection.</p>\r\n<p>The performance is scheduled to take place on<strong>&nbsp;Thursday March 23<sup>rd</sup></strong>&nbsp;in the Student Life Center Ballroom and is open and free to the public.&nbsp;<strong>Dinner</strong>&nbsp;featuring foods from multiple faith traditions will be served at 6:00 PM and&nbsp;<strong>performances start at 6:15 PM</strong></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Religious/Spiritual",
            "Visual Arts",
            "My Vanderbilt Experience",
            "MVE - Culture of Care Track",
            "GME - Diversity & Inclusion",
            "Greek Member Experience"
        ],
        "location": "Student Life Center Ballroom",
        "description": " ; The Vanderbilt Office of University Chaplain and Religious Life, and the Vanderbilt Interfaith Council have partnered with the organizers of Nashville&#x2019;s Premiere ; [Interfaith Oneness Music Festival] (http://www.interfaithoneness.org/)  ;to put together an exciting new performance opportunity on campus. ; Building Bridges ;is an interfaith celebration that aims to bring people of various religions and backgrounds together to express their faiths through artistic performance. The goal of this celebration is to showcase how art can be a bridge that connects diverse people together regardless of the differences in their spiritual beliefs, and to emphasize the respect for humanity that unites all faiths and religions. This event will also connect our campus to the greater Nashville community by inviting professional and semi-professional groups from our wonderful city to join us in this celebration. We hope to demonstrate our commitment to diversity and interfaith understanding beyond the boundaries of our campus.  ;Performances do not need to be outwardly religious and may include music, dancing, spoken word, or any form of artistic performance that highlights community, unity and human connection. The performance is scheduled to take place on ;Thursday March 23rd ;in the Student Life Center Ballroom and is open and free to the public. ;Dinner ;featuring foods from multiple faith traditions will be served at 6:00 PM and ;performances start at 6:15 PM  ;  ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 407AB</span></div> <div class=\"description\"><p>Come talk with 4th years about the field of Ob-Gyn as well as specific application tips for 3rd year students.</p></div>",
        "title": "Ob-Gyn Post Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 407AB</span></div> <div class=\"description\"><p>Come talk with 4th years about the field of Ob-Gyn as well as specific application tips for 3rd year students.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall 407AB",
        "description": "Come talk with 4th years about the field of Ob-Gyn as well as specific application tips for 3rd year students. "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 407 C-D</span></div> <div class=\"description\"><p>We invite you to join current 4th year students who recently matched into pathology to get their perspective on applying to residency as well as pathology as a specialty. &nbsp;While some topics (applications, rotations, letters of rec, etc.) will be slightly geared toward&nbsp;3rd year students with an interest in applying to pathology,&nbsp;everyone from any year is welcome. &nbsp;</p>\r\n<p>Snacks and refreshments will be provided!</p>\r\n<p>&nbsp;</p></div>",
        "title": "Pathology Interest Group: Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 407 C-D</span></div> <div class=\"description\"><p>We invite you to join current 4th year students who recently matched into pathology to get their perspective on applying to residency as well as pathology as a specialty. &nbsp;While some topics (applications, rotations, letters of rec, etc.) will be slightly geared toward&nbsp;3rd year students with an interest in applying to pathology,&nbsp;everyone from any year is welcome. &nbsp;</p>\r\n<p>Snacks and refreshments will be provided!</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall 407 C-D",
        "description": "We invite you to join current 4th year students who recently matched into pathology to get their perspective on applying to residency as well as pathology as a specialty.  ;While some topics (applications, rotations, letters of rec, etc.) will be slightly geared toward ;3rd year students with an interest in applying to pathology, ;everyone from any year is welcome.  ; Snacks and refreshments will be provided!  ; "
    },
    {
        "time": "18:30:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:30:00\">6:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:30:00\">10:30 PM</span>)</b> <div>Location: <span class=\"location\">Alumni 206</span></div> <div class=\"description\"><p>SACE Open Mic Night</p></div>",
        "title": "SACE Open Mic Night",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:30:00\">6:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:30:00\">10:30 PM</span>)</b> <div>Location: <span class=\"location\">Alumni 206</span></div> <div class=\"description\"><p>SACE Open Mic Night</p></div>",
        "categories": [],
        "location": "Alumni 206",
        "description": "SACE Open Mic Night "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Hank Ingram House Lobby</span></div> <div class=\"description\"><p>Join us for the opportunity to hear a panel of refugees and immigrants living in Nashville share some of the experiences they've had before and after moving to the US. Treats will be provided.</p></div>",
        "title": "Refugee Week: Panel Discussion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Hank Ingram House Lobby</span></div> <div class=\"description\"><p>Join us for the opportunity to hear a panel of refugees and immigrants living in Nashville share some of the experiences they've had before and after moving to the US. Treats will be provided.</p></div>",
        "categories": [
            "Diversity & Inclusion",
            "Greek Member Experience",
            "GME - Diversity & Inclusion"
        ],
        "location": "Hank Ingram House Lobby",
        "description": "Join us for the opportunity to hear a panel of refugees and immigrants living in Nashville share some of the experiences they';ve had before and after moving to the US. Treats will be provided. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:45:00\">9:45 PM</span>)</b> <div>Location: <span class=\"location\">Belcourt Theatre</span></div> <div class=\"description\"><div class=\"article-meta\">\r\n<p class=\"article-information\"><strong>Dirs. Ewan McNicol and Anna Sandilands <span class=\"divider\">|</span>USA <span class=\"divider\">|</span>2017 <span class=\"divider\">|</span>82 min. <span class=\"divider\">|</span>NR <span class=\"divider\">|</span>DCP</strong></p>\r\n<p class=\"p1\"><strong><span class=\"s1\">Post-screening discussion with Jessica Griffith, Belcourt front of house manager and Harrison County, Texas native</span></strong></p>\r\n<div class=\"x_x_x_accessibility-item\"><strong>Participants&nbsp;who commit&nbsp;to checking in with the FLiCX administrator by no later than 6:55pm, and to remaining throught the post-screening discussion may RSVP in the right-hand column for tickets&nbsp;purchased by the Dean of Students office.&nbsp;</strong></div>\r\n<div class=\"x_x_x_accessibility-item\">&nbsp;</div>\r\n<div class=\"x_x_x_accessibility-item\"><em>Since seating is limited, we must remind participants of the following:</em></div>\r\n<div class=\"x_x_x_accessibility-item\">\r\n<div class=\"x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_accessibility-item\">\r\n<ul>\r\n<li><em>that if you RSVP in the affirmative, and your plans change, you are expected to log back in and change your status to \"not attending;\"</em></li>\r\n<li><em>that&nbsp;<strong>Vanderbilt participants&nbsp;must RSVP for themselves, and may not be \"guests;\"</strong></em></li>\r\n<li><em>and <strong>non-Vanderbilt guests are limited to one per participant.&nbsp;</strong></em></li>\r\n</ul>\r\n<p>Winner of Tribeca Film Festival&rsquo;s Albert Maysles Documentary Director Award, <strong><em>Uncertain</em></strong>&nbsp;is a visually stunning and disarmingly funny portrait of the literal and figurative troubled waters of Uncertain, TX. In a 94-resident town so tucked away &ldquo;you&rsquo;ve got to be lost to find it,&rdquo; three Uncertain men make their own bids for survival looking to find a more certain future. An ex-convict is obsessed with Mr. Ed, a gigantic boar he hunts in order to stay on the straight and narrow. A young idealist with big plans but few prospects is looking for a bigger life. An aging fisherman is learning to let go of his youthful ways, and making peace with a fateful moment thirty years ago. All the while Uncertain&rsquo;s vast, swampy lake is being choked by an aquatic weed, upsetting the natural balance and the town&rsquo;s only source of livelihood. From award-winning directors Ewan McNicol and Anna Sandilands, <em>Uncdrtain</em>&nbsp;is an outstanding feature debut capturing a vivid cast of characters as compelling as any fiction.</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"article-accessibility\">&nbsp;</div></div>",
        "title": "FLiCX: Uncertain",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:45:00\">9:45 PM</span>)</b> <div>Location: <span class=\"location\">Belcourt Theatre</span></div> <div class=\"description\"><div class=\"article-meta\">\r\n<p class=\"article-information\"><strong>Dirs. Ewan McNicol and Anna Sandilands <span class=\"divider\">|</span>USA <span class=\"divider\">|</span>2017 <span class=\"divider\">|</span>82 min. <span class=\"divider\">|</span>NR <span class=\"divider\">|</span>DCP</strong></p>\r\n<p class=\"p1\"><strong><span class=\"s1\">Post-screening discussion with Jessica Griffith, Belcourt front of house manager and Harrison County, Texas native</span></strong></p>\r\n<div class=\"x_x_x_accessibility-item\"><strong>Participants&nbsp;who commit&nbsp;to checking in with the FLiCX administrator by no later than 6:55pm, and to remaining throught the post-screening discussion may RSVP in the right-hand column for tickets&nbsp;purchased by the Dean of Students office.&nbsp;</strong></div>\r\n<div class=\"x_x_x_accessibility-item\">&nbsp;</div>\r\n<div class=\"x_x_x_accessibility-item\"><em>Since seating is limited, we must remind participants of the following:</em></div>\r\n<div class=\"x_x_x_accessibility-item\">\r\n<div class=\"x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_accessibility-item\">\r\n<ul>\r\n<li><em>that if you RSVP in the affirmative, and your plans change, you are expected to log back in and change your status to \"not attending;\"</em></li>\r\n<li><em>that&nbsp;<strong>Vanderbilt participants&nbsp;must RSVP for themselves, and may not be \"guests;\"</strong></em></li>\r\n<li><em>and <strong>non-Vanderbilt guests are limited to one per participant.&nbsp;</strong></em></li>\r\n</ul>\r\n<p>Winner of Tribeca Film Festival&rsquo;s Albert Maysles Documentary Director Award, <strong><em>Uncertain</em></strong>&nbsp;is a visually stunning and disarmingly funny portrait of the literal and figurative troubled waters of Uncertain, TX. In a 94-resident town so tucked away &ldquo;you&rsquo;ve got to be lost to find it,&rdquo; three Uncertain men make their own bids for survival looking to find a more certain future. An ex-convict is obsessed with Mr. Ed, a gigantic boar he hunts in order to stay on the straight and narrow. A young idealist with big plans but few prospects is looking for a bigger life. An aging fisherman is learning to let go of his youthful ways, and making peace with a fateful moment thirty years ago. All the while Uncertain&rsquo;s vast, swampy lake is being choked by an aquatic weed, upsetting the natural balance and the town&rsquo;s only source of livelihood. From award-winning directors Ewan McNicol and Anna Sandilands, <em>Uncdrtain</em>&nbsp;is an outstanding feature debut capturing a vivid cast of characters as compelling as any fiction.</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"article-accessibility\">&nbsp;</div></div>",
        "categories": [
            "Political",
            "Visual Arts",
            "Film/Movie",
            "Graduate/Professional Students",
            "Environmental/Sustainability"
        ],
        "location": "Belcourt Theatre",
        "description": "Dirs. Ewan McNicol and Anna Sandilands |USA |2017 |82 min. |NR |DCP Post-screening discussion with Jessica Griffith, Belcourt front of house manager and Harrison County, Texas native Participants ;who commit ;to checking in with the FLiCX administrator by no later than 6:55pm, and to remaining throught the post-screening discussion may RSVP in the right-hand column for tickets ;purchased by the Dean of Students office. ;  ; Since seating is limited, we must remind participants of the following: ---that if you RSVP in the affirmative, and your plans change, you are expected to log back in and change your status to \";not attending;\";  ---that ;Vanderbilt participants ;must RSVP for themselves, and may not be \";guests;\";  ---and non-Vanderbilt guests are limited to one per participant. ;  Winner of Tribeca Film Festival&#x2019;s Albert Maysles Documentary Director Award, Uncertain ;is a visually stunning and disarmingly funny portrait of the literal and figurative troubled waters of Uncertain, TX. In a 94-resident town so tucked away &#x201C;you&#x2019;ve got to be lost to find it,&#x201D; three Uncertain men make their own bids for survival looking to find a more certain future. An ex-convict is obsessed with Mr. Ed, a gigantic boar he hunts in order to stay on the straight and narrow. A young idealist with big plans but few prospects is looking for a bigger life. An aging fisherman is learning to let go of his youthful ways, and making peace with a fateful moment thirty years ago. All the while Uncertain&#x2019;s vast, swampy lake is being choked by an aquatic weed, upsetting the natural balance and the town&#x2019;s only source of livelihood. From award-winning directors Ewan McNicol and Anna Sandilands, Uncdrtain ;is an outstanding feature debut capturing a vivid cast of characters as compelling as any fiction.  ;  ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Martha Rivers Ingram Center for the Performing Arts</span></div> <div class=\"description\"><p>Vitality Dance Company invites its audience to party like it's the 1920's with a storytelling dance experience of F. Scott Fitzgerald's classic,&nbsp;<em>The Great Gatsby</em>.</p></div>",
        "title": "Vitality Dance Company presents: The Great Gatsby",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Martha Rivers Ingram Center for the Performing Arts</span></div> <div class=\"description\"><p>Vitality Dance Company invites its audience to party like it's the 1920's with a storytelling dance experience of F. Scott Fitzgerald's classic,&nbsp;<em>The Great Gatsby</em>.</p></div>",
        "categories": [
            "Performing Arts",
            "Greek Member Experience",
            "GME - Campus Involvement",
            "MVE - Arts Track",
            "My Vanderbilt Experience"
        ],
        "location": "Martha Rivers Ingram Center for the Performing Arts",
        "description": "Vitality Dance Company invites its audience to party like it';s the 1920';s with a storytelling dance experience of F. Scott Fitzgerald';s classic, ;The Great Gatsby. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Bridgestone Arena</span></div> <div class=\"description\"><p>The Super Social Committee invites you to join your classmates at the Nashville Predators Game on Thursday March 23rd vs. Calgary Flames. We will have 100 <strong>lower-bowl tickets</strong>, students who RSVP after this will be placed on a waiting list. The ticket will be $15 per person.&nbsp;</p></div>",
        "title": "Super Social Committee Presents: Nashville Predators game!",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Bridgestone Arena</span></div> <div class=\"description\"><p>The Super Social Committee invites you to join your classmates at the Nashville Predators Game on Thursday March 23rd vs. Calgary Flames. We will have 100 <strong>lower-bowl tickets</strong>, students who RSVP after this will be placed on a waiting list. The ticket will be $15 per person.&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Bridgestone Arena",
        "description": "The Super Social Committee invites you to join your classmates at the Nashville Predators Game on Thursday March 23rd vs. Calgary Flames. We will have 100 lower-bowl tickets, students who RSVP after this will be placed on a waiting list. The ticket will be $15 per person. ; "
    },
    {
        "time": "19:15:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">East MPR Vanderbilt WRC</span></div> <div class=\"description\"><p>Need to take a break from studying and wanna learn some cool dance moves?Come join us for Zumba with instructor Rachel Wilson!</p></div>",
        "title": "Dance like David Danced",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">East MPR Vanderbilt WRC</span></div> <div class=\"description\"><p>Need to take a break from studying and wanna learn some cool dance moves?Come join us for Zumba with instructor Rachel Wilson!</p></div>",
        "categories": [
            "Religious/Spiritual"
        ],
        "location": "East MPR Vanderbilt WRC",
        "description": "Need to take a break from studying and wanna learn some cool dance moves?Come join us for Zumba with instructor Rachel Wilson! "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\">Cancelled <br/><br/> <p>The Original Cast Spring Show</p></div>",
        "title": "The Original Cast Spring Show (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\">Cancelled <br/><br/> <p>The Original Cast Spring Show</p></div>",
        "categories": [
            "Performing Arts",
            "My Vanderbilt Experience",
            "MVE - Arts Track",
            "Greek Member Experience",
            "GME - Campus Involvement"
        ],
        "location": "Langford Auditorium",
        "description": "Cancelled  The Original Cast Spring Show "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Front of North House</span></div> <div class=\"description\"><p>This week for Northern Exposure we will be having a bonfire outside of North House!</p></div>",
        "title": "Northern Exposure (03/23)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Front of North House</span></div> <div class=\"description\"><p>This week for Northern Exposure we will be having a bonfire outside of North House!</p></div>",
        "categories": [],
        "location": "Front of North House",
        "description": "This week for Northern Exposure we will be having a bonfire outside of North House! "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-23",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">McGill TV Lounge</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Join us for Coffeehouse every Third Thursday! &nbsp; What to expect: An Open Mic! (sign up with the MC to perform) Poetry,&nbsp;Music, Short Stories,&nbsp;Comedy, etc. Coffee, Tea, and Free Food! &nbsp; Feel Free to Come and Go! Starts at 7:30 and Ends when it Ends :)</p></div>",
        "title": "McGill CoffeeHouse (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-23\">Thursday, March 23, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">McGill TV Lounge</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Join us for Coffeehouse every Third Thursday! &nbsp; What to expect: An Open Mic! (sign up with the MC to perform) Poetry,&nbsp;Music, Short Stories,&nbsp;Comedy, etc. Coffee, Tea, and Free Food! &nbsp; Feel Free to Come and Go! Starts at 7:30 and Ends when it Ends :)</p></div>",
        "categories": [],
        "location": "McGill TV Lounge",
        "description": "Cancelled  Join us for Coffeehouse every Third Thursday!  ; What to expect: An Open Mic! (sign up with the MC to perform) Poetry, ;Music, Short Stories, ;Comedy, etc. Coffee, Tea, and Free Food!  ; Feel Free to Come and Go! Starts at 7:30 and Ends when it Ends :) "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-24T07:00:00\">Friday, March 24, 2017 (7:00 AM)</span> - <span class=\"dtend\" title=\"2017-03-25T14:00:00\">Saturday, March 25, 2017 (2:00 PM)</span></b> <div>Location: <span class=\"location\">Chattanooga, TN to Nashville, TN</span></div> <div class=\"description\"><p>Have you ever wanted to run&nbsp;<em>really, really</em> far? A marathon? An ultra? Even better...a Ragnar!</p>\r\n<p>&nbsp;</p>\r\n<p>Join VMS as we run from <strong>Chattanooga to Nashville</strong> in the Tennessee Ragnar Relay!</p>\r\n<p>&nbsp;</p>\r\n<p>In just 2 days, we'll run across (part of) the beautiful state of Tennessee, with 12 runners, 2 vans, a lot of food, and hopefully some Febreeze.&nbsp;We'll take turns running while our compa&ntilde;eros rest, so that each runner only ends up taking 3 running shifts. One lucky runner only has to run 10.9 miles...and one luckier runners gets to run 23.1!<strong> <a href=\"https://www.runragnar.com/event-detail/relay/tennessee\">Check it out here!</a></strong></p>\r\n<p>&nbsp;</p>\r\n<p>As far as the time commitment is concerned, we'll likely need to drive to Chattanooga on Thursday night, since the race starts early Friday morning. We should get back to Nashville at some point in the day Saturday.</p>\r\n<p>&nbsp;</p>\r\n<p>We hope you'll join us! If you have any questions, please email Katy Anthony (kathleen.p.anthony@vanderbilt.edu). If you want to join, please sign up on <strong><a href=\"https://docs.google.com/spreadsheets/d/1I21k8e3qhm7bC_6iL2THNn1ErEuoWuiBrMfvrdyatnA/edit#gid=0\">this excel spreadsheet</a>&nbsp;--&nbsp;</strong>but sign up only if you're fairly committed to coming!</p></div>",
        "title": "VMS Runs the Ragnar!",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-24T07:00:00\">Friday, March 24, 2017 (7:00 AM)</span> - <span class=\"dtend\" title=\"2017-03-25T14:00:00\">Saturday, March 25, 2017 (2:00 PM)</span></b> <div>Location: <span class=\"location\">Chattanooga, TN to Nashville, TN</span></div> <div class=\"description\"><p>Have you ever wanted to run&nbsp;<em>really, really</em> far? A marathon? An ultra? Even better...a Ragnar!</p>\r\n<p>&nbsp;</p>\r\n<p>Join VMS as we run from <strong>Chattanooga to Nashville</strong> in the Tennessee Ragnar Relay!</p>\r\n<p>&nbsp;</p>\r\n<p>In just 2 days, we'll run across (part of) the beautiful state of Tennessee, with 12 runners, 2 vans, a lot of food, and hopefully some Febreeze.&nbsp;We'll take turns running while our compa&ntilde;eros rest, so that each runner only ends up taking 3 running shifts. One lucky runner only has to run 10.9 miles...and one luckier runners gets to run 23.1!<strong> <a href=\"https://www.runragnar.com/event-detail/relay/tennessee\">Check it out here!</a></strong></p>\r\n<p>&nbsp;</p>\r\n<p>As far as the time commitment is concerned, we'll likely need to drive to Chattanooga on Thursday night, since the race starts early Friday morning. We should get back to Nashville at some point in the day Saturday.</p>\r\n<p>&nbsp;</p>\r\n<p>We hope you'll join us! If you have any questions, please email Katy Anthony (kathleen.p.anthony@vanderbilt.edu). If you want to join, please sign up on <strong><a href=\"https://docs.google.com/spreadsheets/d/1I21k8e3qhm7bC_6iL2THNn1ErEuoWuiBrMfvrdyatnA/edit#gid=0\">this excel spreadsheet</a>&nbsp;--&nbsp;</strong>but sign up only if you're fairly committed to coming!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Chattanooga, TN to Nashville, TN",
        "description": "Have you ever wanted to run ;really, really far? A marathon? An ultra? Even better...a Ragnar!  ; Join VMS as we run from Chattanooga to Nashville in the Tennessee Ragnar Relay!  ; In just 2 days, we';ll run across (part of) the beautiful state of Tennessee, with 12 runners, 2 vans, a lot of food, and hopefully some Febreeze. ;We';ll take turns running while our compa&#xF1;eros rest, so that each runner only ends up taking 3 running shifts. One lucky runner only has to run 10.9 miles...and one luckier runners gets to run 23.1! [Check it out here!] (https://www.runragnar.com/event-detail/relay/tennessee)   ; As far as the time commitment is concerned, we';ll likely need to drive to Chattanooga on Thursday night, since the race starts early Friday morning. We should get back to Nashville at some point in the day Saturday.  ; We hope you';ll join us! If you have any questions, please email Katy Anthony (kathleen.p.anthony@vanderbilt.edu). If you want to join, please sign up on [this excel spreadsheet] (https://docs.google.com/spreadsheets/d/1I21k8e3qhm7bC_6iL2THNn1ErEuoWuiBrMfvrdyatnA/edit#gid=0)  ;-- ;but sign up only if you';re fairly committed to coming! "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Graduate/Professional Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "My Vanderbilt Experience",
            "MVE - Health & Wellness Track",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance</span></div> <div class=\"description\"><p>&ldquo;An Insider&rsquo;s Guide to Judicial Clerkships,&rdquo; a talk featuring Samiyyah Ali (&rsquo;16), Judicial Law Clerk to U.S. District Judge Amul Thapar (2016-17) and U.S. Circuit Judge Sri Srinivasan (2017-18).&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>A judicial&nbsp;clerkship&nbsp;is the job you never knew you needed.&nbsp; As a&nbsp;clerk, you're uniquely positioned at the right hand of a judge: managing cases, researching disputed legal issues, and drafting court opinions.&nbsp; You will also get an insider's look at what distinguishes the good lawyers from the bad ones.&nbsp; Whether you intend to pursue litigation or transactional work, you will walk into your first day at the firm, nonprofit, or government agency knowledgeable and prepared--because you will already know what the ultimate arbiter of all legal things is looking for. Come hear more about your future job.</p>\r\n<p>&nbsp;&nbsp;</p>\r\n<p>This event is free and open to the public.&nbsp; Lunch will be served.&nbsp; Co-sponsored by the Branstetter Program and the Judicial Clerkship Program.</p>\r\n<p>&nbsp;</p></div>",
        "title": "\"An Insider’s Guide to Judicial Clerkships,” a talk featuring Samiyyah Ali (’16), Judicial Law Clerk to U.S. District Judge Amul Thapar (2016-17) and U.S. Circuit Judge Sri Srinivasan (2017-18)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance</span></div> <div class=\"description\"><p>&ldquo;An Insider&rsquo;s Guide to Judicial Clerkships,&rdquo; a talk featuring Samiyyah Ali (&rsquo;16), Judicial Law Clerk to U.S. District Judge Amul Thapar (2016-17) and U.S. Circuit Judge Sri Srinivasan (2017-18).&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>A judicial&nbsp;clerkship&nbsp;is the job you never knew you needed.&nbsp; As a&nbsp;clerk, you're uniquely positioned at the right hand of a judge: managing cases, researching disputed legal issues, and drafting court opinions.&nbsp; You will also get an insider's look at what distinguishes the good lawyers from the bad ones.&nbsp; Whether you intend to pursue litigation or transactional work, you will walk into your first day at the firm, nonprofit, or government agency knowledgeable and prepared--because you will already know what the ultimate arbiter of all legal things is looking for. Come hear more about your future job.</p>\r\n<p>&nbsp;&nbsp;</p>\r\n<p>This event is free and open to the public.&nbsp; Lunch will be served.&nbsp; Co-sponsored by the Branstetter Program and the Judicial Clerkship Program.</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Law School"
        ],
        "location": "Renaissance",
        "description": "&#x201C;An Insider&#x2019;s Guide to Judicial Clerkships,&#x201D; a talk featuring Samiyyah Ali (&#x2019;16), Judicial Law Clerk to U.S. District Judge Amul Thapar (2016-17) and U.S. Circuit Judge Sri Srinivasan (2017-18). ;  ; A judicial ;clerkship ;is the job you never knew you needed. ; As a ;clerk, you';re uniquely positioned at the right hand of a judge: managing cases, researching disputed legal issues, and drafting court opinions. ; You will also get an insider';s look at what distinguishes the good lawyers from the bad ones. ; Whether you intend to pursue litigation or transactional work, you will walk into your first day at the firm, nonprofit, or government agency knowledgeable and prepared--because you will already know what the ultimate arbiter of all legal things is looking for. Come hear more about your future job.  ; ; This event is free and open to the public. ; Lunch will be served. ; Co-sponsored by the Branstetter Program and the Judicial Clerkship Program.  ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 411A-D</span></div> <div class=\"description\"><p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "title": "SNMA Health Disparities Week",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 411A-D</span></div> <div class=\"description\"><p>The Vanderbilt Chapter of the&nbsp;SNMA is pleased to invite you to the&nbsp;<strong><em>2017 Health Disparities Week</em></strong>. Every year, the&nbsp;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt&nbsp;a week of events centered on a variety of health disparities topics.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall Room 411A-D",
        "description": "The Vanderbilt Chapter of the ;SNMA is pleased to invite you to the ;2017 Health Disparities Week. Every year, the ;SNMA collaborates with multiple student groups on campus to bring to Vanderbilt ;a week of events centered on a variety of health disparities topics. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen School of Management</span></div> <div class=\"description\"><p>TBD</p></div>",
        "title": "Lunch & Learn",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen School of Management</span></div> <div class=\"description\"><p>TBD</p></div>",
        "categories": [],
        "location": "Owen School of Management",
        "description": "TBD "
    },
    {
        "time": "14:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:30:00\">3:30 PM</span>)</b> <div>Location: <span class=\"location\">SLC LL Room 3</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend <strong>Curricular Practical Training (CPT)</strong>&nbsp;and/or <strong>Optional Practical Training (OPT)</strong> workshops and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n<li>OPT is a 12-month employment authorization, related to a student&rsquo;s field of study, that can be used during or after academic studies are complete.</li>\r\n</ul>\r\n<p><em>Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services?</em></p>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT and/or OPT workshop will now be <u>required</u> before applying for employment authorization.&nbsp;</strong><strong><em>Spots are limited!</em></strong></p></div>",
        "title": "OPT Workshop",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:30:00\">3:30 PM</span>)</b> <div>Location: <span class=\"location\">SLC LL Room 3</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend <strong>Curricular Practical Training (CPT)</strong>&nbsp;and/or <strong>Optional Practical Training (OPT)</strong> workshops and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n<li>OPT is a 12-month employment authorization, related to a student&rsquo;s field of study, that can be used during or after academic studies are complete.</li>\r\n</ul>\r\n<p><em>Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services?</em></p>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT and/or OPT workshop will now be <u>required</u> before applying for employment authorization.&nbsp;</strong><strong><em>Spots are limited!</em></strong></p></div>",
        "categories": [
            "Career Development",
            "International"
        ],
        "location": "SLC LL Room 3",
        "description": "F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!! Have you ever thought about working off campus or interning for a company in the United States? Attend Curricular Practical Training (CPT) ;and/or Optional Practical Training (OPT) workshops and get the facts about how to apply for employment authorization. ---CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment. ;  ---OPT is a 12-month employment authorization, related to a student&#x2019;s field of study, that can be used during or after academic studies are complete.  Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services? Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States? These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall. ; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States. ; CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&#x2019;s, master&#x2019;s, doctoral). ; If you have an interest to work off campus, please sign up for the Spring ;workshops. ;Attendance at a CPT and/or OPT workshop will now be required before applying for employment authorization. ;Spots are limited! "
    },
    {
        "time": "15:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">McGill TV Lounge</span></div> <div class=\"description\"><p>Do you paint? Do you write? Dance, play, sing, or act? Or maybe you're looking to get inspired or express yourself? Then you should join Lambda and McGill to create both art and community!</p>\r\n<p>There will stations for writing and painting, as well as an open mic for sharing any work of art. We will also be hosting short, introductory workshops for anyone who wants to try something new!</p>\r\n<p>Suggested donation: $3. ALL money raised will be donated to the ACLU!</p>\r\n<p>Come destress and explore your creative side, while helping a great cause! Can't wait to see you there!</p></div>",
        "title": "Giving and Making: An Artistic Fundraiser",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">McGill TV Lounge</span></div> <div class=\"description\"><p>Do you paint? Do you write? Dance, play, sing, or act? Or maybe you're looking to get inspired or express yourself? Then you should join Lambda and McGill to create both art and community!</p>\r\n<p>There will stations for writing and painting, as well as an open mic for sharing any work of art. We will also be hosting short, introductory workshops for anyone who wants to try something new!</p>\r\n<p>Suggested donation: $3. ALL money raised will be donated to the ACLU!</p>\r\n<p>Come destress and explore your creative side, while helping a great cause! Can't wait to see you there!</p></div>",
        "categories": [],
        "location": "McGill TV Lounge",
        "description": "Do you paint? Do you write? Dance, play, sing, or act? Or maybe you';re looking to get inspired or express yourself? Then you should join Lambda and McGill to create both art and community! There will stations for writing and painting, as well as an open mic for sharing any work of art. We will also be hosting short, introductory workshops for anyone who wants to try something new! Suggested donation: $3. ALL money raised will be donated to the ACLU! Come destress and explore your creative side, while helping a great cause! Can';t wait to see you there! "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-24T18:00:00\">Friday, March 24, 2017 (6:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-25T19:00:00\">Saturday, March 25, 2017 (7:00 PM)</span></b> <div>Location: <span class=\"location\">Foster Falls near Chattanooga, TN</span></div> <div class=\"description\"><p>VMS Wilderness Medicine goes camping and rock climbing at Foster Falls!&nbsp;</p>\r\n<p>On Friday March 24th, VSMWM will take 12 students into the wilderness (read: 5 minutes off the highway) to camp for one night. Then on Saturday March 25th, VSMWM will take whomever survived the night to one TN's most famous bedrock climbing spots - FOSTER FALLS!! We will climb all morning, eat lunch, climb all afternoon, and head back to Nashville Saturday night (Chick-fil-A anyone?).</p>\r\n<p>Sign up is limited to 12 people only! Some rock climbing experience is recommended but you in no way need to be a professional - beginners welcome!&nbsp;Required gear for climbing includes rental shoes (available for rental from Vanderbilt Rec Center), harness, helmets, and appropriate clothing for variable weather. We hope to be able to use personal gear to outfit climbers with harnesses and helmets, but&nbsp;participants&nbsp;will need to rent their own shoes. Ropes, quickdraws, carabiners, belay devices, etc. will be supplied by trip leaders. Participants&nbsp;will also be responsible for bringing appropriate camping gear (ex. sleeping pads and sleeping bags.&nbsp;Tent not required). &nbsp;</p></div>",
        "title": "VMS Wilderness Medicine Camps and Climbs Foster Falls!",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-24T18:00:00\">Friday, March 24, 2017 (6:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-25T19:00:00\">Saturday, March 25, 2017 (7:00 PM)</span></b> <div>Location: <span class=\"location\">Foster Falls near Chattanooga, TN</span></div> <div class=\"description\"><p>VMS Wilderness Medicine goes camping and rock climbing at Foster Falls!&nbsp;</p>\r\n<p>On Friday March 24th, VSMWM will take 12 students into the wilderness (read: 5 minutes off the highway) to camp for one night. Then on Saturday March 25th, VSMWM will take whomever survived the night to one TN's most famous bedrock climbing spots - FOSTER FALLS!! We will climb all morning, eat lunch, climb all afternoon, and head back to Nashville Saturday night (Chick-fil-A anyone?).</p>\r\n<p>Sign up is limited to 12 people only! Some rock climbing experience is recommended but you in no way need to be a professional - beginners welcome!&nbsp;Required gear for climbing includes rental shoes (available for rental from Vanderbilt Rec Center), harness, helmets, and appropriate clothing for variable weather. We hope to be able to use personal gear to outfit climbers with harnesses and helmets, but&nbsp;participants&nbsp;will need to rent their own shoes. Ropes, quickdraws, carabiners, belay devices, etc. will be supplied by trip leaders. Participants&nbsp;will also be responsible for bringing appropriate camping gear (ex. sleeping pads and sleeping bags.&nbsp;Tent not required). &nbsp;</p></div>",
        "categories": [],
        "location": "Foster Falls near Chattanooga, TN",
        "description": "VMS Wilderness Medicine goes camping and rock climbing at Foster Falls! ; On Friday March 24th, VSMWM will take 12 students into the wilderness (read: 5 minutes off the highway) to camp for one night. Then on Saturday March 25th, VSMWM will take whomever survived the night to one TN';s most famous bedrock climbing spots - FOSTER FALLS!! We will climb all morning, eat lunch, climb all afternoon, and head back to Nashville Saturday night (Chick-fil-A anyone?). Sign up is limited to 12 people only! Some rock climbing experience is recommended but you in no way need to be a professional - beginners welcome! ;Required gear for climbing includes rental shoes (available for rental from Vanderbilt Rec Center), harness, helmets, and appropriate clothing for variable weather. We hope to be able to use personal gear to outfit climbers with harnesses and helmets, but ;participants ;will need to rent their own shoes. Ropes, quickdraws, carabiners, belay devices, etc. will be supplied by trip leaders. Participants ;will also be responsible for bringing appropriate camping gear (ex. sleeping pads and sleeping bags. ;Tent not required).  ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Art Studios (Behind Last Drop Coffee Shop)</span></div> <div class=\"description\"><p>If you love getting messy, this week's creation station is for you. One of our instructors will be leading an \"intro to the wheel\"&nbsp;workshop in the clay studio. Participants will get to try their hand on the potter's wheel and get to choose a glaze for their finished piece. Be sure to arrive on time and wear clothes that can get dirty!</p>\r\n<p>All students are welcome, but classes fill up fast. Sign up on anchorlink today to reserve a spot. NO PLUS ONES PLEASE!</p>\r\n<p>&nbsp;</p></div>",
        "title": "Creation Station - Intro to the Wheel",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Art Studios (Behind Last Drop Coffee Shop)</span></div> <div class=\"description\"><p>If you love getting messy, this week's creation station is for you. One of our instructors will be leading an \"intro to the wheel\"&nbsp;workshop in the clay studio. Participants will get to try their hand on the potter's wheel and get to choose a glaze for their finished piece. Be sure to arrive on time and wear clothes that can get dirty!</p>\r\n<p>All students are welcome, but classes fill up fast. Sign up on anchorlink today to reserve a spot. NO PLUS ONES PLEASE!</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Visual Arts"
        ],
        "location": "Sarratt Art Studios (Behind Last Drop Coffee Shop)",
        "description": "If you love getting messy, this week';s creation station is for you. One of our instructors will be leading an \";intro to the wheel\"; ;workshop in the clay studio. Participants will get to try their hand on the potter';s wheel and get to choose a glaze for their finished piece. Be sure to arrive on time and wear clothes that can get dirty! All students are welcome, but classes fill up fast. Sign up on anchorlink today to reserve a spot. NO PLUS ONES PLEASE!  ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Art Studios (Behind Last Drop Coffee Shop)</span></div> <div class=\"description\"><p>This Creation Station takes card making to the next level. In this instructor-led workshop, participants will receive a short watercolor lesson and have the opportunity to create a unique set of greeting cards.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>All students are welcome, but classes fill up fast. Sign up on anchorlink to reserve a spot. No \"plus ones\" please!</p>\r\n<p>&nbsp;</p></div>",
        "title": "Creation Station - Card Making with Watercolor",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Art Studios (Behind Last Drop Coffee Shop)</span></div> <div class=\"description\"><p>This Creation Station takes card making to the next level. In this instructor-led workshop, participants will receive a short watercolor lesson and have the opportunity to create a unique set of greeting cards.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>All students are welcome, but classes fill up fast. Sign up on anchorlink to reserve a spot. No \"plus ones\" please!</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Visual Arts"
        ],
        "location": "Sarratt Art Studios (Behind Last Drop Coffee Shop)",
        "description": "This Creation Station takes card making to the next level. In this instructor-led workshop, participants will receive a short watercolor lesson and have the opportunity to create a unique set of greeting cards. ;  ; All students are welcome, but classes fill up fast. Sign up on anchorlink to reserve a spot. No \";plus ones\"; please!  ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt School of Medicine</span></div> <div class=\"description\"><p>Join the Child Neurology Interest Group for our post-match meeting to learn more about the Child Neurology match process, tips for the interview trail, and general advice for preparation! We hope to see you there!</p>\r\n<p>&nbsp;</p>\r\n<p>Food and drinks will be provided.</p></div>",
        "title": "CiM Child Neurology Interest Group: Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt School of Medicine</span></div> <div class=\"description\"><p>Join the Child Neurology Interest Group for our post-match meeting to learn more about the Child Neurology match process, tips for the interview trail, and general advice for preparation! We hope to see you there!</p>\r\n<p>&nbsp;</p>\r\n<p>Food and drinks will be provided.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Vanderbilt School of Medicine",
        "description": "Join the Child Neurology Interest Group for our post-match meeting to learn more about the Child Neurology match process, tips for the interview trail, and general advice for preparation! We hope to see you there!  ; Food and drinks will be provided. "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 407 C-D</span></div> <div class=\"description\"><p>Join the Otolaryngology/ENT interest group and our recently-matched 4th years as we discuss choosing otolaryngology, the application process, interviews, and the match! Dinner and drinks will be provided!</p></div>",
        "title": "CIM Otolaryngology/ENT Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 407 C-D</span></div> <div class=\"description\"><p>Join the Otolaryngology/ENT interest group and our recently-matched 4th years as we discuss choosing otolaryngology, the application process, interviews, and the match! Dinner and drinks will be provided!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall 407 C-D",
        "description": "Join the Otolaryngology/ENT interest group and our recently-matched 4th years as we discuss choosing otolaryngology, the application process, interviews, and the match! Dinner and drinks will be provided! "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-24T19:00:00\">Friday, March 24, 2017 (7:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-24T23:00:00\">Friday, March 24, 2017 (11:00 PM)</span></b> <div>Location: <span class=\"location\">Student Life Center </span></div> <div class=\"description\"><p>With the goal of bringing Nashville to the SLC, VPB's The VenUe Committee gathers together four sections of Music City--Broadway, 12th South, East Nashville, and Berryhill. We have classic favorites like hot chicken, a mechanical bull, and live music, but also aim to share the parts of Nashville that are lesser known here at Vanderbilt--comedy acts and new restaurants, among other things. Come on out to Nash Bash for lots of fun, food, and other free things!</p></div>",
        "title": "Nash Bash!",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-24T19:00:00\">Friday, March 24, 2017 (7:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-24T23:00:00\">Friday, March 24, 2017 (11:00 PM)</span></b> <div>Location: <span class=\"location\">Student Life Center </span></div> <div class=\"description\"><p>With the goal of bringing Nashville to the SLC, VPB's The VenUe Committee gathers together four sections of Music City--Broadway, 12th South, East Nashville, and Berryhill. We have classic favorites like hot chicken, a mechanical bull, and live music, but also aim to share the parts of Nashville that are lesser known here at Vanderbilt--comedy acts and new restaurants, among other things. Come on out to Nash Bash for lots of fun, food, and other free things!</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - Dores After Dark Track",
            "Alcohol Free Late Night Programming"
        ],
        "location": "Student Life Center ",
        "description": "With the goal of bringing Nashville to the SLC, VPB';s The VenUe Committee gathers together four sections of Music City--Broadway, 12th South, East Nashville, and Berryhill. We have classic favorites like hot chicken, a mechanical bull, and live music, but also aim to share the parts of Nashville that are lesser known here at Vanderbilt--comedy acts and new restaurants, among other things. Come on out to Nash Bash for lots of fun, food, and other free things! "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Rand 308</span></div> <div class=\"description\"><p><font color=\"#000000\" face=\"arial\">Come Vibe with VOP after our choir practice. We'll have food, games, karaoke, and sweet prizes!</font></p>\r\n<p>&nbsp;</p></div>",
        "title": "Melodies from Heaven",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Rand 308</span></div> <div class=\"description\"><p><font color=\"#000000\" face=\"arial\">Come Vibe with VOP after our choir practice. We'll have food, games, karaoke, and sweet prizes!</font></p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Religious/Spiritual"
        ],
        "location": "Rand 308",
        "description": "Come Vibe with VOP after our choir practice. We';ll have food, games, karaoke, and sweet prizes!  ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">DNR</span></div> <div class=\"description\"><p>Variations will perform with VIBE at VPAC's Fourth Friday Event</p></div>",
        "title": "Variations at Fourth Fridays",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">DNR</span></div> <div class=\"description\"><p>Variations will perform with VIBE at VPAC's Fourth Friday Event</p></div>",
        "categories": [],
        "location": "DNR",
        "description": "Variations will perform with VIBE at VPAC';s Fourth Friday Event "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-24T19:00:00\">Friday, March 24, 2017 (7:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-24T23:45:00\">Friday, March 24, 2017 (11:45 PM)</span></b> <div>Location: <span class=\"location\">Buttrick 301/302</span></div> <div class=\"description\"><p>Come join Vanderbilt Gamecraft as we collaborate with the Vanderbilt Association of Introverts to host a night devoted to board game play! There will be a wide array of games to choose from. Whether you're feeling a nice co-op to play with friends or a single-player survival simulator, we got all the games to to make the night rich with entertainment. Hope to see you there!</p></div>",
        "title": "Vanderbilt Gamecraft/Vanderbilt Association of Introverts Collaboration",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-24T19:00:00\">Friday, March 24, 2017 (7:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-24T23:45:00\">Friday, March 24, 2017 (11:45 PM)</span></b> <div>Location: <span class=\"location\">Buttrick 301/302</span></div> <div class=\"description\"><p>Come join Vanderbilt Gamecraft as we collaborate with the Vanderbilt Association of Introverts to host a night devoted to board game play! There will be a wide array of games to choose from. Whether you're feeling a nice co-op to play with friends or a single-player survival simulator, we got all the games to to make the night rich with entertainment. Hope to see you there!</p></div>",
        "categories": [],
        "location": "Buttrick 301/302",
        "description": "Come join Vanderbilt Gamecraft as we collaborate with the Vanderbilt Association of Introverts to host a night devoted to board game play! There will be a wide array of games to choose from. Whether you';re feeling a nice co-op to play with friends or a single-player survival simulator, we got all the games to to make the night rich with entertainment. Hope to see you there! "
    },
    {
        "time": "19:30:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Buttrick 101</span></div> <div class=\"description\"><p>Movies that Matter, Environmental Stewardship and Justice, and Project: Bridges will host a screening of \"Climate Refugees\" and a dialogue on one of the great global challenges of our generation. Climate change, by bringing more droughts, natural disasters, and famines, are already driving millions upon millions from their homes. It will be our moral obligation to help these people fleeing environmental degradation, thirst, and starvation, and we should begin to educate ourselves on this critical issue as soon as possible.&nbsp;</p></div>",
        "title": "Climate Refugeeism--The Next Global Crisis",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Buttrick 101</span></div> <div class=\"description\"><p>Movies that Matter, Environmental Stewardship and Justice, and Project: Bridges will host a screening of \"Climate Refugees\" and a dialogue on one of the great global challenges of our generation. Climate change, by bringing more droughts, natural disasters, and famines, are already driving millions upon millions from their homes. It will be our moral obligation to help these people fleeing environmental degradation, thirst, and starvation, and we should begin to educate ourselves on this critical issue as soon as possible.&nbsp;</p></div>",
        "categories": [
            "Political",
            "Environmental/Sustainability",
            "Film/Movie",
            "GME - Diversity & Inclusion",
            "Greek Member Experience",
            "International",
            "Academic"
        ],
        "location": "Buttrick 101",
        "description": "Movies that Matter, Environmental Stewardship and Justice, and Project: Bridges will host a screening of \";Climate Refugees\"; and a dialogue on one of the great global challenges of our generation. Climate change, by bringing more droughts, natural disasters, and famines, are already driving millions upon millions from their homes. It will be our moral obligation to help these people fleeing environmental degradation, thirst, and starvation, and we should begin to educate ourselves on this critical issue as soon as possible. ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-24",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>The Original Cast's Spring Show, As Years Go By, is a musical revue comprised of songs from musicals such as Chicago, Avenue Q, Shrek The Musical, and Waitress. The show follows an ambitious writer, Casey, growing up and learning to live in the moment. Come laugh with us as Casey navigates the frustrations of childhood, the embarrassment of puberty, the terror of starting college, and the stresses of adulthood.</p></div>",
        "title": "As Years Go By",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-24\">Friday, March 24, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>The Original Cast's Spring Show, As Years Go By, is a musical revue comprised of songs from musicals such as Chicago, Avenue Q, Shrek The Musical, and Waitress. The show follows an ambitious writer, Casey, growing up and learning to live in the moment. Come laugh with us as Casey navigates the frustrations of childhood, the embarrassment of puberty, the terror of starting college, and the stresses of adulthood.</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Langford Auditorium",
        "description": "The Original Cast';s Spring Show, As Years Go By, is a musical revue comprised of songs from musicals such as Chicago, Avenue Q, Shrek The Musical, and Waitress. The show follows an ambitious writer, Casey, growing up and learning to live in the moment. Come laugh with us as Casey navigates the frustrations of childhood, the embarrassment of puberty, the terror of starting college, and the stresses of adulthood. "
    },
    {
        "time": "09:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Adventure Science Center</span></div> <div class=\"description\"><p>Demos will be provided to teach attendees of the ASC information about Nanoscale sizes and properties.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>Lunch will be provided.</p></div>",
        "title": "NanoDay at Adventure Science Center",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Adventure Science Center</span></div> <div class=\"description\"><p>Demos will be provided to teach attendees of the ASC information about Nanoscale sizes and properties.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>Lunch will be provided.</p></div>",
        "categories": [],
        "location": "Adventure Science Center",
        "description": "Demos will be provided to teach attendees of the ASC information about Nanoscale sizes and properties. ;  ; Lunch will be provided. "
    },
    {
        "time": "09:45:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:45:00\">9:45 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Outdoor Track</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Come out to the only HOME Outdoor Track Meet!&nbsp;</p></div>",
        "title": "Vanderbilt Outdoor Track & Field  (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:45:00\">9:45 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Outdoor Track</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Come out to the only HOME Outdoor Track Meet!&nbsp;</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - School Spirit Track",
            "GME - Campus Involvement",
            "Greek Member Experience"
        ],
        "location": "Outdoor Track",
        "description": "Cancelled  Come out to the only HOME Outdoor Track Meet! ; "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Magnolia Lawn, Vanderbilt University</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Want to support a great cause while benefitting your own fitness?! Come support&nbsp;kids affected by their parent's cancer on March 25th at the Camp Kesem Color Run! In addition to a color-filled 5k around campus, we will have free T-shirts, entertainment, and food &amp;&nbsp;drinks for after the event. All proceeds from ticket sales go to Camp Kesem at Vanderbilt, an organization that provides a free week of summer camp to kids whose parents have or have had cancer. See you there!</p></div>",
        "title": "Camp Kesem Color Run (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Magnolia Lawn, Vanderbilt University</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Want to support a great cause while benefitting your own fitness?! Come support&nbsp;kids affected by their parent's cancer on March 25th at the Camp Kesem Color Run! In addition to a color-filled 5k around campus, we will have free T-shirts, entertainment, and food &amp;&nbsp;drinks for after the event. All proceeds from ticket sales go to Camp Kesem at Vanderbilt, an organization that provides a free week of summer camp to kids whose parents have or have had cancer. See you there!</p></div>",
        "categories": [
            "Service & Philanthropy",
            "Health & Wellness"
        ],
        "location": "Magnolia Lawn, Vanderbilt University",
        "description": "Cancelled  Want to support a great cause while benefitting your own fitness?! Come support ;kids affected by their parent';s cancer on March 25th at the Camp Kesem Color Run! In addition to a color-filled 5k around campus, we will have free T-shirts, entertainment, and food &; ;drinks for after the event. All proceeds from ticket sales go to Camp Kesem at Vanderbilt, an organization that provides a free week of summer camp to kids whose parents have or have had cancer. See you there! "
    },
    {
        "time": "11:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Currey Lawn</span></div> <div class=\"description\"><p>The Entertainment and Sports Law Society is hosting its annual decathlon. This (largely non-athletic) decathlon is a fun event all for a good cause. Teams of four will compete against each other in the decathlon events for prizes. All proceeds from the team member entrance fees will go towards Volunteer Lawyers and Professionals for the Arts, a local organization housed at Belmont University.</p></div>",
        "title": "ESLS Annual Decathlon",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Currey Lawn</span></div> <div class=\"description\"><p>The Entertainment and Sports Law Society is hosting its annual decathlon. This (largely non-athletic) decathlon is a fun event all for a good cause. Teams of four will compete against each other in the decathlon events for prizes. All proceeds from the team member entrance fees will go towards Volunteer Lawyers and Professionals for the Arts, a local organization housed at Belmont University.</p></div>",
        "categories": [
            "Service & Philanthropy",
            "Law School"
        ],
        "location": "Currey Lawn",
        "description": "The Entertainment and Sports Law Society is hosting its annual decathlon. This (largely non-athletic) decathlon is a fun event all for a good cause. Teams of four will compete against each other in the decathlon events for prizes. All proceeds from the team member entrance fees will go towards Volunteer Lawyers and Professionals for the Arts, a local organization housed at Belmont University. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:30:00\">2:30 PM</span>)</b> <div>Location: <span class=\"location\">Soccer/Lacrosse Field </span></div> <div class=\"description\"><p>Come out and support your fellow Commodores at the lacrosse game!&nbsp;</p></div>",
        "title": "Vanderbilt Lacrosse vs. Butler",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:30:00\">2:30 PM</span>)</b> <div>Location: <span class=\"location\">Soccer/Lacrosse Field </span></div> <div class=\"description\"><p>Come out and support your fellow Commodores at the lacrosse game!&nbsp;</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - School Spirit Track",
            "GME - Campus Involvement",
            "Greek Member Experience",
            "Athletics"
        ],
        "location": "Soccer/Lacrosse Field ",
        "description": "Come out and support your fellow Commodores at the lacrosse game! ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill 136</span></div> <div class=\"description\"><p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Hosted by the organization, Vandy_LAN, Vandy_LAN VII is Vanderbilts premier gaming experience. It offers more than just game tournaments. It features raffle prizes, food, drinks, and a plethora of games to compete in or just play casually. The event usually has 500 people come and enjoy each semester, so you won't want to miss it. Vandy SMASH will be there as well to put on tournaments for Smash 4 and Melee. These games alone bring in many outside players, averaging 80 entrants each semester. Vandy students get in free and non-vandy people only pay a small price for access to of the event's amenities.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:769,&quot;3&quot;:{&quot;1&quot;:0},&quot;11&quot;:4,&quot;12&quot;:0}\">Hosted by the organization, Vandy_LAN, Vandy_LAN VII is Vanderbilts premier gaming experience. It offers more than just game tournaments. It features raffle prizes, food, drinks, and a plethora of games to compete in or just play casually. The event usually has 500 people come and enjoy each semester, so you won't want to miss it. Vandy SMASH will be there as well to put on tournaments for Smash 4 and Melee. These games alone bring in many outside players, averaging 80 entrants each semester. Vandy students get in free and non-vandy attendees only pay a small price for access to all of the event's amenities.</span></p></div>",
        "title": "SMASH @ Vandy_LAN VII",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill 136</span></div> <div class=\"description\"><p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Hosted by the organization, Vandy_LAN, Vandy_LAN VII is Vanderbilts premier gaming experience. It offers more than just game tournaments. It features raffle prizes, food, drinks, and a plethora of games to compete in or just play casually. The event usually has 500 people come and enjoy each semester, so you won't want to miss it. Vandy SMASH will be there as well to put on tournaments for Smash 4 and Melee. These games alone bring in many outside players, averaging 80 entrants each semester. Vandy students get in free and non-vandy people only pay a small price for access to of the event's amenities.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:769,&quot;3&quot;:{&quot;1&quot;:0},&quot;11&quot;:4,&quot;12&quot;:0}\">Hosted by the organization, Vandy_LAN, Vandy_LAN VII is Vanderbilts premier gaming experience. It offers more than just game tournaments. It features raffle prizes, food, drinks, and a plethora of games to compete in or just play casually. The event usually has 500 people come and enjoy each semester, so you won't want to miss it. Vandy SMASH will be there as well to put on tournaments for Smash 4 and Melee. These games alone bring in many outside players, averaging 80 entrants each semester. Vandy students get in free and non-vandy attendees only pay a small price for access to all of the event's amenities.</span></p></div>",
        "categories": [
            "Performing Arts",
            "Diversity & Inclusion",
            "Athletics",
            "Visual Arts",
            "Religious/Spiritual"
        ],
        "location": "Featheringill 136",
        "description": "Hosted by the organization, Vandy_LAN, Vandy_LAN VII is Vanderbilts premier gaming experience. It offers more than just game tournaments. It features raffle prizes, food, drinks, and a plethora of games to compete in or just play casually. The event usually has 500 people come and enjoy each semester, so you won';t want to miss it. Vandy SMASH will be there as well to put on tournaments for Smash 4 and Melee. These games alone bring in many outside players, averaging 80 entrants each semester. Vandy students get in free and non-vandy attendees only pay a small price for access to all of the event';s amenities. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation & Wellness Center</span></div> <div class=\"description\"><p>Our annual philanthropy event benefiting Taylor Trudeau Cycle for Life which uses its proceeds to support Leukemia research.</p></div>",
        "title": "Cycle for Life",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation & Wellness Center</span></div> <div class=\"description\"><p>Our annual philanthropy event benefiting Taylor Trudeau Cycle for Life which uses its proceeds to support Leukemia research.</p></div>",
        "categories": [
            "Athletics",
            "Service & Philanthropy",
            "Fraternity (For Organizations Advised by Greek Life)"
        ],
        "location": "Vanderbilt Recreation & Wellness Center",
        "description": "Our annual philanthropy event benefiting Taylor Trudeau Cycle for Life which uses its proceeds to support Leukemia research. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Alpha Omicron Pi House</span></div> <div class=\"description\"><p>Strike Out Arthritis is AOII's annual fundraising event that raises money for our national philanthropy, The Arthritis Foundation.&nbsp;There will be games for competition including field games and corn hole, and food for guests.</p></div>",
        "title": "Strike Out Arthritis",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Alpha Omicron Pi House</span></div> <div class=\"description\"><p>Strike Out Arthritis is AOII's annual fundraising event that raises money for our national philanthropy, The Arthritis Foundation.&nbsp;There will be games for competition including field games and corn hole, and food for guests.</p></div>",
        "categories": [
            "Sorority (For Organizations Advised by Greek Life)"
        ],
        "location": "Alpha Omicron Pi House",
        "description": "Strike Out Arthritis is AOII';s annual fundraising event that raises money for our national philanthropy, The Arthritis Foundation. ;There will be games for competition including field games and corn hole, and food for guests. "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-25T14:00:00\">Saturday, March 25, 2017 (2:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-25T23:59:00\">Saturday, March 25, 2017 (11:59 PM)</span></b> <div>Location: <span class=\"location\">Featheringill Hall</span></div> <div class=\"description\"><p>Vandy_LAN is a biannual <span class=\"x_il\">gaming</span> convention, providing tournaments, food, and awesome prizes to <span class=\"x_il\">Vanderbilt</span> students. The event serves as a alcohol-free, community-building experience for students to bond over a shared interest in <span class=\"x_il\">gaming</span>. We provide free food and free prizes for all attendees.</p></div>",
        "title": "Vandy_LAN VII",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-25T14:00:00\">Saturday, March 25, 2017 (2:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-25T23:59:00\">Saturday, March 25, 2017 (11:59 PM)</span></b> <div>Location: <span class=\"location\">Featheringill Hall</span></div> <div class=\"description\"><p>Vandy_LAN is a biannual <span class=\"x_il\">gaming</span> convention, providing tournaments, food, and awesome prizes to <span class=\"x_il\">Vanderbilt</span> students. The event serves as a alcohol-free, community-building experience for students to bond over a shared interest in <span class=\"x_il\">gaming</span>. We provide free food and free prizes for all attendees.</p></div>",
        "categories": [
            "Alcohol Free Late Night Programming",
            "Visual Arts",
            "MVE - Dores After Dark Track",
            "My Vanderbilt Experience"
        ],
        "location": "Featheringill Hall",
        "description": "Vandy_LAN is a biannual gaming convention, providing tournaments, food, and awesome prizes to Vanderbilt students. The event serves as a alcohol-free, community-building experience for students to bond over a shared interest in gaming. We provide free food and free prizes for all attendees. "
    },
    {
        "time": "14:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>Join LTA at the Multicultural Leadership Council's \"InVUsion\" Celebration!</p></div>",
        "title": "LTA at InVUsion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>Join LTA at the Multicultural Leadership Council's \"InVUsion\" Celebration!</p></div>",
        "categories": [],
        "location": "Alumni Lawn",
        "description": "Join LTA at the Multicultural Leadership Council';s \";InVUsion\"; Celebration! "
    },
    {
        "time": "15:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>MLC's capstone event, InVUsion, is a massive multicultural festival that highlights the MLC organizations' missions, cultures and performances. With free food from over 20 ethnic restaurants across Nashville, a performance competition featuring the best dances from cultural showcases throughout the year (Diwali, Cafe Con Leche, Asian New Year Festival, Harambe), and booths hosted by MLC organizations educating attendees on culture, this is one of the biggest events of the spring. Learning outcomes: Students will experience through ethnic food, dances, and performances, a variety of cultures from around the world and have a better understanding and increased appreciation of the said cultures.</p></div>",
        "title": "InVUsion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>MLC's capstone event, InVUsion, is a massive multicultural festival that highlights the MLC organizations' missions, cultures and performances. With free food from over 20 ethnic restaurants across Nashville, a performance competition featuring the best dances from cultural showcases throughout the year (Diwali, Cafe Con Leche, Asian New Year Festival, Harambe), and booths hosted by MLC organizations educating attendees on culture, this is one of the biggest events of the spring. Learning outcomes: Students will experience through ethnic food, dances, and performances, a variety of cultures from around the world and have a better understanding and increased appreciation of the said cultures.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - Cultural Awareness Track",
            "GME - Diversity & Inclusion",
            "Greek Member Experience",
            "Diversity & Inclusion"
        ],
        "location": "Alumni Lawn",
        "description": "MLC';s capstone event, InVUsion, is a massive multicultural festival that highlights the MLC organizations'; missions, cultures and performances. With free food from over 20 ethnic restaurants across Nashville, a performance competition featuring the best dances from cultural showcases throughout the year (Diwali, Cafe Con Leche, Asian New Year Festival, Harambe), and booths hosted by MLC organizations educating attendees on culture, this is one of the biggest events of the spring. Learning outcomes: Students will experience through ethnic food, dances, and performances, a variety of cultures from around the world and have a better understanding and increased appreciation of the said cultures. "
    },
    {
        "time": "15:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>Variations will post with Momentum for a VPAC collaboration at InVUsion</p></div>",
        "title": "Variations at InVUsion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>Variations will post with Momentum for a VPAC collaboration at InVUsion</p></div>",
        "categories": [],
        "location": "Alumni Lawn",
        "description": "Variations will post with Momentum for a VPAC collaboration at InVUsion "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-25T18:00:00\">Saturday, March 25, 2017 (6:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-25T23:45:00\">Saturday, March 25, 2017 (11:45 PM)</span></b> <div>Location: <span class=\"location\">Featheringill (Atrium)</span></div> <div class=\"description\"><p>Come join Vanderbilt's Gamecraft as we collaborate with Vandy_LAN's 7th major gaming event. There will be multiple video games tournaments, a wide variety of board games to play, and Gamecraft's own board game tournament! Celebrate the weekend with this amazing culmination of gaming!</p></div>",
        "title": "Vanderbilt Gamecraft/Vandy_LAN Collaboration",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-25T18:00:00\">Saturday, March 25, 2017 (6:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-25T23:45:00\">Saturday, March 25, 2017 (11:45 PM)</span></b> <div>Location: <span class=\"location\">Featheringill (Atrium)</span></div> <div class=\"description\"><p>Come join Vanderbilt's Gamecraft as we collaborate with Vandy_LAN's 7th major gaming event. There will be multiple video games tournaments, a wide variety of board games to play, and Gamecraft's own board game tournament! Celebrate the weekend with this amazing culmination of gaming!</p></div>",
        "categories": [],
        "location": "Featheringill (Atrium)",
        "description": "Come join Vanderbilt';s Gamecraft as we collaborate with Vandy_LAN';s 7th major gaming event. There will be multiple video games tournaments, a wide variety of board games to play, and Gamecraft';s own board game tournament! Celebrate the weekend with this amazing culmination of gaming! "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-25T18:00:00\">Saturday, March 25, 2017 (6:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-26T00:15:00\">Sunday, March 26, 2017 (12:15 AM)</span></b> <div>Location: <span class=\"location\">VWRC Field House</span></div> <div class=\"description\"><p>Join us at our RESCHEDULED Big Event as we celebrate the culmination of Vanderbilt University Dance Marathon's 15th year with guest performers, games, food, and of course, dancing! &nbsp;Vanderbilt University Dance Marathon (VUDM) is Vanderbilt's largest student-run philanthropic organization, bringing in over $2 million in the last 15 years all for Monroe Carell Jr. Children's Hospital at Vanderbilt. &nbsp;Everything we do, we do FTK- For The Kids! &nbsp;We are so excited to&nbsp;<em>finally&nbsp;</em>be able to celebrate all of this year's hard work after a short postponement... we're back!&nbsp;</p></div>",
        "title": "Dance Marathon 2017: The Big Event 2.0 ... BIGGER & BETTER!",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-25T18:00:00\">Saturday, March 25, 2017 (6:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-26T00:15:00\">Sunday, March 26, 2017 (12:15 AM)</span></b> <div>Location: <span class=\"location\">VWRC Field House</span></div> <div class=\"description\"><p>Join us at our RESCHEDULED Big Event as we celebrate the culmination of Vanderbilt University Dance Marathon's 15th year with guest performers, games, food, and of course, dancing! &nbsp;Vanderbilt University Dance Marathon (VUDM) is Vanderbilt's largest student-run philanthropic organization, bringing in over $2 million in the last 15 years all for Monroe Carell Jr. Children's Hospital at Vanderbilt. &nbsp;Everything we do, we do FTK- For The Kids! &nbsp;We are so excited to&nbsp;<em>finally&nbsp;</em>be able to celebrate all of this year's hard work after a short postponement... we're back!&nbsp;</p></div>",
        "categories": [
            "Service & Philanthropy",
            "Greek Member Experience",
            "GME - Community Impact",
            "MVE - Service & Civic Engagement Track",
            "My Vanderbilt Experience"
        ],
        "location": "VWRC Field House",
        "description": "Join us at our RESCHEDULED Big Event as we celebrate the culmination of Vanderbilt University Dance Marathon';s 15th year with guest performers, games, food, and of course, dancing!  ;Vanderbilt University Dance Marathon (VUDM) is Vanderbilt';s largest student-run philanthropic organization, bringing in over $2 million in the last 15 years all for Monroe Carell Jr. Children';s Hospital at Vanderbilt.  ;Everything we do, we do FTK- For The Kids!  ;We are so excited to ;finally ;be able to celebrate all of this year';s hard work after a short postponement... we';re back! ; "
    },
    {
        "time": "18:45:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:45:00\">6:45 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom </span></div> <div class=\"description\"><p>This year the Vanderbilt Public Relations Society is hosting our 8th annual Scene &amp; Heard Fashion Show on March 25, 2017 in the Student Life Center at 6:45pm. All proceeds will be donated to The Mary Parrish Center, a cherished organization held in high regard &nbsp;by the Vanderbilt community. The organization provides therapeutic, transitional housing and comprehensive services that empower survivors of domestic and sexual violence.</p></div>",
        "title": "8th Annual Scene & Heard Fashion Show 2017",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:45:00\">6:45 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom </span></div> <div class=\"description\"><p>This year the Vanderbilt Public Relations Society is hosting our 8th annual Scene &amp; Heard Fashion Show on March 25, 2017 in the Student Life Center at 6:45pm. All proceeds will be donated to The Mary Parrish Center, a cherished organization held in high regard &nbsp;by the Vanderbilt community. The organization provides therapeutic, transitional housing and comprehensive services that empower survivors of domestic and sexual violence.</p></div>",
        "categories": [
            "GME - Community Impact",
            "Greek Member Experience"
        ],
        "location": "Student Life Center Ballroom ",
        "description": "This year the Vanderbilt Public Relations Society is hosting our 8th annual Scene &; Heard Fashion Show on March 25, 2017 in the Student Life Center at 6:45pm. All proceeds will be donated to The Mary Parrish Center, a cherished organization held in high regard  ;by the Vanderbilt community. The organization provides therapeutic, transitional housing and comprehensive services that empower survivors of domestic and sexual violence. "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-25",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>The Original Cast's Spring Show, As Years Go By, is a musical revue comprised of songs from musicals such as Chicago, Avenue Q, Shrek The Musical, and Waitress. The show follows an ambitious writer, Casey, growing up and learning to live in the moment. Come laugh with us as Casey navigates the frustrations of childhood, the embarrassment of puberty, the terror of starting college, and the stresses of adulthood.</p></div>",
        "title": "As Years Go By",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-25\">Saturday, March 25, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>The Original Cast's Spring Show, As Years Go By, is a musical revue comprised of songs from musicals such as Chicago, Avenue Q, Shrek The Musical, and Waitress. The show follows an ambitious writer, Casey, growing up and learning to live in the moment. Come laugh with us as Casey navigates the frustrations of childhood, the embarrassment of puberty, the terror of starting college, and the stresses of adulthood.</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Langford Auditorium",
        "description": "The Original Cast';s Spring Show, As Years Go By, is a musical revue comprised of songs from musicals such as Chicago, Avenue Q, Shrek The Musical, and Waitress. The show follows an ambitious writer, Casey, growing up and learning to live in the moment. Come laugh with us as Casey navigates the frustrations of childhood, the embarrassment of puberty, the terror of starting college, and the stresses of adulthood. "
    },
    {
        "time": "11:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "title": "Cereal Sundays",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "categories": [],
        "location": "Moore College Faculty Director Apartment (Smith 502)",
        "description": "Stop by Dr. L';s apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out! "
    },
    {
        "time": "13:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Ben Chace, director of <em>Sin Alas</em>, and William Luis, Director of the Latino and Latina Studies Program and Gertrude Conway Vanderbilt Professor of Spanish. <br /><br /> <strong>Cuba</strong>&nbsp;(1968) Dir. Tom&aacute;s Guti&eacute;rrez Alea. Sergio, a wealthy bourgeois aspiring writer, decides to stay in Cuba after the revolution, even though his wife and friends flee to Miami. Sergio reflects on the changes in Cuba, from the Castro Revolution to the missile crisis, the effect of living in an underdeveloped country, and his relationships with his girlfriends, Elena and Hanna. Memories of Underdevelopment is a complex character study of alienation during the turmoil of social changes. The film is told in a highly subjective point of view through a fragmented narrative that resembles the way memories function. Spanish with English Subtitles. Digital file. 97 minutes. &nbsp;Presented in collaboration with The Latino and Latina Studies Program and the Center for Latin American Studies.&nbsp;<em>Restored by the Cineteca di Bologna at L' Immagine Ritrovata laboratory in association with Instituto Cubano del Arte e Industria Cinematograficos (ICAIC ). Restoration funded by the George Lucas Family Foundation and The Film Foundation's World Cinema Project<strong>.</strong></em>&nbsp;</p></div>",
        "title": "iLens: Memorias del Subdesarrollo (Memories of Underdevelpment)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Ben Chace, director of <em>Sin Alas</em>, and William Luis, Director of the Latino and Latina Studies Program and Gertrude Conway Vanderbilt Professor of Spanish. <br /><br /> <strong>Cuba</strong>&nbsp;(1968) Dir. Tom&aacute;s Guti&eacute;rrez Alea. Sergio, a wealthy bourgeois aspiring writer, decides to stay in Cuba after the revolution, even though his wife and friends flee to Miami. Sergio reflects on the changes in Cuba, from the Castro Revolution to the missile crisis, the effect of living in an underdeveloped country, and his relationships with his girlfriends, Elena and Hanna. Memories of Underdevelopment is a complex character study of alienation during the turmoil of social changes. The film is told in a highly subjective point of view through a fragmented narrative that resembles the way memories function. Spanish with English Subtitles. Digital file. 97 minutes. &nbsp;Presented in collaboration with The Latino and Latina Studies Program and the Center for Latin American Studies.&nbsp;<em>Restored by the Cineteca di Bologna at L' Immagine Ritrovata laboratory in association with Instituto Cubano del Arte e Industria Cinematograficos (ICAIC ). Restoration funded by the George Lucas Family Foundation and The Film Foundation's World Cinema Project<strong>.</strong></em>&nbsp;</p></div>",
        "categories": [
            "Diversity & Inclusion",
            "Visual Arts",
            "Film/Movie",
            "Graduate/Professional Students",
            "Political",
            "International"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by Ben Chace, director of Sin Alas, and William Luis, Director of the Latino and Latina Studies Program and Gertrude Conway Vanderbilt Professor of Spanish.  Cuba ;(1968) Dir. Tom&#xE1;s Guti&#xE9;rrez Alea. Sergio, a wealthy bourgeois aspiring writer, decides to stay in Cuba after the revolution, even though his wife and friends flee to Miami. Sergio reflects on the changes in Cuba, from the Castro Revolution to the missile crisis, the effect of living in an underdeveloped country, and his relationships with his girlfriends, Elena and Hanna. Memories of Underdevelopment is a complex character study of alienation during the turmoil of social changes. The film is told in a highly subjective point of view through a fragmented narrative that resembles the way memories function. Spanish with English Subtitles. Digital file. 97 minutes.  ;Presented in collaboration with The Latino and Latina Studies Program and the Center for Latin American Studies. ;Restored by the Cineteca di Bologna at L'; Immagine Ritrovata laboratory in association with Instituto Cubano del Arte e Industria Cinematograficos (ICAIC ). Restoration funded by the George Lucas Family Foundation and The Film Foundation';s World Cinema Project. ; "
    },
    {
        "time": "15:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Ben Chace, Director</p>\r\n<p><strong>Cuba/USA </strong>(2015) 70 year-old Luis Vargas sits in front of his crumbling art deco building in downtown Havana reading the Communist newspaper. He notices an obituary for Isabela Mu&ntilde;oz, a once renowned modern dancer, and attends her funeral, standing apart from the rest of the mourners. That night he can't sleep and is tormented by a fragment of the melody from her famous performance in 1967. His friend Ovilio suggests completing the melody as a way of letting go, but after a meandering search through the streets of Havana, Luis is led even deeper into a world of memory he has spent decades trying to forget. As scenes from his dramatic affair with Isabela unfold into his consciousness of daily life Luis begins to see parallels in the strained marriage of his young neighbors and the memories of his parents from his childhood in the provinces. Realizing his place in a cycle of failed intentions the old man tries to make a break. Spanish with English subtitles. Blu-ray. 90 minutes. <em>The first American directed and/or produced film shot in Cuba since the revolution. The first American film invited to premiere at the Havana International Film Festival. </em></p></div>",
        "title": "iLens: Sin Alas (Without Wings)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Ben Chace, Director</p>\r\n<p><strong>Cuba/USA </strong>(2015) 70 year-old Luis Vargas sits in front of his crumbling art deco building in downtown Havana reading the Communist newspaper. He notices an obituary for Isabela Mu&ntilde;oz, a once renowned modern dancer, and attends her funeral, standing apart from the rest of the mourners. That night he can't sleep and is tormented by a fragment of the melody from her famous performance in 1967. His friend Ovilio suggests completing the melody as a way of letting go, but after a meandering search through the streets of Havana, Luis is led even deeper into a world of memory he has spent decades trying to forget. As scenes from his dramatic affair with Isabela unfold into his consciousness of daily life Luis begins to see parallels in the strained marriage of his young neighbors and the memories of his parents from his childhood in the provinces. Realizing his place in a cycle of failed intentions the old man tries to make a break. Spanish with English subtitles. Blu-ray. 90 minutes. <em>The first American directed and/or produced film shot in Cuba since the revolution. The first American film invited to premiere at the Havana International Film Festival. </em></p></div>",
        "categories": [
            "International",
            "Graduate/Professional Students",
            "Film/Movie",
            "Visual Arts",
            "Diversity & Inclusion"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by Ben Chace, Director Cuba/USA (2015) 70 year-old Luis Vargas sits in front of his crumbling art deco building in downtown Havana reading the Communist newspaper. He notices an obituary for Isabela Mu&#xF1;oz, a once renowned modern dancer, and attends her funeral, standing apart from the rest of the mourners. That night he can';t sleep and is tormented by a fragment of the melody from her famous performance in 1967. His friend Ovilio suggests completing the melody as a way of letting go, but after a meandering search through the streets of Havana, Luis is led even deeper into a world of memory he has spent decades trying to forget. As scenes from his dramatic affair with Isabela unfold into his consciousness of daily life Luis begins to see parallels in the strained marriage of his young neighbors and the memories of his parents from his childhood in the provinces. Realizing his place in a cycle of failed intentions the old man tries to make a break. Spanish with English subtitles. Blu-ray. 90 minutes. The first American directed and/or produced film shot in Cuba since the revolution. The first American film invited to premiere at the Havana International Film Festival.  "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni 202</span></div> <div class=\"description\"><p>At Coronation, the new prince and princess are crowned as the royal members of PISO. At this event, educational information will be orally conveyed before the crowning of the new prince and princess. Guests who arrive later can read this on printed sheets of paper. After this phase, attendees will feast on catered and home-cooked Filipino food in a ballroom-like setting. Meat, vegetarian, noodle, and rice options will be offered. Cards about the history of the food and the regions from which they were discovered will be placed on tables. After dining, guests may dance to waltz and modern music.&nbsp;</p>\r\n<p>Semiformal / Black Tie Optional attire&nbsp;is expected.&nbsp;Attendance is free. Coronation is open to any undergraduate students who are looking for a fun multicultural experience.</p></div>",
        "title": "PISO Coronation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni 202</span></div> <div class=\"description\"><p>At Coronation, the new prince and princess are crowned as the royal members of PISO. At this event, educational information will be orally conveyed before the crowning of the new prince and princess. Guests who arrive later can read this on printed sheets of paper. After this phase, attendees will feast on catered and home-cooked Filipino food in a ballroom-like setting. Meat, vegetarian, noodle, and rice options will be offered. Cards about the history of the food and the regions from which they were discovered will be placed on tables. After dining, guests may dance to waltz and modern music.&nbsp;</p>\r\n<p>Semiformal / Black Tie Optional attire&nbsp;is expected.&nbsp;Attendance is free. Coronation is open to any undergraduate students who are looking for a fun multicultural experience.</p></div>",
        "categories": [
            "Diversity & Inclusion"
        ],
        "location": "Alumni 202",
        "description": "At Coronation, the new prince and princess are crowned as the royal members of PISO. At this event, educational information will be orally conveyed before the crowning of the new prince and princess. Guests who arrive later can read this on printed sheets of paper. After this phase, attendees will feast on catered and home-cooked Filipino food in a ballroom-like setting. Meat, vegetarian, noodle, and rice options will be offered. Cards about the history of the food and the regions from which they were discovered will be placed on tables. After dining, guests may dance to waltz and modern music. ; Semiformal / Black Tie Optional attire ;is expected. ;Attendance is free. Coronation is open to any undergraduate students who are looking for a fun multicultural experience. "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Central Library</span></div> <div class=\"description\"><p><span style=\"font-family: 'Arial',sans-serif; font-size: 10pt;\">Step back in time and join Vanderbilt staff, students and community members&nbsp;for a Jane Austen-era dance at the Central Library on Sunday, March 26<sup>th</sup> from 5:00-7:00 pm. No experience or partner is necessary&ndash;we&rsquo;ll learn various English Country Dances together! </span></p>\r\n<p><span style=\"font-family: 'Arial',sans-serif; font-size: 10pt;\">The evening features Susan Kevra, Caller, and The English Channel Band.&nbsp;The event is free and open to the public. Regency period costumes welcome, but not required. Refreshments will be served.&nbsp;</span></p></div>",
        "title": "Dance in the Library with Jane Austen",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Central Library</span></div> <div class=\"description\"><p><span style=\"font-family: 'Arial',sans-serif; font-size: 10pt;\">Step back in time and join Vanderbilt staff, students and community members&nbsp;for a Jane Austen-era dance at the Central Library on Sunday, March 26<sup>th</sup> from 5:00-7:00 pm. No experience or partner is necessary&ndash;we&rsquo;ll learn various English Country Dances together! </span></p>\r\n<p><span style=\"font-family: 'Arial',sans-serif; font-size: 10pt;\">The evening features Susan Kevra, Caller, and The English Channel Band.&nbsp;The event is free and open to the public. Regency period costumes welcome, but not required. Refreshments will be served.&nbsp;</span></p></div>",
        "categories": [],
        "location": "Vanderbilt Central Library",
        "description": "Step back in time and join Vanderbilt staff, students and community members ;for a Jane Austen-era dance at the Central Library on Sunday, March 26th from 5:00-7:00 pm. No experience or partner is necessary&#x2013;we&#x2019;ll learn various English Country Dances together!  The evening features Susan Kevra, Caller, and The English Channel Band. ;The event is free and open to the public. Regency period costumes welcome, but not required. Refreshments will be served. ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "title": "Sutherland Social",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "categories": [
            "The Ingram Commons"
        ],
        "location": "Sutherland House",
        "description": "Come fellowship with Sutherland residents with food and fun! "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Tower 2 room 808</span></div> <div class=\"description\"><p>With midterms, clubs, and the job recruiting ramping up, residents of tower 2 floors 7 and 8 can stop by to chat, enjoy a homemade treats, and listen to calming music.&nbsp;</p></div>",
        "title": "Study break with sweets!",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Tower 2 room 808</span></div> <div class=\"description\"><p>With midterms, clubs, and the job recruiting ramping up, residents of tower 2 floors 7 and 8 can stop by to chat, enjoy a homemade treats, and listen to calming music.&nbsp;</p></div>",
        "categories": [],
        "location": "Tower 2 room 808",
        "description": "With midterms, clubs, and the job recruiting ramping up, residents of tower 2 floors 7 and 8 can stop by to chat, enjoy a homemade treats, and listen to calming music. ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Scales 3</span></div> <div class=\"description\"><p>Scales 3 bi-weekly floor program&nbsp;</p></div>",
        "title": "Sweats and Shows",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Scales 3</span></div> <div class=\"description\"><p>Scales 3 bi-weekly floor program&nbsp;</p></div>",
        "categories": [],
        "location": "Scales 3",
        "description": "Scales 3 bi-weekly floor program ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Smith 1 Common Area</span></div> <div class=\"description\"><p>Join Moore College Council for \"Moore Munchies.\"&nbsp;Stop by the Smith 1 common room for Krispy Kreme donuts!&nbsp;</p></div>",
        "title": "Moore Munchies",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Smith 1 Common Area</span></div> <div class=\"description\"><p>Join Moore College Council for \"Moore Munchies.\"&nbsp;Stop by the Smith 1 common room for Krispy Kreme donuts!&nbsp;</p></div>",
        "categories": [],
        "location": "Smith 1 Common Area",
        "description": "Join Moore College Council for \";Moore Munchies.\"; ;Stop by the Smith 1 common room for Krispy Kreme donuts! ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-03-26",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Kay Bobs</span></div> <div class=\"description\"><p>Join your fellow Gabbeans at Sunday Night Trivia at Kay Bobs in Hillsboro Village at 8 pm!</p></div>",
        "title": "Gabbe goes to Trivia!",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-26\">Sunday, March 26, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Kay Bobs</span></div> <div class=\"description\"><p>Join your fellow Gabbeans at Sunday Night Trivia at Kay Bobs in Hillsboro Village at 8 pm!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Kay Bobs",
        "description": "Join your fellow Gabbeans at Sunday Night Trivia at Kay Bobs in Hillsboro Village at 8 pm! "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Law School - Hyatt Room</span></div> <div class=\"description\"><div>\r\n<div>\r\n<p class=\"x_MsoNoSpacing\"><span class=\"\">A lecture addressing patent litigation. <a href=\"http://www.mbhb.com/attorneys/sigmond/\">Leif R. Sigmond, Jr.</a> will discuss both district court patent litigation and Patent Trial and Appeal Board (PTAB) trials.</span></p>\r\n<p class=\"x_MsoNoSpacing\"><span class=\"\">Mr. Sigmond is a partner with McDonnell Boehnen Hulbert &amp; Berghoff LLP and serves as Chair of the firm&rsquo;s Litigation &amp; Appeals Practice Group</span><span class=\"\">. Mr. Sigmond concentrates in intellectual property litigation. He has advised clients on protecting, obtaining and licensing intellectual property. Mr. Sigmond served as MBHB managing partner from 2002 to 2004 and (separately) in 2011. Mr. Sigmond is located in the MBHB Chicago office. Mr. Sigmond has a B.S. in Electrical Engineering from Lafayette College and a J.D. from Widener University School of Law.</span></p>\r\n<div class=\"\">This event is open to Vanderbilt Law School students and faculty. Lunch will be served. Sponsored by the Vanderbilt IP Association.</div>\r\n</div>\r\n</div>\r\n<p>&nbsp;</p></div>",
        "title": "Patent Law: District Court Litigation and PTAB Trials Presentation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Law School - Hyatt Room</span></div> <div class=\"description\"><div>\r\n<div>\r\n<p class=\"x_MsoNoSpacing\"><span class=\"\">A lecture addressing patent litigation. <a href=\"http://www.mbhb.com/attorneys/sigmond/\">Leif R. Sigmond, Jr.</a> will discuss both district court patent litigation and Patent Trial and Appeal Board (PTAB) trials.</span></p>\r\n<p class=\"x_MsoNoSpacing\"><span class=\"\">Mr. Sigmond is a partner with McDonnell Boehnen Hulbert &amp; Berghoff LLP and serves as Chair of the firm&rsquo;s Litigation &amp; Appeals Practice Group</span><span class=\"\">. Mr. Sigmond concentrates in intellectual property litigation. He has advised clients on protecting, obtaining and licensing intellectual property. Mr. Sigmond served as MBHB managing partner from 2002 to 2004 and (separately) in 2011. Mr. Sigmond is located in the MBHB Chicago office. Mr. Sigmond has a B.S. in Electrical Engineering from Lafayette College and a J.D. from Widener University School of Law.</span></p>\r\n<div class=\"\">This event is open to Vanderbilt Law School students and faculty. Lunch will be served. Sponsored by the Vanderbilt IP Association.</div>\r\n</div>\r\n</div>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Law School",
            "Academic"
        ],
        "location": "Vanderbilt Law School - Hyatt Room",
        "description": "A lecture addressing patent litigation. [Leif R. Sigmond, Jr.] (http://www.mbhb.com/attorneys/sigmond/) will discuss both district court patent litigation and Patent Trial and Appeal Board (PTAB) trials. Mr. Sigmond is a partner with McDonnell Boehnen Hulbert &; Berghoff LLP and serves as Chair of the firm&#x2019;s Litigation &; Appeals Practice Group. Mr. Sigmond concentrates in intellectual property litigation. He has advised clients on protecting, obtaining and licensing intellectual property. Mr. Sigmond served as MBHB managing partner from 2002 to 2004 and (separately) in 2011. Mr. Sigmond is located in the MBHB Chicago office. Mr. Sigmond has a B.S. in Electrical Engineering from Lafayette College and a J.D. from Widener University School of Law. This event is open to Vanderbilt Law School students and faculty. Lunch will be served. Sponsored by the Vanderbilt IP Association.  ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing classroom</span></div> <div class=\"description\"><p>Host Responsibility Training is provided by the Center for Student Wellbeing. This alcohol and other drug education presentation will prepare hosts to have safe and successful events through the discussion of Tennessee State Law, Vanderbilt Policy, and DUI prevention strategies.&nbsp; The presentation is approximately 30 minutes in length and is required annually for hosts of events where alcohol is present.</p></div>",
        "title": "Graduate/Professional Student Host Responsibility Training",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing classroom</span></div> <div class=\"description\"><p>Host Responsibility Training is provided by the Center for Student Wellbeing. This alcohol and other drug education presentation will prepare hosts to have safe and successful events through the discussion of Tennessee State Law, Vanderbilt Policy, and DUI prevention strategies.&nbsp; The presentation is approximately 30 minutes in length and is required annually for hosts of events where alcohol is present.</p></div>",
        "categories": [],
        "location": "Center for Student Wellbeing classroom",
        "description": "Host Responsibility Training is provided by the Center for Student Wellbeing. This alcohol and other drug education presentation will prepare hosts to have safe and successful events through the discussion of Tennessee State Law, Vanderbilt Policy, and DUI prevention strategies. ; The presentation is approximately 30 minutes in length and is required annually for hosts of events where alcohol is present. "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-03-27T12:00:00\">Monday, March 27, 2017 (12:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-31T13:00:00\">Friday, March 31, 2017 (1:00 PM)</span></b> <div>Location: <span class=\"location\">Rand Wall</span></div> <div class=\"description\"><p>Join us at the wall for Hidden Dores' 4th annual photo campaign! Like years in the past, we want you to voice your experiences as students of colors and as allies.</p></div>",
        "title": "Hidden Dore's Photo Campaign",
        "summary": "<b><span class=\"dtstart\" title=\"2017-03-27T12:00:00\">Monday, March 27, 2017 (12:00 PM)</span> - <span class=\"dtend\" title=\"2017-03-31T13:00:00\">Friday, March 31, 2017 (1:00 PM)</span></b> <div>Location: <span class=\"location\">Rand Wall</span></div> <div class=\"description\"><p>Join us at the wall for Hidden Dores' 4th annual photo campaign! Like years in the past, we want you to voice your experiences as students of colors and as allies.</p></div>",
        "categories": [
            "Diversity & Inclusion"
        ],
        "location": "Rand Wall",
        "description": "Join us at the wall for Hidden Dores'; 4th annual photo campaign! Like years in the past, we want you to voice your experiences as students of colors and as allies. "
    },
    {
        "time": "14:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "14:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">201 Light Hall</span></div> <div class=\"description\"><p>Office Hours with Dean Fleming in 201 Light Hall.</p></div>",
        "title": "Office Hours with Dean Fleming",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">201 Light Hall</span></div> <div class=\"description\"><p>Office Hours with Dean Fleming in 201 Light Hall.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "201 Light Hall",
        "description": "Office Hours with Dean Fleming in 201 Light Hall. "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 407 A-C</span></div> <div class=\"description\"><p>Want to practice your Jedi physical diagnosis skills acquired under the tutelage of Dr. Fowler?</p>\r\n<p>Want to practice your amazing or non-existent Spanish-speaking skills?&nbsp;</p>\r\n<p>Please join us as we go over and practice together the Spanish PDx!&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>DINNER WILL BE PROVIDED</p>\r\n<p>ALL LEVELS WELCOMED (from fluent/native to what-is-Spanish-again?)</p></div>",
        "title": "Spanish PDx",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall Room 407 A-C</span></div> <div class=\"description\"><p>Want to practice your Jedi physical diagnosis skills acquired under the tutelage of Dr. Fowler?</p>\r\n<p>Want to practice your amazing or non-existent Spanish-speaking skills?&nbsp;</p>\r\n<p>Please join us as we go over and practice together the Spanish PDx!&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>DINNER WILL BE PROVIDED</p>\r\n<p>ALL LEVELS WELCOMED (from fluent/native to what-is-Spanish-again?)</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall Room 407 A-C",
        "description": "Want to practice your Jedi physical diagnosis skills acquired under the tutelage of Dr. Fowler? Want to practice your amazing or non-existent Spanish-speaking skills? ; Please join us as we go over and practice together the Spanish PDx! ;  ; DINNER WILL BE PROVIDED ALL LEVELS WELCOMED (from fluent/native to what-is-Spanish-again?) "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Black Cultural Center</span></div> <div class=\"description\"><div class=\"_4-u2 _3xaf _3-95 _4-u8\">\r\n<div class=\"_2qgs\"><strong><span class=\"_4n-j _3cht fsl\" data-testid=\"event-permalink-details\">From the Desert to the Runway: a native fashion designer shares her entrepreneurial experiences</span></strong></div>\r\n<div class=\"_2qgs\">&nbsp;</div>\r\n<div class=\"_2qgs\"><span class=\"_4n-j _3cht fsl\" data-testid=\"event-permalink-details\">Join us for a special guest lecture by Cher Thomas, and indigenous fashion designer (Cocopah/Akimel O'odham) from Arizona will talk about her experiences as an entrepreneur and starting her charitable nonprofit. <br /><br />Ms. Thomas' work has been featured in Native fashion magazines, Indian Country Today, and models wearing her designs have walked in shows internationally in Canada, US, Australia. Her website is <a href=\"http://www.cherthomasdesigns.com/\" target=\"_blank\" rel=\"nofollow noopener nofollow\">http://<wbr />www.cherthomasdesigns.com/</a><br /><br />Lecture sponsored by the Native Americans in Tennessee Interacting at Vanderbilt (NATIVe) student group. Open to the public.</span></div>\r\n</div>\r\n<div class=\"_4-u2 _3xaf _3-95 _4-u8\">&nbsp;</div></div>",
        "title": "From the Desert to the Runway",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Black Cultural Center</span></div> <div class=\"description\"><div class=\"_4-u2 _3xaf _3-95 _4-u8\">\r\n<div class=\"_2qgs\"><strong><span class=\"_4n-j _3cht fsl\" data-testid=\"event-permalink-details\">From the Desert to the Runway: a native fashion designer shares her entrepreneurial experiences</span></strong></div>\r\n<div class=\"_2qgs\">&nbsp;</div>\r\n<div class=\"_2qgs\"><span class=\"_4n-j _3cht fsl\" data-testid=\"event-permalink-details\">Join us for a special guest lecture by Cher Thomas, and indigenous fashion designer (Cocopah/Akimel O'odham) from Arizona will talk about her experiences as an entrepreneur and starting her charitable nonprofit. <br /><br />Ms. Thomas' work has been featured in Native fashion magazines, Indian Country Today, and models wearing her designs have walked in shows internationally in Canada, US, Australia. Her website is <a href=\"http://www.cherthomasdesigns.com/\" target=\"_blank\" rel=\"nofollow noopener nofollow\">http://<wbr />www.cherthomasdesigns.com/</a><br /><br />Lecture sponsored by the Native Americans in Tennessee Interacting at Vanderbilt (NATIVe) student group. Open to the public.</span></div>\r\n</div>\r\n<div class=\"_4-u2 _3xaf _3-95 _4-u8\">&nbsp;</div></div>",
        "categories": [
            "Diversity & Inclusion",
            "Visual Arts"
        ],
        "location": "Black Cultural Center",
        "description": "From the Desert to the Runway: a native fashion designer shares her entrepreneurial experiences  ; Join us for a special guest lecture by Cher Thomas, and indigenous fashion designer (Cocopah/Akimel O';odham) from Arizona will talk about her experiences as an entrepreneur and starting her charitable nonprofit.  Ms. Thomas'; work has been featured in Native fashion magazines, Indian Country Today, and models wearing her designs have walked in shows internationally in Canada, US, Australia. Her website is [http://www.cherthomasdesigns.com/] (http://www.cherthomasdesigns.com/)  Lecture sponsored by the Native Americans in Tennessee Interacting at Vanderbilt (NATIVe) student group. Open to the public.  ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">OACS</span></div> <div class=\"description\"><p>Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the <a href=\"http://www.thenashvillefoodproject.org/\" target=\"_blank\">Nashville Food Project</a>. Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply.</p></div>",
        "title": "Redefine",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">OACS</span></div> <div class=\"description\"><p>Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the <a href=\"http://www.thenashvillefoodproject.org/\" target=\"_blank\">Nashville Food Project</a>. Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply.</p></div>",
        "categories": [
            "Service & Philanthropy",
            "International"
        ],
        "location": "OACS",
        "description": "Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the [Nashville Food Project] (http://www.thenashvillefoodproject.org/) . Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply. "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Delta Tau Delta</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Delta Tau Delta's Faculty Speaker Series is back this semester with a new lineup of fantastic professors and employees of Vanderbilt. On a select number of Mondays at 6pm this semester, the Delta Tau Delta Chapter will host a professor for an informal conversation on topics of interest. Past speakers have talked on educational reform, the current immigration crisis, and personal finance.</p></div>",
        "title": "Spring Faculty Speaker Series 3 (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Delta Tau Delta</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Delta Tau Delta's Faculty Speaker Series is back this semester with a new lineup of fantastic professors and employees of Vanderbilt. On a select number of Mondays at 6pm this semester, the Delta Tau Delta Chapter will host a professor for an informal conversation on topics of interest. Past speakers have talked on educational reform, the current immigration crisis, and personal finance.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Faculty Engagement"
        ],
        "location": "Delta Tau Delta",
        "description": "Cancelled  Delta Tau Delta';s Faculty Speaker Series is back this semester with a new lineup of fantastic professors and employees of Vanderbilt. On a select number of Mondays at 6pm this semester, the Delta Tau Delta Chapter will host a professor for an informal conversation on topics of interest. Past speakers have talked on educational reform, the current immigration crisis, and personal finance. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom</span></div> <div class=\"description\"><p>Join VPB Speaker's Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr.&nbsp;</p></div>",
        "title": "VPB Speaker's Committee presents IMPACT Symposium 2017",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom</span></div> <div class=\"description\"><p>Join VPB Speaker's Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr.&nbsp;</p></div>",
        "categories": [
            "GME - Diversity & Inclusion",
            "MVE - Service & Civic Engagement Track",
            "Greek Member Experience",
            "My Vanderbilt Experience"
        ],
        "location": "Student Life Center Ballroom",
        "description": "Join VPB Speaker';s Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr. ; "
    },
    {
        "time": "19:15:00",
        "date": "2017-03-27",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:15:00\">9:15 PM</span>)</b> <div>Location: <span class=\"location\">Wyatt Center Rotunda</span></div> <div class=\"description\"><p>Please join us for an exciting final Common Ground event of the year! We proudly present&nbsp;Dr. Andrew Van Schaack, Associate Dean for&nbsp;Online Learning, and Vanderbilt Alumni for a night of informative talks, networking, dinner and drinks.</p></div>",
        "title": "Online Learning Communities: A Vision of the Futur...",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-27\">Monday, March 27, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:15:00\">9:15 PM</span>)</b> <div>Location: <span class=\"location\">Wyatt Center Rotunda</span></div> <div class=\"description\"><p>Please join us for an exciting final Common Ground event of the year! We proudly present&nbsp;Dr. Andrew Van Schaack, Associate Dean for&nbsp;Online Learning, and Vanderbilt Alumni for a night of informative talks, networking, dinner and drinks.</p></div>",
        "categories": [
            "Graduate/Professional Students"
        ],
        "location": "Wyatt Center Rotunda",
        "description": "Please join us for an exciting final Common Ground event of the year! We proudly present ;Dr. Andrew Van Schaack, Associate Dean for ;Online Learning, and Vanderbilt Alumni for a night of informative talks, networking, dinner and drinks. "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "13:00:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "GME - Healthy Behaviors",
            "MVE - Health & Wellness Track",
            "Greek Member Experience",
            "My Vanderbilt Experience",
            "Health & Wellness"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "15:00:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">319 Light Hall</span></div> <div class=\"description\"><p>Office Hours with the Office of Diversity Affairs.</p></div>",
        "title": "Office of Diversity Affairs",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">319 Light Hall</span></div> <div class=\"description\"><p>Office Hours with the Office of Diversity Affairs.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "319 Light Hall",
        "description": "Office Hours with the Office of Diversity Affairs. "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Le Sel </span></div> <div class=\"description\"><p>This event is part of the Life After Vanderbilt Series</p>\r\n<p>&nbsp;</p>\r\n<p>RSVP to Sarah Quinn in Alumni Relations sarah.quinn@vanderbilt.edu</p></div>",
        "title": "Seniors and the City",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Le Sel </span></div> <div class=\"description\"><p>This event is part of the Life After Vanderbilt Series</p>\r\n<p>&nbsp;</p>\r\n<p>RSVP to Sarah Quinn in Alumni Relations sarah.quinn@vanderbilt.edu</p></div>",
        "categories": [],
        "location": "Le Sel ",
        "description": "This event is part of the Life After Vanderbilt Series  ; RSVP to Sarah Quinn in Alumni Relations sarah.quinn@vanderbilt.edu "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "title": "Vandy Wesley Weekly Dinner and Community",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "categories": [
            "Health & Wellness",
            "Religious/Spiritual"
        ],
        "location": "Div School Reading Room (through the courtyard next to Benton Chapel)",
        "description": "Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond.  ;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community.  ; All are welcome!! "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>Join VPB Speaker's Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr.&nbsp;</p></div>",
        "title": "VPB Speaker's Committee presents IMPACT Symposium 2017",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>Join VPB Speaker's Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr.&nbsp;</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Service & Civic Engagement Track",
            "GME - Diversity & Inclusion"
        ],
        "location": "Langford Auditorium",
        "description": "Join VPB Speaker';s Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr. ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">BCC Auditorium  </span></div> <div class=\"description\"><p>This event will have a panel of African American professors who discuss their difficult and successes in academia.&nbsp;</p></div>",
        "title": "Black in Academia",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">BCC Auditorium  </span></div> <div class=\"description\"><p>This event will have a panel of African American professors who discuss their difficult and successes in academia.&nbsp;</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Cultural Awareness Track",
            "GME - Faculty Engagement"
        ],
        "location": "BCC Auditorium  ",
        "description": "This event will have a panel of African American professors who discuss their difficult and successes in academia. ; "
    },
    {
        "time": "19:15:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:30:00\">10:30 PM</span>)</b> <div>Location: <span class=\"location\">Belcourt Theatre</span></div> <div class=\"description\"><p>Dir. Robert Zemeckis <span class=\"divider\">|</span>USA <span class=\"divider\">|</span>1997 <span class=\"divider\">|</span>150 min. <span class=\"divider\">|</span>PG <span class=\"divider\">|</span>35mm</p>\r\n<p>Skype Q&amp;A following the screening with Steve Howell, head of the Space Sciences and Astrobiology Division at the NASA Ames Research Center, about the search for extraterrestrial life. Moderated by Tracie Prater, aerospace engineer in the Materials and Processes Laboratory at NASA Marshall Space Flight Center.</p>\r\n<div class=\"x_x_x_accessibility-item\"><strong>Participants&nbsp;who commit&nbsp;to checking in with the FLiCX administrator by no later than7:15pm, and to remaining through the post-screening discussion may RSVP in the right-hand column for tickets purchased by the Dean of Students office.</strong></div>\r\n<div class=\"x_x_x_accessibility-item\">&nbsp;</div>\r\n<div class=\"x_x_x_accessibility-item\"><em>Since seating is limited, we must remind participants of the following:</em></div>\r\n<div class=\"x_x_x_accessibility-item\">\r\n<div class=\"x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_accessibility-item\">\r\n<ul>\r\n<li><em>that if you RSVP in the affirmative, and your plans change, you are expected to log back in and change your status to \"not attending;\"</em></li>\r\n<li><em>that&nbsp;<strong>Vanderbilt participants&nbsp;must RSVP for themselves, and may not be \"guests;\"</strong></em></li>\r\n<li><em>and <strong>non-Vanderbilt guests are limited to one per participant.&nbsp;</strong></em></li>\r\n</ul>\r\n<p><em></em>Based on Carl Sagan's novel of the same name, <strong><em>Contact</em></strong>&nbsp;follows Dr. Ellie Arroway (Jodie Foster), a radio astronomer working with the Search for Extraterrestrial Intelligence (SETI), as she intercepts a message seemingly sent by aliens with plans for the construction of a strange device. What could then turn into an overblown discussion of humanity's reaction to evidence of extraterrestrial life instead turns its introspective eye on Arroway herself, creating a deeply personal tale of one person's search for life's meaning in the stars above.</p>\r\n<p><strong>Steve B. Howell</strong> is currently the head of the Space Sciences and Astrobiology Division at the NASA Ames Research Center following his success as project scientist of both the Kepler and K2 missions. He received his PhD in astrophysics at the University of Amsterdam and has over 900 scientific publications spanning research on variable stars, instrumentation, spectroscopy, and exoplanets. Steve has written or contributed to numerous scientific books, and his textbook on digital imaging detectors (CCDs) is the standard in college courses around the world. Working as the scientist in charge of the planet-hunting Kepler mission inspired the creation of <em>A Kepler's Dozen</em>, a collection of short stories about real exoplanets that included Steve's first science fiction work. As a frequent invited speaker at scientific conferences and public forums, Steve has a passion for sharing astronomy with people throughout the world. He lives in the San Francisco Bay area with his partner Sally and enjoys scientific challenges, the great outdoors, vegetarian gourmet cooking, and playing blues music. And, yes, he still considers Pluto a planet in our solar system.</p>\r\n<p><strong>Tracie Prater</strong> is an aerospace engineer in the Materials and Processes Laboratory at NASA Marshall Space Flight Center, where she is currently the materials discipline lead for the in-space manufacturing (ISM) project. Using the International Space Station as a testbed, ISM is responsible for developing the manufacturing capabilities needed to produce parts on demand during long duration, crewed space exploration missions. She also serves as a subject matter expert for NASA's Centennial Challenge on 3D Printing of Habitats, a public competition for additive manufacturing of structural habitats using recyclable materials and in situ resources (www.bradley.edu/challenge). She has a PhD in mechanical engineering from Vanderbilt University.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div></div>",
        "title": "FLiCX: Contact (Science on Screen)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:30:00\">10:30 PM</span>)</b> <div>Location: <span class=\"location\">Belcourt Theatre</span></div> <div class=\"description\"><p>Dir. Robert Zemeckis <span class=\"divider\">|</span>USA <span class=\"divider\">|</span>1997 <span class=\"divider\">|</span>150 min. <span class=\"divider\">|</span>PG <span class=\"divider\">|</span>35mm</p>\r\n<p>Skype Q&amp;A following the screening with Steve Howell, head of the Space Sciences and Astrobiology Division at the NASA Ames Research Center, about the search for extraterrestrial life. Moderated by Tracie Prater, aerospace engineer in the Materials and Processes Laboratory at NASA Marshall Space Flight Center.</p>\r\n<div class=\"x_x_x_accessibility-item\"><strong>Participants&nbsp;who commit&nbsp;to checking in with the FLiCX administrator by no later than7:15pm, and to remaining through the post-screening discussion may RSVP in the right-hand column for tickets purchased by the Dean of Students office.</strong></div>\r\n<div class=\"x_x_x_accessibility-item\">&nbsp;</div>\r\n<div class=\"x_x_x_accessibility-item\"><em>Since seating is limited, we must remind participants of the following:</em></div>\r\n<div class=\"x_x_x_accessibility-item\">\r\n<div class=\"x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_x_accessibility-item\">\r\n<ul>\r\n<li><em>that if you RSVP in the affirmative, and your plans change, you are expected to log back in and change your status to \"not attending;\"</em></li>\r\n<li><em>that&nbsp;<strong>Vanderbilt participants&nbsp;must RSVP for themselves, and may not be \"guests;\"</strong></em></li>\r\n<li><em>and <strong>non-Vanderbilt guests are limited to one per participant.&nbsp;</strong></em></li>\r\n</ul>\r\n<p><em></em>Based on Carl Sagan's novel of the same name, <strong><em>Contact</em></strong>&nbsp;follows Dr. Ellie Arroway (Jodie Foster), a radio astronomer working with the Search for Extraterrestrial Intelligence (SETI), as she intercepts a message seemingly sent by aliens with plans for the construction of a strange device. What could then turn into an overblown discussion of humanity's reaction to evidence of extraterrestrial life instead turns its introspective eye on Arroway herself, creating a deeply personal tale of one person's search for life's meaning in the stars above.</p>\r\n<p><strong>Steve B. Howell</strong> is currently the head of the Space Sciences and Astrobiology Division at the NASA Ames Research Center following his success as project scientist of both the Kepler and K2 missions. He received his PhD in astrophysics at the University of Amsterdam and has over 900 scientific publications spanning research on variable stars, instrumentation, spectroscopy, and exoplanets. Steve has written or contributed to numerous scientific books, and his textbook on digital imaging detectors (CCDs) is the standard in college courses around the world. Working as the scientist in charge of the planet-hunting Kepler mission inspired the creation of <em>A Kepler's Dozen</em>, a collection of short stories about real exoplanets that included Steve's first science fiction work. As a frequent invited speaker at scientific conferences and public forums, Steve has a passion for sharing astronomy with people throughout the world. He lives in the San Francisco Bay area with his partner Sally and enjoys scientific challenges, the great outdoors, vegetarian gourmet cooking, and playing blues music. And, yes, he still considers Pluto a planet in our solar system.</p>\r\n<p><strong>Tracie Prater</strong> is an aerospace engineer in the Materials and Processes Laboratory at NASA Marshall Space Flight Center, where she is currently the materials discipline lead for the in-space manufacturing (ISM) project. Using the International Space Station as a testbed, ISM is responsible for developing the manufacturing capabilities needed to produce parts on demand during long duration, crewed space exploration missions. She also serves as a subject matter expert for NASA's Centennial Challenge on 3D Printing of Habitats, a public competition for additive manufacturing of structural habitats using recyclable materials and in situ resources (www.bradley.edu/challenge). She has a PhD in mechanical engineering from Vanderbilt University.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div></div>",
        "categories": [
            "Women & Gender Issues",
            "Religious/Spiritual",
            "Graduate/Professional Students",
            "Political",
            "Visual Arts",
            "Film/Movie"
        ],
        "location": "Belcourt Theatre",
        "description": "Dir. Robert Zemeckis |USA |1997 |150 min. |PG |35mm Skype Q&;A following the screening with Steve Howell, head of the Space Sciences and Astrobiology Division at the NASA Ames Research Center, about the search for extraterrestrial life. Moderated by Tracie Prater, aerospace engineer in the Materials and Processes Laboratory at NASA Marshall Space Flight Center. Participants ;who commit ;to checking in with the FLiCX administrator by no later than7:15pm, and to remaining through the post-screening discussion may RSVP in the right-hand column for tickets purchased by the Dean of Students office.  ; Since seating is limited, we must remind participants of the following: ---that if you RSVP in the affirmative, and your plans change, you are expected to log back in and change your status to \";not attending;\";  ---that ;Vanderbilt participants ;must RSVP for themselves, and may not be \";guests;\";  ---and non-Vanderbilt guests are limited to one per participant. ;  Based on Carl Sagan';s novel of the same name, Contact ;follows Dr. Ellie Arroway (Jodie Foster), a radio astronomer working with the Search for Extraterrestrial Intelligence (SETI), as she intercepts a message seemingly sent by aliens with plans for the construction of a strange device. What could then turn into an overblown discussion of humanity';s reaction to evidence of extraterrestrial life instead turns its introspective eye on Arroway herself, creating a deeply personal tale of one person';s search for life';s meaning in the stars above. Steve B. Howell is currently the head of the Space Sciences and Astrobiology Division at the NASA Ames Research Center following his success as project scientist of both the Kepler and K2 missions. He received his PhD in astrophysics at the University of Amsterdam and has over 900 scientific publications spanning research on variable stars, instrumentation, spectroscopy, and exoplanets. Steve has written or contributed to numerous scientific books, and his textbook on digital imaging detectors (CCDs) is the standard in college courses around the world. Working as the scientist in charge of the planet-hunting Kepler mission inspired the creation of A Kepler';s Dozen, a collection of short stories about real exoplanets that included Steve';s first science fiction work. As a frequent invited speaker at scientific conferences and public forums, Steve has a passion for sharing astronomy with people throughout the world. He lives in the San Francisco Bay area with his partner Sally and enjoys scientific challenges, the great outdoors, vegetarian gourmet cooking, and playing blues music. And, yes, he still considers Pluto a planet in our solar system. Tracie Prater is an aerospace engineer in the Materials and Processes Laboratory at NASA Marshall Space Flight Center, where she is currently the materials discipline lead for the in-space manufacturing (ISM) project. Using the International Space Station as a testbed, ISM is responsible for developing the manufacturing capabilities needed to produce parts on demand during long duration, crewed space exploration missions. She also serves as a subject matter expert for NASA';s Centennial Challenge on 3D Printing of Habitats, a public competition for additive manufacturing of structural habitats using recyclable materials and in situ resources (www.bradley.edu/challenge). She has a PhD in mechanical engineering from Vanderbilt University.  ;  ; "
    },
    {
        "time": "19:15:00",
        "date": "2017-03-28",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall Lounge</span></div> <div class=\"description\"><p>Come join ONE, an international grassroots campaigning and advocacy organization, to learn about the International Affairs budget!</p>\r\n<p>Help us tell our members of Congress that fighting extreme poverty overseas matters to the people they represent and that they need to stand up and defend these investments.</p></div>",
        "title": "International Affairs Budget Defense",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-28\">Tuesday, March 28, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:15:00\">7:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall Lounge</span></div> <div class=\"description\"><p>Come join ONE, an international grassroots campaigning and advocacy organization, to learn about the International Affairs budget!</p>\r\n<p>Help us tell our members of Congress that fighting extreme poverty overseas matters to the people they represent and that they need to stand up and defend these investments.</p></div>",
        "categories": [
            "Political",
            "Health & Wellness"
        ],
        "location": "Alumni Hall Lounge",
        "description": "Come join ONE, an international grassroots campaigning and advocacy organization, to learn about the International Affairs budget! Help us tell our members of Congress that fighting extreme poverty overseas matters to the people they represent and that they need to stand up and defend these investments. "
    },
    {
        "time": "09:15:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - Health & Wellness Track",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">LH</span></div> <div class=\"description\"><p>Come to the March meeting and let's discuss recent immigration policy and how it could be affecting our patients. Dr. Miller will be joining us! Thanks to Becca DePew for organizing!</p></div>",
        "title": "Monthly Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">LH</span></div> <div class=\"description\"><p>Come to the March meeting and let's discuss recent immigration policy and how it could be affecting our patients. Dr. Miller will be joining us! Thanks to Becca DePew for organizing!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "LH",
        "description": "Come to the March meeting and let';s discuss recent immigration policy and how it could be affecting our patients. Dr. Miller will be joining us! Thanks to Becca DePew for organizing! "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">411 A-D Light Hall</span></div> <div class=\"description\"><p>-</p></div>",
        "title": "March CCO Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">411 A-D Light Hall</span></div> <div class=\"description\"><p>-</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "411 A-D Light Hall",
        "description": "- "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance Room (Law School)</span></div> <div class=\"description\"><p>The issue of ideological diversity on college campuses has dominated the news in recent months. Writing in <em>T</em><em>he New York Times</em>, Nicholas Kristof observed, \"Universities are the bedrock of progressive values, but the one kind of diversity that universities disregard is ideological and religious. We&rsquo;re fine with people who don&rsquo;t look like us, as long as they think like us...Universities should be a hubbub of the full range of political perspectives from A to Z, not just from V to Z. So maybe we progressives could take a brief break from attacking the other side and more broadly incorporate values that we supposedly cherish &mdash; like diversity &mdash; in our own dominions.\"</p>\r\n<p>Mark Grabowski, Professor of Journalism at Adelphi University, will deliver a talk on ideological diversity on college campuses today. His talk will focus on viewpoint diversity among faculty members. Professor Grabowski is a member of the Heterodox Academy, a group dedicated to advancing ideological diversity on college campuses. He has written extensively on the topic and is a contributor to <em>The Washington Examiner</em>.&nbsp;He holds a law degree from Georgetown University and a bachelor's degree from Case Western Reserve University.</p>\r\n<p>Brian Fitzpatrick, Professor of Law at Vanderbilt University, will provide commentary on the talk. Professor Fitzpatrick holds a law degree from Harvard University and a bachelor's degree from Notre Dame University.</p>\r\n<p>This event is free and open to the public. Sponsored by the Federalist Society. Lunch will be provided.&nbsp;</p>\r\n<p>*Law students, please note that the event is open to 2Ls, 3Ls, and LLMs. 1L students have a Career Services event during this time.&nbsp;</p></div>",
        "title": "God and Man at Vanderbilt: Ideological Diversity on College Campuses",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance Room (Law School)</span></div> <div class=\"description\"><p>The issue of ideological diversity on college campuses has dominated the news in recent months. Writing in <em>T</em><em>he New York Times</em>, Nicholas Kristof observed, \"Universities are the bedrock of progressive values, but the one kind of diversity that universities disregard is ideological and religious. We&rsquo;re fine with people who don&rsquo;t look like us, as long as they think like us...Universities should be a hubbub of the full range of political perspectives from A to Z, not just from V to Z. So maybe we progressives could take a brief break from attacking the other side and more broadly incorporate values that we supposedly cherish &mdash; like diversity &mdash; in our own dominions.\"</p>\r\n<p>Mark Grabowski, Professor of Journalism at Adelphi University, will deliver a talk on ideological diversity on college campuses today. His talk will focus on viewpoint diversity among faculty members. Professor Grabowski is a member of the Heterodox Academy, a group dedicated to advancing ideological diversity on college campuses. He has written extensively on the topic and is a contributor to <em>The Washington Examiner</em>.&nbsp;He holds a law degree from Georgetown University and a bachelor's degree from Case Western Reserve University.</p>\r\n<p>Brian Fitzpatrick, Professor of Law at Vanderbilt University, will provide commentary on the talk. Professor Fitzpatrick holds a law degree from Harvard University and a bachelor's degree from Notre Dame University.</p>\r\n<p>This event is free and open to the public. Sponsored by the Federalist Society. Lunch will be provided.&nbsp;</p>\r\n<p>*Law students, please note that the event is open to 2Ls, 3Ls, and LLMs. 1L students have a Career Services event during this time.&nbsp;</p></div>",
        "categories": [
            "Law School"
        ],
        "location": "Renaissance Room (Law School)",
        "description": "The issue of ideological diversity on college campuses has dominated the news in recent months. Writing in The New York Times, Nicholas Kristof observed, \";Universities are the bedrock of progressive values, but the one kind of diversity that universities disregard is ideological and religious. We&#x2019;re fine with people who don&#x2019;t look like us, as long as they think like us...Universities should be a hubbub of the full range of political perspectives from A to Z, not just from V to Z. So maybe we progressives could take a brief break from attacking the other side and more broadly incorporate values that we supposedly cherish &#x2014; like diversity &#x2014; in our own dominions.\"; Mark Grabowski, Professor of Journalism at Adelphi University, will deliver a talk on ideological diversity on college campuses today. His talk will focus on viewpoint diversity among faculty members. Professor Grabowski is a member of the Heterodox Academy, a group dedicated to advancing ideological diversity on college campuses. He has written extensively on the topic and is a contributor to The Washington Examiner. ;He holds a law degree from Georgetown University and a bachelor';s degree from Case Western Reserve University. Brian Fitzpatrick, Professor of Law at Vanderbilt University, will provide commentary on the talk. Professor Fitzpatrick holds a law degree from Harvard University and a bachelor';s degree from Notre Dame University. This event is free and open to the public. Sponsored by the Federalist Society. Lunch will be provided. ; *Law students, please note that the event is open to 2Ls, 3Ls, and LLMs. 1L students have a Career Services event during this time. ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM.</p>\r\n<p>Join us as we \"live among the psalms\" in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God's presence, and a blessing.</p>\r\n<p>&nbsp;</p></div>",
        "title": "One Psalm",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM.</p>\r\n<p>Join us as we \"live among the psalms\" in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God's presence, and a blessing.</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Religious/Spiritual"
        ],
        "location": "Benton Chapel",
        "description": "The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM. Join us as we \";live among the psalms\"; in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God';s presence, and a blessing.  ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Bass, Berry & Sims Room</span></div> <div class=\"description\"><p>We want to hear your feedback!&nbsp; Help us learn more about how we can better connect graduate and professional students with the University's sexual violence prevention, support, and response resources.&nbsp; RSVP helpful but not required.</p>\r\n<p>&nbsp;</p>\r\n<p>Offered by the VU Project Safe Center and the Provost's Task Force on Sexual Assault</p>\r\n<p>RSVP to projectsafe@vanderbilt.edu</p>\r\n<p>&nbsp;</p></div>",
        "title": "Professional Student Focus Group on University Sexual Violence Resources",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Bass, Berry & Sims Room</span></div> <div class=\"description\"><p>We want to hear your feedback!&nbsp; Help us learn more about how we can better connect graduate and professional students with the University's sexual violence prevention, support, and response resources.&nbsp; RSVP helpful but not required.</p>\r\n<p>&nbsp;</p>\r\n<p>Offered by the VU Project Safe Center and the Provost's Task Force on Sexual Assault</p>\r\n<p>RSVP to projectsafe@vanderbilt.edu</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "The Ingram Commons"
        ],
        "location": "Bass, Berry & Sims Room",
        "description": "We want to hear your feedback! ; Help us learn more about how we can better connect graduate and professional students with the University';s sexual violence prevention, support, and response resources. ; RSVP helpful but not required.  ; Offered by the VU Project Safe Center and the Provost';s Task Force on Sexual Assault RSVP to projectsafe@vanderbilt.edu  ; "
    },
    {
        "time": "14:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">SLC LL Rooms 1, 2</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend a&nbsp;<strong>Curricular Practical Training (CPT)</strong>&nbsp;workshop and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n</ul>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT workshop will now be <u>required</u> before applying for employment authorization. </strong><strong><em>Spots are limited!</em></strong></p></div>",
        "title": "CPT Workshop",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">SLC LL Rooms 1, 2</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend a&nbsp;<strong>Curricular Practical Training (CPT)</strong>&nbsp;workshop and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n</ul>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT workshop will now be <u>required</u> before applying for employment authorization. </strong><strong><em>Spots are limited!</em></strong></p></div>",
        "categories": [
            "Career Development",
            "International"
        ],
        "location": "SLC LL Rooms 1, 2",
        "description": "F-1 Students interested to work off campus, attend a CPT workshop!!! Have you ever thought about working off campus or interning for a company in the United States? Attend a ;Curricular Practical Training (CPT) ;workshop and get the facts about how to apply for employment authorization. ---CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment. ;  Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States? These are examples of some of the information you will learn by attending one of the CPT workshops this fall. ; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States. ; CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&#x2019;s, master&#x2019;s, doctoral). ; If you have an interest to work off campus, please sign up for the Spring ;workshops. ;Attendance at a CPT workshop will now be required before applying for employment authorization. Spots are limited! "
    },
    {
        "time": "15:30:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:30:00\">4:30 PM</span>)</b> <div>Location: <span class=\"location\">Flynn Auditorium</span></div> <div class=\"description\"><p>The Moot Court Board will provide&nbsp;the 1L class with instructions on preparing for their upcoming oral arguments.&nbsp;</p></div>",
        "title": "1L Oral Argument Presentation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:30:00\">4:30 PM</span>)</b> <div>Location: <span class=\"location\">Flynn Auditorium</span></div> <div class=\"description\"><p>The Moot Court Board will provide&nbsp;the 1L class with instructions on preparing for their upcoming oral arguments.&nbsp;</p></div>",
        "categories": [
            "Law School"
        ],
        "location": "Flynn Auditorium",
        "description": "The Moot Court Board will provide ;the 1L class with instructions on preparing for their upcoming oral arguments. ; "
    },
    {
        "time": "16:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:00:00\">4:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Alpha Chi Omega House</span></div> <div class=\"description\"><p>On behalf of the sisters of Alpha Chi Omega, I would like to invite you to Coffee and Chai with Alpha Chi on Wednesday, March 29th, from 4:00-6:00PM. This is a casual, drop-in style event with coffee, tea, pastries, and an opportunity for us to get to know more about you and you about us! We would love for you to stop by the Alpha Chi house (across from Branscomb Quad/the Student Life Center) any time you'd like between 4:00 and 6:00 for treats and conversation outside of the classroom. Please R.S.V.P. to our Vice President of Intellectual Development, Anni Pabari, at vandyaxo.id@gmail.com.</p></div>",
        "title": "Coffee and Chai with Alpha Chi",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:00:00\">4:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Alpha Chi Omega House</span></div> <div class=\"description\"><p>On behalf of the sisters of Alpha Chi Omega, I would like to invite you to Coffee and Chai with Alpha Chi on Wednesday, March 29th, from 4:00-6:00PM. This is a casual, drop-in style event with coffee, tea, pastries, and an opportunity for us to get to know more about you and you about us! We would love for you to stop by the Alpha Chi house (across from Branscomb Quad/the Student Life Center) any time you'd like between 4:00 and 6:00 for treats and conversation outside of the classroom. Please R.S.V.P. to our Vice President of Intellectual Development, Anni Pabari, at vandyaxo.id@gmail.com.</p></div>",
        "categories": [],
        "location": "Alpha Chi Omega House",
        "description": "On behalf of the sisters of Alpha Chi Omega, I would like to invite you to Coffee and Chai with Alpha Chi on Wednesday, March 29th, from 4:00-6:00PM. This is a casual, drop-in style event with coffee, tea, pastries, and an opportunity for us to get to know more about you and you about us! We would love for you to stop by the Alpha Chi house (across from Branscomb Quad/the Student Life Center) any time you';d like between 4:00 and 6:00 for treats and conversation outside of the classroom. Please R.S.V.P. to our Vice President of Intellectual Development, Anni Pabari, at vandyaxo.id@gmail.com. "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Wilson Hall, Room 103</span></div> <div class=\"description\"><p>Thinking about how to budget, save and deal with debt when you graduate?&nbsp;</p>\r\n<p>Get advice from wealth manager and Vanderbilt Professor, Gary Kimball (BS'84) to help your finances conquer &amp; prevail!</p>\r\n<p>&nbsp;</p>\r\n<p>Money 101</p>\r\n<p>Wednesday, March 29</p>\r\n<p>5:30-6:30pm</p>\r\n<p>Wilson Hall, room 103</p>\r\n<p>*Free Chick-Fil-A*&nbsp;</p>\r\n<p>RSVP to sarah.quinn@vanderbilt.edu in Alumni Relations</p>\r\n<p>Money 101 is a \"Vanderbilt for Life\" program of your Vanderbilt Alumni Association and a part of the Life After Vanderbilt Series.</p></div>",
        "title": "Money 101",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Wilson Hall, Room 103</span></div> <div class=\"description\"><p>Thinking about how to budget, save and deal with debt when you graduate?&nbsp;</p>\r\n<p>Get advice from wealth manager and Vanderbilt Professor, Gary Kimball (BS'84) to help your finances conquer &amp; prevail!</p>\r\n<p>&nbsp;</p>\r\n<p>Money 101</p>\r\n<p>Wednesday, March 29</p>\r\n<p>5:30-6:30pm</p>\r\n<p>Wilson Hall, room 103</p>\r\n<p>*Free Chick-Fil-A*&nbsp;</p>\r\n<p>RSVP to sarah.quinn@vanderbilt.edu in Alumni Relations</p>\r\n<p>Money 101 is a \"Vanderbilt for Life\" program of your Vanderbilt Alumni Association and a part of the Life After Vanderbilt Series.</p></div>",
        "categories": [
            "Career Development"
        ],
        "location": "Wilson Hall, Room 103",
        "description": "Thinking about how to budget, save and deal with debt when you graduate? ; Get advice from wealth manager and Vanderbilt Professor, Gary Kimball (BS';84) to help your finances conquer &; prevail!  ; Money 101 Wednesday, March 29 5:30-6:30pm Wilson Hall, room 103 *Free Chick-Fil-A* ; RSVP to sarah.quinn@vanderbilt.edu in Alumni Relations Money 101 is a \";Vanderbilt for Life\"; program of your Vanderbilt Alumni Association and a part of the Life After Vanderbilt Series. "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam C216</span></div> <div class=\"description\"><p>This event will host a panel of women in science (PhD students, Post-doctoral fellow, MD/PhD, and clinical scientists) to talk about their careers and what lead them to their respective career paths. The first 15 minutes will have the panelists describing their experiences, while the remainder of the session will be up for student questions. The event is open to all ranges of students, post-docs and faculty.&nbsp;</p></div>",
        "title": "Career Panel Discussion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam C216</span></div> <div class=\"description\"><p>This event will host a panel of women in science (PhD students, Post-doctoral fellow, MD/PhD, and clinical scientists) to talk about their careers and what lead them to their respective career paths. The first 15 minutes will have the panelists describing their experiences, while the remainder of the session will be up for student questions. The event is open to all ranges of students, post-docs and faculty.&nbsp;</p></div>",
        "categories": [
            "Career Development",
            "Graduate/Professional Students",
            "Academic",
            "School of Medicine"
        ],
        "location": "Kissam C216",
        "description": "This event will host a panel of women in science (PhD students, Post-doctoral fellow, MD/PhD, and clinical scientists) to talk about their careers and what lead them to their respective career paths. The first 15 minutes will have the panelists describing their experiences, while the remainder of the session will be up for student questions. The event is open to all ranges of students, post-docs and faculty. ; "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Rand Hall Room 307</span></div> <div class=\"description\"><p>Join VRWC group fitness instructor, Nephie, in our guided meditation class on March 29th at 5:30pm!<br /><br />This class is meant to help support participants on the road to creating and/or maintaining a regular daily practice. We will do a centering meditation, hear from texts on a topic, guided meditation, and silent mediation. Meditation techniques sample from a variety of different traditions.</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Rand Hall Room 307</span></div> <div class=\"description\"><p>Join VRWC group fitness instructor, Nephie, in our guided meditation class on March 29th at 5:30pm!<br /><br />This class is meant to help support participants on the road to creating and/or maintaining a regular daily practice. We will do a centering meditation, hear from texts on a topic, guided meditation, and silent mediation. Meditation techniques sample from a variety of different traditions.</p></div>",
        "categories": [
            "Health & Wellness"
        ],
        "location": "Rand Hall Room 307",
        "description": "Join VRWC group fitness instructor, Nephie, in our guided meditation class on March 29th at 5:30pm! This class is meant to help support participants on the road to creating and/or maintaining a regular daily practice. We will do a centering meditation, hear from texts on a topic, guided meditation, and silent mediation. Meditation techniques sample from a variety of different traditions. "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Our mentorship program would feature networking events for undergraduate female students. Our goal is to facilitate a relationship between the female undergraduates with both Owen Graduate female students and business women in Nashville. We aspire to inspire young business women by connecting them with these women who&nbsp;can advise undergraduates by drawing on personal business experiences.</p></div>",
        "title": "Mentorship Program - Networking Event (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Our mentorship program would feature networking events for undergraduate female students. Our goal is to facilitate a relationship between the female undergraduates with both Owen Graduate female students and business women in Nashville. We aspire to inspire young business women by connecting them with these women who&nbsp;can advise undergraduates by drawing on personal business experiences.</p></div>",
        "categories": [
            "Women & Gender Issues",
            "Career Development"
        ],
        "location": "Alumni Hall",
        "description": "Cancelled  Our mentorship program would feature networking events for undergraduate female students. Our goal is to facilitate a relationship between the female undergraduates with both Owen Graduate female students and business women in Nashville. We aspire to inspire young business women by connecting them with these women who ;can advise undergraduates by drawing on personal business experiences. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>Join VPB Speaker's Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr.&nbsp;</p></div>",
        "title": "VPB Speaker's Committee presents IMPACT Symposium 2017",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>Join VPB Speaker's Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr.&nbsp;</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "GME - Diversity & Inclusion",
            "MVE - Service & Civic Engagement Track"
        ],
        "location": "Langford Auditorium",
        "description": "Join VPB Speaker';s Committee for its annual three day speaking symposium. Speakers from a range of backgrounds and perspectives will focus on a three day thematic conversation with the goal of furthering campus dialogue on relevant social, political, and international issues at Vanderbilt University. Past speakers have included Speaker John Boehner, Spike Lee, Mitt Romney, Madeleine Albright, Colin Powell, Stokely Carmichael, and Martin Luther King Jr. ; "
    },
    {
        "time": "19:30:00",
        "date": "2017-03-29",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by: Lynn Ramey, Associate Professor of French</p>\r\n<p><strong>Canada</strong>&nbsp;(1991) Dir: Bruce Beresford. A Jesuit priest and his companion&nbsp;come&nbsp;to the New World on a mission to convert Native Americans. Confronting the inhospitable Canadian winter, the two Europeans take learn very different lessons about their relationship to the land and people they encounter. Beautifully shot but dark both visually and emotionally, the film forces the viewer to think about religion, colonization, and cultural encounter. Critically acclaimed in many quarters, the film provoked strong responses from indigenous communities in Canada. English, Latin, Cree, Mohawk, Algonquin. 101 min. DVD <em>Presented in collaboration with the Department of French &amp; Italian</em></p></div>",
        "title": "iLens: Black Robe (Robe noir)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-29\">Wednesday, March 29, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by: Lynn Ramey, Associate Professor of French</p>\r\n<p><strong>Canada</strong>&nbsp;(1991) Dir: Bruce Beresford. A Jesuit priest and his companion&nbsp;come&nbsp;to the New World on a mission to convert Native Americans. Confronting the inhospitable Canadian winter, the two Europeans take learn very different lessons about their relationship to the land and people they encounter. Beautifully shot but dark both visually and emotionally, the film forces the viewer to think about religion, colonization, and cultural encounter. Critically acclaimed in many quarters, the film provoked strong responses from indigenous communities in Canada. English, Latin, Cree, Mohawk, Algonquin. 101 min. DVD <em>Presented in collaboration with the Department of French &amp; Italian</em></p></div>",
        "categories": [
            "International",
            "Film/Movie",
            "Political"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by: Lynn Ramey, Associate Professor of French Canada ;(1991) Dir: Bruce Beresford. A Jesuit priest and his companion ;come ;to the New World on a mission to convert Native Americans. Confronting the inhospitable Canadian winter, the two Europeans take learn very different lessons about their relationship to the land and people they encounter. Beautifully shot but dark both visually and emotionally, the film forces the viewer to think about religion, colonization, and cultural encounter. Critically acclaimed in many quarters, the film provoked strong responses from indigenous communities in Canada. English, Latin, Cree, Mohawk, Algonquin. 101 min. DVD Presented in collaboration with the Department of French &; Italian "
    },
    {
        "time": "09:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "Health & Wellness",
            "My Vanderbilt Experience",
            "MVE - Health & Wellness Track",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "11:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Resilience 101 focuses on the development and application of real-world skills that students can use during times of challenge and personal growth. Students will learn what resilience is, be given the opportunity to begin crafting a personal narrative that demonstrates their ability to thrive, and examine resilience-based strategies and skills. The central themes of these skills will revolve around internal and external gratitude as well as developing meaningful relationships. Ultimately, this session will encourage students to develop and engage in practices, routines, and habits that heighten how they feel, encourage a positive state of mind, and help them successfully navigate difficult situations to ensure they are getting the most out of their experience at Vanderbilt University.</p></div>",
        "title": "Resilience 101",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Resilience 101 focuses on the development and application of real-world skills that students can use during times of challenge and personal growth. Students will learn what resilience is, be given the opportunity to begin crafting a personal narrative that demonstrates their ability to thrive, and examine resilience-based strategies and skills. The central themes of these skills will revolve around internal and external gratitude as well as developing meaningful relationships. Ultimately, this session will encourage students to develop and engage in practices, routines, and habits that heighten how they feel, encourage a positive state of mind, and help them successfully navigate difficult situations to ensure they are getting the most out of their experience at Vanderbilt University.</p></div>",
        "categories": [
            "GME - Healthy Behaviors",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "My Vanderbilt Experience"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Resilience 101 focuses on the development and application of real-world skills that students can use during times of challenge and personal growth. Students will learn what resilience is, be given the opportunity to begin crafting a personal narrative that demonstrates their ability to thrive, and examine resilience-based strategies and skills. The central themes of these skills will revolve around internal and external gratitude as well as developing meaningful relationships. Ultimately, this session will encourage students to develop and engage in practices, routines, and habits that heighten how they feel, encourage a positive state of mind, and help them successfully navigate difficult situations to ensure they are getting the most out of their experience at Vanderbilt University. "
    },
    {
        "time": "11:30:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:30:00\">11:30 AM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Multicultural Lounge</span></div> <div class=\"description\"><p>Join IICC for our&nbsp;End of the Month Kickback series for students to build community, relax, and recharge before the start of the new month. &nbsp;Join us in Sarratt 337/Multicultural Lounge for snacks, board games, and good company!</p></div>",
        "title": "End of the Month Kickback",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:30:00\">11:30 AM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Multicultural Lounge</span></div> <div class=\"description\"><p>Join IICC for our&nbsp;End of the Month Kickback series for students to build community, relax, and recharge before the start of the new month. &nbsp;Join us in Sarratt 337/Multicultural Lounge for snacks, board games, and good company!</p></div>",
        "categories": [
            "Diversity & Inclusion"
        ],
        "location": "Multicultural Lounge",
        "description": "Join IICC for our ;End of the Month Kickback series for students to build community, relax, and recharge before the start of the new month.  ;Join us in Sarratt 337/Multicultural Lounge for snacks, board games, and good company! "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Atrium</span></div> <div class=\"description\"><p>The Engineering Council will be holding a free lunch&nbsp;for all engineering students.</p></div>",
        "title": "March Lunch Social",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Atrium</span></div> <div class=\"description\"><p>The Engineering Council will be holding a free lunch&nbsp;for all engineering students.</p></div>",
        "categories": [],
        "location": "Featheringill Atrium",
        "description": "The Engineering Council will be holding a free lunch ;for all engineering students. "
    },
    {
        "time": "12:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 208</span></div> <div class=\"description\"><div>Literature, Arts, &amp; Medicine is pleased to host the Cultural Series, a monthly creative performance lunch hour, this Thursday, March 30&nbsp;from 12-1pm in LH 208.&nbsp;Please come enjoy performances in music, dance, literary readings, art, and more by friends and colleagues.</div>\r\n<div>&nbsp;</div>\r\n<div>Sign up&nbsp;<a href=\"https://email.vanderbilt.edu/owa/redir.aspx?SURL=HDNCATE776DKQL_nwLmh5V0Hh3tkQHCm65KihJoJXgCkgN6GbdDTCGgAdAB0AHAAcwA6AC8ALwBkAG8AYwBzAC4AZwBvAG8AZwBsAGUALgBjAG8AbQAvAGYAbwByAG0AcwAvAGQALwAxAGgAZwBvADUAaQBhADAAMAAwADYAdAB3AHgAOABMAEUAYwA3AHIAeQBvADkAQwAyAGwASQAzAEIAQwA0AFoAQwBhAFAATQBsAFoAUQBpAHYAbgBhAE0ALwB2AGkAZQB3AGYAbwByAG0A&amp;URL=https%3a%2f%2fdocs.google.com%2fforms%2fd%2f1hgo5ia0006twx8LEc7ryo9C2lI3BC4ZCaPMlZQivnaM%2fviewform\" target=\"_blank\">here</a>&nbsp;if you would like to perform or showcase your art this month&nbsp;or any future month!&nbsp;Impromptu performances are always welcome, so feel free to perform something at the end even if you didn&rsquo;t sign up ahead of time.</div>\r\n<div>&nbsp;</div>\r\n<div>All are welcome, and <strong>food and beverage is provided</strong>. If you can't make the event but would like to watch online in real-time or after the event, please check out this&nbsp;<a href=\"http://mediasite.vanderbilt.edu/Mediasite/Play/f4d0c8d2450f4249b410b05edfad492c1d\">Mediasite link</a>!</div>\r\n<div>&nbsp;</div></div>",
        "title": "Literature, Arts, & Medicine: Cultural Series",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 208</span></div> <div class=\"description\"><div>Literature, Arts, &amp; Medicine is pleased to host the Cultural Series, a monthly creative performance lunch hour, this Thursday, March 30&nbsp;from 12-1pm in LH 208.&nbsp;Please come enjoy performances in music, dance, literary readings, art, and more by friends and colleagues.</div>\r\n<div>&nbsp;</div>\r\n<div>Sign up&nbsp;<a href=\"https://email.vanderbilt.edu/owa/redir.aspx?SURL=HDNCATE776DKQL_nwLmh5V0Hh3tkQHCm65KihJoJXgCkgN6GbdDTCGgAdAB0AHAAcwA6AC8ALwBkAG8AYwBzAC4AZwBvAG8AZwBsAGUALgBjAG8AbQAvAGYAbwByAG0AcwAvAGQALwAxAGgAZwBvADUAaQBhADAAMAAwADYAdAB3AHgAOABMAEUAYwA3AHIAeQBvADkAQwAyAGwASQAzAEIAQwA0AFoAQwBhAFAATQBsAFoAUQBpAHYAbgBhAE0ALwB2AGkAZQB3AGYAbwByAG0A&amp;URL=https%3a%2f%2fdocs.google.com%2fforms%2fd%2f1hgo5ia0006twx8LEc7ryo9C2lI3BC4ZCaPMlZQivnaM%2fviewform\" target=\"_blank\">here</a>&nbsp;if you would like to perform or showcase your art this month&nbsp;or any future month!&nbsp;Impromptu performances are always welcome, so feel free to perform something at the end even if you didn&rsquo;t sign up ahead of time.</div>\r\n<div>&nbsp;</div>\r\n<div>All are welcome, and <strong>food and beverage is provided</strong>. If you can't make the event but would like to watch online in real-time or after the event, please check out this&nbsp;<a href=\"http://mediasite.vanderbilt.edu/Mediasite/Play/f4d0c8d2450f4249b410b05edfad492c1d\">Mediasite link</a>!</div>\r\n<div>&nbsp;</div></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "LH 208",
        "description": "Literature, Arts, &; Medicine is pleased to host the Cultural Series, a monthly creative performance lunch hour, this Thursday, March 30 ;from 12-1pm in LH 208. ;Please come enjoy performances in music, dance, literary readings, art, and more by friends and colleagues.  ; Sign up ; [here] (https://email.vanderbilt.edu/owa/redir.aspx?SURL=HDNCATE776DKQL_nwLmh5V0Hh3tkQHCm65KihJoJXgCkgN6GbdDTCGgAdAB0AHAAcwA6AC8ALwBkAG8AYwBzAC4AZwBvAG8AZwBsAGUALgBjAG8AbQAvAGYAbwByAG0AcwAvAGQALwAxAGgAZwBvADUAaQBhADAAMAAwADYAdAB3AHgAOABMAEUAYwA3AHIAeQBvADkAQwAyAGwASQAzAEIAQwA0AFoAQwBhAFAATQBsAFoAUQBpAHYAbgBhAE0ALwB2AGkAZQB3AGYAbwByAG0A&;URL=https%3a%2f%2fdocs.google.com%2fforms%2fd%2f1hgo5ia0006twx8LEc7ryo9C2lI3BC4ZCaPMlZQivnaM%2fviewform)  ;if you would like to perform or showcase your art this month ;or any future month! ;Impromptu performances are always welcome, so feel free to perform something at the end even if you didn&#x2019;t sign up ahead of time.  ; All are welcome, and food and beverage is provided. If you can';t make the event but would like to watch online in real-time or after the event, please check out this ; [Mediasite link] (http://mediasite.vanderbilt.edu/Mediasite/Play/f4d0c8d2450f4249b410b05edfad492c1d) !  ; "
    },
    {
        "time": "15:15:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "MVE - Health & Wellness Track",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "17:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 202</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">A meeting with Enrollment Services to provide an overview of the logistics of registering in YES. Open to VMS2 and VMS3 who will be registering for the Immersion Phase in April 2017.</span></p></div>",
        "title": "Immersion Phase: How to Register (Logistics)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 202</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">A meeting with Enrollment Services to provide an overview of the logistics of registering in YES. Open to VMS2 and VMS3 who will be registering for the Immersion Phase in April 2017.</span></p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall 202",
        "description": "A meeting with Enrollment Services to provide an overview of the logistics of registering in YES. Open to VMS2 and VMS3 who will be registering for the Immersion Phase in April 2017. "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">3rd floor Light Hall couches, North lobby side</span></div> <div class=\"description\"><p>Come knit and crochet with VMS Knits for (K)Nashville! We create various projects for underserved communities in Nashville, such as our Shade Tree patients. No knitting/crocheting experience necessary, and we provide all the supplies. Hope to see you there!</p></div>",
        "title": "VMS Knits weekly meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">3rd floor Light Hall couches, North lobby side</span></div> <div class=\"description\"><p>Come knit and crochet with VMS Knits for (K)Nashville! We create various projects for underserved communities in Nashville, such as our Shade Tree patients. No knitting/crocheting experience necessary, and we provide all the supplies. Hope to see you there!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "3rd floor Light Hall couches, North lobby side",
        "description": "Come knit and crochet with VMS Knits for (K)Nashville! We create various projects for underserved communities in Nashville, such as our Shade Tree patients. No knitting/crocheting experience necessary, and we provide all the supplies. Hope to see you there! "
    },
    {
        "time": "17:30:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Rand Lounge</span></div> <div class=\"description\"><p>Vanderbilt Music Outreach's annual benefit concert is here! Come to VMO Palooza for food and live music performances!&nbsp;</p>\r\n<p>In addition to food we will also be giving out shirts&nbsp;on a first come first serve basis. Donations will be accepted and all proceeds will go to W.O. Smith Music School in Nashville, TN.</p>\r\n<p>&nbsp;</p>\r\n<p>And it's completely FREE! So come join us for a fun night you won't forget!</p></div>",
        "title": "VMO Palooza Concert",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Rand Lounge</span></div> <div class=\"description\"><p>Vanderbilt Music Outreach's annual benefit concert is here! Come to VMO Palooza for food and live music performances!&nbsp;</p>\r\n<p>In addition to food we will also be giving out shirts&nbsp;on a first come first serve basis. Donations will be accepted and all proceeds will go to W.O. Smith Music School in Nashville, TN.</p>\r\n<p>&nbsp;</p>\r\n<p>And it's completely FREE! So come join us for a fun night you won't forget!</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Rand Lounge",
        "description": "Vanderbilt Music Outreach';s annual benefit concert is here! Come to VMO Palooza for food and live music performances! ; In addition to food we will also be giving out shirts ;on a first come first serve basis. Donations will be accepted and all proceeds will go to W.O. Smith Music School in Nashville, TN.  ; And it';s completely FREE! So come join us for a fun night you won';t forget! "
    },
    {
        "time": "18:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 363</span></div> <div class=\"description\"><p>The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &ndash; resulting in the reduction of violence. This one-hour educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) and introduces bystander intervention strategies.</p></div>",
        "title": "Green Dot Overview",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 363</span></div> <div class=\"description\"><p>The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &ndash; resulting in the reduction of violence. This one-hour educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) and introduces bystander intervention strategies.</p></div>",
        "categories": [
            "Health & Wellness"
        ],
        "location": "Sarratt 363",
        "description": "The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &#x2013; resulting in the reduction of violence. This one-hour educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) and introduces bystander intervention strategies. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Hank Lobby</span></div> <div class=\"description\"><p>Learn how to dance bhangra and its cultural history, and enjoy tasty Indian snacks!</p></div>",
        "title": "Hank Bhangra",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Hank Lobby</span></div> <div class=\"description\"><p>Learn how to dance bhangra and its cultural history, and enjoy tasty Indian snacks!</p></div>",
        "categories": [
            "Diversity & Inclusion"
        ],
        "location": "Hank Lobby",
        "description": "Learn how to dance bhangra and its cultural history, and enjoy tasty Indian snacks! "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam MPR</span></div> <div class=\"description\"><p>Moore College Council presents...Sips n' Strokes. Join us for mocktails, snacks, and to paint the Nashville skyline! Sign-up is required.&nbsp;</p></div>",
        "title": "Sips n' Strokes",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam MPR</span></div> <div class=\"description\"><p>Moore College Council presents...Sips n' Strokes. Join us for mocktails, snacks, and to paint the Nashville skyline! Sign-up is required.&nbsp;</p></div>",
        "categories": [],
        "location": "Kissam MPR",
        "description": "Moore College Council presents...Sips n'; Strokes. Join us for mocktails, snacks, and to paint the Nashville skyline! Sign-up is required. ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Sultan's Grill</span></div> <div class=\"description\"><p>Join the Med-Peds and Family Medicine Interest&nbsp;Group chairs for our post-match meeting to learn more about why to choose a career in Family Medicine/Med-Peds and to hear some practical tips for the application process! We will be meeting at Sultan's Grill (1602 21st Ave S, Nashville, TN 37212) and covering the appetizers (and possibly the entire meal depending on how many folks turn out!)! Hope to see you there!</p></div>",
        "title": "Med-Peds/Family Medicine Post-Match Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Sultan's Grill</span></div> <div class=\"description\"><p>Join the Med-Peds and Family Medicine Interest&nbsp;Group chairs for our post-match meeting to learn more about why to choose a career in Family Medicine/Med-Peds and to hear some practical tips for the application process! We will be meeting at Sultan's Grill (1602 21st Ave S, Nashville, TN 37212) and covering the appetizers (and possibly the entire meal depending on how many folks turn out!)! Hope to see you there!</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Sultan's Grill",
        "description": "Join the Med-Peds and Family Medicine Interest ;Group chairs for our post-match meeting to learn more about why to choose a career in Family Medicine/Med-Peds and to hear some practical tips for the application process! We will be meeting at Sultan';s Grill (1602 21st Ave S, Nashville, TN 37212) and covering the appetizers (and possibly the entire meal depending on how many folks turn out!)! Hope to see you there! "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">McTyeire International House, Fireside Lounge</span></div> <div class=\"description\"><p><strong>McTyeire Fireside Chat: \"Poison and Magic in XIV&rsquo;s Paris\"&nbsp;</strong></p>\r\n<p>&nbsp;</p>\r\n<p>Holly Tucker, Professor of French and MHS, will talk about her new book<strong> &lsquo;<em>City of Light, City of Poison: Murder, Magic, and the First Police Chief of Paris</em>&rsquo;</strong>, a true-crime tale of deception and murder.</p></div>",
        "title": "McTyeire Fireside Chat: \"Poison and Magic in XIV’s Paris\"",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">McTyeire International House, Fireside Lounge</span></div> <div class=\"description\"><p><strong>McTyeire Fireside Chat: \"Poison and Magic in XIV&rsquo;s Paris\"&nbsp;</strong></p>\r\n<p>&nbsp;</p>\r\n<p>Holly Tucker, Professor of French and MHS, will talk about her new book<strong> &lsquo;<em>City of Light, City of Poison: Murder, Magic, and the First Police Chief of Paris</em>&rsquo;</strong>, a true-crime tale of deception and murder.</p></div>",
        "categories": [
            "International",
            "Academic"
        ],
        "location": "McTyeire International House, Fireside Lounge",
        "description": "McTyeire Fireside Chat: \";Poison and Magic in XIV&#x2019;s Paris\"; ;  ; Holly Tucker, Professor of French and MHS, will talk about her new book &#x2018;City of Light, City of Poison: Murder, Magic, and the First Police Chief of Paris&#x2019;, a true-crime tale of deception and murder. "
    },
    {
        "time": "19:00:00",
        "date": "2017-03-30",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">McTyeire International House, Fireside Lounge</span></div> <div class=\"description\"><p><strong>McTyeire Fireside Chat: \"Poison and Magic in XIV&rsquo;s Paris\"&nbsp;</strong></p>\r\n<p>&nbsp;</p>\r\n<p>Holly Tucker, Professor of French and MHS, will talk about her new book<strong> &lsquo;<em>City of Light, City of Poison: Murder, Magic, and the First Police Chief of Paris</em>&rsquo;</strong>, a true-crime tale of deception and murder.</p></div>",
        "title": "McTyeire Fireside Chat: \"Poison and Magic in XIV’s Paris\"",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-30\">Thursday, March 30, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">McTyeire International House, Fireside Lounge</span></div> <div class=\"description\"><p><strong>McTyeire Fireside Chat: \"Poison and Magic in XIV&rsquo;s Paris\"&nbsp;</strong></p>\r\n<p>&nbsp;</p>\r\n<p>Holly Tucker, Professor of French and MHS, will talk about her new book<strong> &lsquo;<em>City of Light, City of Poison: Murder, Magic, and the First Police Chief of Paris</em>&rsquo;</strong>, a true-crime tale of deception and murder.</p></div>",
        "categories": [
            "International",
            "Academic"
        ],
        "location": "McTyeire International House, Fireside Lounge",
        "description": "McTyeire Fireside Chat: \";Poison and Magic in XIV&#x2019;s Paris\"; ;  ; Holly Tucker, Professor of French and MHS, will talk about her new book &#x2018;City of Light, City of Poison: Murder, Magic, and the First Police Chief of Paris&#x2019;, a true-crime tale of deception and murder. "
    },
    {
        "time": "09:30:00",
        "date": "2017-03-31",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:30:00\">9:30 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Stapleton Lounge</span></div> <div class=\"description\"><p>Monday morning coffee in the Stapleton lobby to&nbsp;start the week off with a caffeine boost</p></div>",
        "title": "Stape Coffee",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:30:00\">9:30 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Stapleton Lounge</span></div> <div class=\"description\"><p>Monday morning coffee in the Stapleton lobby to&nbsp;start the week off with a caffeine boost</p></div>",
        "categories": [],
        "location": "Stapleton Lounge",
        "description": "Monday morning coffee in the Stapleton lobby to ;start the week off with a caffeine boost "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-31",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>What is MAPS?</p>\r\n<p>MAPS is a joint initiative between the Center for Student Wellbeing and the Psychological and Counseling Center (PCC) initiative to prevent suicide in the campus community while promoting mental health awareness. MAPS was&nbsp;funded by a grant from the Substance Abuse and Mental Health Services Administration (SAMHSA) of the U.S. government's Department of Health and Human Services.</p>\r\n<p>What does MAPS do? The goal of MAPS is to work toward suicide prevention and mental health awareness through education and outreach in the campus community. The PCC staff will work with its campus partners throughout Vanderbilt University to provide skills to students, faculty, and staff to identify and assist those in need of help due to mental health concerns.</p>\r\n<p>Why is MAPS important? MAPS will help address a major public health problem: suicide. Over 30,000 people die by suicide in the United States each year &ndash; approximately one person every 18 minutes. Suicide is the third leading cause of death among Americans between the ages of 15-24, the time when most students attend college. There is also a strong association between suicide and mental illness. Suicide is a preventable phenomenon, and MAPS will help in that prevention. &nbsp;</p>\r\n<p>&nbsp;</p></div>",
        "title": "MAPS Training (Mental health Awareness & Preventio...",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>What is MAPS?</p>\r\n<p>MAPS is a joint initiative between the Center for Student Wellbeing and the Psychological and Counseling Center (PCC) initiative to prevent suicide in the campus community while promoting mental health awareness. MAPS was&nbsp;funded by a grant from the Substance Abuse and Mental Health Services Administration (SAMHSA) of the U.S. government's Department of Health and Human Services.</p>\r\n<p>What does MAPS do? The goal of MAPS is to work toward suicide prevention and mental health awareness through education and outreach in the campus community. The PCC staff will work with its campus partners throughout Vanderbilt University to provide skills to students, faculty, and staff to identify and assist those in need of help due to mental health concerns.</p>\r\n<p>Why is MAPS important? MAPS will help address a major public health problem: suicide. Over 30,000 people die by suicide in the United States each year &ndash; approximately one person every 18 minutes. Suicide is the third leading cause of death among Americans between the ages of 15-24, the time when most students attend college. There is also a strong association between suicide and mental illness. Suicide is a preventable phenomenon, and MAPS will help in that prevention. &nbsp;</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Health & Wellness",
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "What is MAPS? MAPS is a joint initiative between the Center for Student Wellbeing and the Psychological and Counseling Center (PCC) initiative to prevent suicide in the campus community while promoting mental health awareness. MAPS was ;funded by a grant from the Substance Abuse and Mental Health Services Administration (SAMHSA) of the U.S. government';s Department of Health and Human Services. What does MAPS do? The goal of MAPS is to work toward suicide prevention and mental health awareness through education and outreach in the campus community. The PCC staff will work with its campus partners throughout Vanderbilt University to provide skills to students, faculty, and staff to identify and assist those in need of help due to mental health concerns. Why is MAPS important? MAPS will help address a major public health problem: suicide. Over 30,000 people die by suicide in the United States each year &#x2013; approximately one person every 18 minutes. Suicide is the third leading cause of death among Americans between the ages of 15-24, the time when most students attend college. There is also a strong association between suicide and mental illness. Suicide is a preventable phenomenon, and MAPS will help in that prevention.  ;  ; "
    },
    {
        "time": "10:00:00",
        "date": "2017-03-31",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Graduate/Professional Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "My Vanderbilt Experience",
            "Greek Member Experience",
            "MVE - Health & Wellness Track",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "19:30:00",
        "date": "2017-03-31",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>We finna make sum jokes!</p></div>",
        "title": "Tongue 'N' Cheek Show",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-03-31\">Friday, March 31, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>We finna make sum jokes!</p></div>",
        "categories": [
            "MVE - Arts Track",
            "GME - Campus Involvement",
            "Greek Member Experience",
            "My Vanderbilt Experience",
            "Religious/Spiritual",
            "Alcohol Free Late Night Programming",
            "Performing Arts"
        ],
        "location": "Sarratt Cinema",
        "description": "We finna make sum jokes! "
    },
    {
        "time": "08:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"08:00:00\">8:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">208 Light Hall</span></div> <div class=\"description\"><p>Your CCO Presidents along with the Medicine and Business Society and the CiM Business in Medicine group plan to offer an enhancement to medical student education in regards to essential business understanding relevant for any physician leader.&nbsp;</p>\r\n<p>This morning workshop from 8AM - 1PM will feature prominent members in the medical community to whom business has become an essential part of their roles as physicians and administrators. The focus will be on narratives and interactive workshops.&nbsp;</p>\r\n<p>Breakfast and Lunch will be provided! RSVP if you want food.</p></div>",
        "title": "Enterprise in Medicine: A Business Learning Workshop for Medical Students",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"08:00:00\">8:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">208 Light Hall</span></div> <div class=\"description\"><p>Your CCO Presidents along with the Medicine and Business Society and the CiM Business in Medicine group plan to offer an enhancement to medical student education in regards to essential business understanding relevant for any physician leader.&nbsp;</p>\r\n<p>This morning workshop from 8AM - 1PM will feature prominent members in the medical community to whom business has become an essential part of their roles as physicians and administrators. The focus will be on narratives and interactive workshops.&nbsp;</p>\r\n<p>Breakfast and Lunch will be provided! RSVP if you want food.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "208 Light Hall",
        "description": "Your CCO Presidents along with the Medicine and Business Society and the CiM Business in Medicine group plan to offer an enhancement to medical student education in regards to essential business understanding relevant for any physician leader. ; This morning workshop from 8AM - 1PM will feature prominent members in the medical community to whom business has become an essential part of their roles as physicians and administrators. The focus will be on narratives and interactive workshops. ; Breakfast and Lunch will be provided! RSVP if you want food. "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-04-01T09:00:00\">Saturday, April 1, 2017 (9:00 AM)</span> - <span class=\"dtend\" title=\"2017-04-02T16:00:00\">Sunday, April 2, 2017 (4:00 PM)</span></b> <div>Location: <span class=\"location\">The Wond'ry</span></div> <div class=\"description\"><p>Welcome to our BIGGEST event of the year, 48-Hour Launch!<br /><br />Have a great business idea? Do you want to make it a reality!? This is FOR YOU!&nbsp;<br /><br />48-Hour Launch (April 1st and 2nd) is a great opportunity for you to turn your business idea into action, and learn more as you go along the business planning process through mini lectures and individual mentoring by Nashville entrepreneurs. The head of the Pre-Flight program, John Murdock, will condense his seven-week course into only 48 hours, giving a select number of students a snapshot experience into launching a startup. This weekend-long program will also give you valuable experience to talk about in your interviews and a killer project to add to your resume. The to<span class=\"text_exposed_show\">p teams will receive cash prizes, totalling $1,000!! However, with a cap on the amount of students we will be able to admit, only fully committed students will be admitted.<br /><br />VINES will be hosting an info session to give you details about the event this Wednesday, March 1st at 6pm in Featheringill Hall 110.&nbsp;<br />48-Hour Launch Applications are up on Anchorlink!! (<a href=\"https://l.facebook.com/l.php?u=https%3A%2F%2Fanchorlink.vanderbilt.edu%2Fform%2Fstart%2F122090&amp;h=ATP_I_zvkFleSJj_an6HonBemcvVnF7XEe_1r47mWTKFypPNRimV14LHsotkUflaYEIxzNMgFzyEVm69eDNuLKFQ7ZPW2tB68Nnyt4Ri6vBulXjbt-2nV3hx_-MZyhQrWZitGgs0ow&amp;enc=AZN--xMgXrw5pdOJBNzNOdxRvqPoplbMgNiZH32ELdmCZs2sSFZ6jH4tiJ2shP0-zUU&amp;s=1\" target=\"_blank\" rel=\"nofollow nofollow\">https://<wbr />anchorlink.vanderbilt.edu/<wbr />form/start/122090</a>).<br /><br />The schedule:<br /><br />Saturday April 1st:<br />9:00 am Introductions, overview of weekend and breakfast<br />9:30 am First Lecture: Business Model Basics, Value Proposition, and Competitive Advantage<br />10:30 am Workshop Session with mentors<br />12:00 pm Lunch<br />12:30 pm Second Lecture: Customer Validation<br />1:30 pm Workshop Session with mentors<br />3:30 pm Third Lecture: Building idea out further<br />4:30 pm Workshop Session with mentors and dinner<br />6:00 pm Day ends<br /><br />Sunday April 2nd:<br />9:00 am Fourth Lecture: Monetization<br />9:30 am Workshop Session with mentors<br />10:30 am Fifth Lecture: Marketing<br />11:00 am Workshop Session with mentors<br />12:00 pm Lunch<br />1:00 pm Pitch Training and Workshop Session with mentors<br />3:30 pm Dinner<br />4:00 pm Final Pitches and Prizes ($$$)<br /><br /><br />Other important dates:<br />March 1st: Formal 48-Hour Launch interest meeting<br />March 15th: Applications close<br />March 19th: Application success notified<br />March 22nd: Mandatory pre-48HL meeting for participants, at 7pm<br />The application can be accessed here!<br />PLEASE NOTE: If selected to participate, you are committed to fully attend and participate the program.</span></p></div>",
        "title": "48-Hour Launch",
        "summary": "<b><span class=\"dtstart\" title=\"2017-04-01T09:00:00\">Saturday, April 1, 2017 (9:00 AM)</span> - <span class=\"dtend\" title=\"2017-04-02T16:00:00\">Sunday, April 2, 2017 (4:00 PM)</span></b> <div>Location: <span class=\"location\">The Wond'ry</span></div> <div class=\"description\"><p>Welcome to our BIGGEST event of the year, 48-Hour Launch!<br /><br />Have a great business idea? Do you want to make it a reality!? This is FOR YOU!&nbsp;<br /><br />48-Hour Launch (April 1st and 2nd) is a great opportunity for you to turn your business idea into action, and learn more as you go along the business planning process through mini lectures and individual mentoring by Nashville entrepreneurs. The head of the Pre-Flight program, John Murdock, will condense his seven-week course into only 48 hours, giving a select number of students a snapshot experience into launching a startup. This weekend-long program will also give you valuable experience to talk about in your interviews and a killer project to add to your resume. The to<span class=\"text_exposed_show\">p teams will receive cash prizes, totalling $1,000!! However, with a cap on the amount of students we will be able to admit, only fully committed students will be admitted.<br /><br />VINES will be hosting an info session to give you details about the event this Wednesday, March 1st at 6pm in Featheringill Hall 110.&nbsp;<br />48-Hour Launch Applications are up on Anchorlink!! (<a href=\"https://l.facebook.com/l.php?u=https%3A%2F%2Fanchorlink.vanderbilt.edu%2Fform%2Fstart%2F122090&amp;h=ATP_I_zvkFleSJj_an6HonBemcvVnF7XEe_1r47mWTKFypPNRimV14LHsotkUflaYEIxzNMgFzyEVm69eDNuLKFQ7ZPW2tB68Nnyt4Ri6vBulXjbt-2nV3hx_-MZyhQrWZitGgs0ow&amp;enc=AZN--xMgXrw5pdOJBNzNOdxRvqPoplbMgNiZH32ELdmCZs2sSFZ6jH4tiJ2shP0-zUU&amp;s=1\" target=\"_blank\" rel=\"nofollow nofollow\">https://<wbr />anchorlink.vanderbilt.edu/<wbr />form/start/122090</a>).<br /><br />The schedule:<br /><br />Saturday April 1st:<br />9:00 am Introductions, overview of weekend and breakfast<br />9:30 am First Lecture: Business Model Basics, Value Proposition, and Competitive Advantage<br />10:30 am Workshop Session with mentors<br />12:00 pm Lunch<br />12:30 pm Second Lecture: Customer Validation<br />1:30 pm Workshop Session with mentors<br />3:30 pm Third Lecture: Building idea out further<br />4:30 pm Workshop Session with mentors and dinner<br />6:00 pm Day ends<br /><br />Sunday April 2nd:<br />9:00 am Fourth Lecture: Monetization<br />9:30 am Workshop Session with mentors<br />10:30 am Fifth Lecture: Marketing<br />11:00 am Workshop Session with mentors<br />12:00 pm Lunch<br />1:00 pm Pitch Training and Workshop Session with mentors<br />3:30 pm Dinner<br />4:00 pm Final Pitches and Prizes ($$$)<br /><br /><br />Other important dates:<br />March 1st: Formal 48-Hour Launch interest meeting<br />March 15th: Applications close<br />March 19th: Application success notified<br />March 22nd: Mandatory pre-48HL meeting for participants, at 7pm<br />The application can be accessed here!<br />PLEASE NOTE: If selected to participate, you are committed to fully attend and participate the program.</span></p></div>",
        "categories": [],
        "location": "The Wond'ry",
        "description": "Welcome to our BIGGEST event of the year, 48-Hour Launch! Have a great business idea? Do you want to make it a reality!? This is FOR YOU! ; 48-Hour Launch (April 1st and 2nd) is a great opportunity for you to turn your business idea into action, and learn more as you go along the business planning process through mini lectures and individual mentoring by Nashville entrepreneurs. The head of the Pre-Flight program, John Murdock, will condense his seven-week course into only 48 hours, giving a select number of students a snapshot experience into launching a startup. This weekend-long program will also give you valuable experience to talk about in your interviews and a killer project to add to your resume. The top teams will receive cash prizes, totalling $1,000!! However, with a cap on the amount of students we will be able to admit, only fully committed students will be admitted. VINES will be hosting an info session to give you details about the event this Wednesday, March 1st at 6pm in Featheringill Hall 110. ; 48-Hour Launch Applications are up on Anchorlink!! ( [https://anchorlink.vanderbilt.edu/form/start/122090] (https://l.facebook.com/l.php?u=https%3A%2F%2Fanchorlink.vanderbilt.edu%2Fform%2Fstart%2F122090&;h=ATP_I_zvkFleSJj_an6HonBemcvVnF7XEe_1r47mWTKFypPNRimV14LHsotkUflaYEIxzNMgFzyEVm69eDNuLKFQ7ZPW2tB68Nnyt4Ri6vBulXjbt-2nV3hx_-MZyhQrWZitGgs0ow&;enc=AZN--xMgXrw5pdOJBNzNOdxRvqPoplbMgNiZH32ELdmCZs2sSFZ6jH4tiJ2shP0-zUU&;s=1) ). The schedule: Saturday April 1st: 9:00 am Introductions, overview of weekend and breakfast 9:30 am First Lecture: Business Model Basics, Value Proposition, and Competitive Advantage 10:30 am Workshop Session with mentors 12:00 pm Lunch 12:30 pm Second Lecture: Customer Validation 1:30 pm Workshop Session with mentors 3:30 pm Third Lecture: Building idea out further 4:30 pm Workshop Session with mentors and dinner 6:00 pm Day ends Sunday April 2nd: 9:00 am Fourth Lecture: Monetization 9:30 am Workshop Session with mentors 10:30 am Fifth Lecture: Marketing 11:00 am Workshop Session with mentors 12:00 pm Lunch 1:00 pm Pitch Training and Workshop Session with mentors 3:30 pm Dinner 4:00 pm Final Pitches and Prizes ($$$) Other important dates: March 1st: Formal 48-Hour Launch interest meeting March 15th: Applications close March 19th: Application success notified March 22nd: Mandatory pre-48HL meeting for participants, at 7pm The application can be accessed here! PLEASE NOTE: If selected to participate, you are committed to fully attend and participate the program. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Nashville Food Project</span></div> <div class=\"description\"><p>Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the <a href=\"http://www.thenashvillefoodproject.org/\" target=\"_blank\">Nashville Food Project</a>. Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply.</p></div>",
        "title": "Redefine",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Nashville Food Project</span></div> <div class=\"description\"><p>Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the <a href=\"http://www.thenashvillefoodproject.org/\" target=\"_blank\">Nashville Food Project</a>. Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply.</p></div>",
        "categories": [
            "Service & Philanthropy",
            "International"
        ],
        "location": "Nashville Food Project",
        "description": "Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the [Nashville Food Project] (http://www.thenashvillefoodproject.org/) . Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\"><p>This year VSAP will be hosting a mini-conference in the Student Life Center. We will be bringing in a keynote speaker, Dr. LuoLuo Hong, to discuss underrepresented narratives of sexual violence. Throughout the day we will have different student groups write and present break out sessions on the topic, as well as an opportunity for the Project Safe Center to present on the state of sexual violence on our campus with the most recent data.&nbsp;We intend to make this an annual event, hoping to grow the conference into one for the entire SEC over the years. For now this event will be solely open to Vanderbilt students.</p></div>",
        "title": "VSAP Conference: Underrepresented Narratives of Sexual Violence",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center</span></div> <div class=\"description\"><p>This year VSAP will be hosting a mini-conference in the Student Life Center. We will be bringing in a keynote speaker, Dr. LuoLuo Hong, to discuss underrepresented narratives of sexual violence. Throughout the day we will have different student groups write and present break out sessions on the topic, as well as an opportunity for the Project Safe Center to present on the state of sexual violence on our campus with the most recent data.&nbsp;We intend to make this an annual event, hoping to grow the conference into one for the entire SEC over the years. For now this event will be solely open to Vanderbilt students.</p></div>",
        "categories": [
            "Diversity & Inclusion",
            "Health & Wellness",
            "Women & Gender Issues",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Student Life Center",
        "description": "This year VSAP will be hosting a mini-conference in the Student Life Center. We will be bringing in a keynote speaker, Dr. LuoLuo Hong, to discuss underrepresented narratives of sexual violence. Throughout the day we will have different student groups write and present break out sessions on the topic, as well as an opportunity for the Project Safe Center to present on the state of sexual violence on our campus with the most recent data. ;We intend to make this an annual event, hoping to grow the conference into one for the entire SEC over the years. For now this event will be solely open to Vanderbilt students. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Curry Field</span></div> <div class=\"description\"><p style=\"margin: 0in; margin-bottom: .0001pt;\"><span style=\"font-size: 11.0pt; font-family: 'Arial',sans-serif; color: black;\">The event will be a cultural showcase, with the theme this year being &ldquo;Truck art.\" We will have music, food, kite-flying, henna stalls and painting. This will be an interactive event in which we will play small games with prizes, and everyone will participate in painting a mural and small objects like coasters. This will be a free event. </span></p></div>",
        "title": "Pakistan Day",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Curry Field</span></div> <div class=\"description\"><p style=\"margin: 0in; margin-bottom: .0001pt;\"><span style=\"font-size: 11.0pt; font-family: 'Arial',sans-serif; color: black;\">The event will be a cultural showcase, with the theme this year being &ldquo;Truck art.\" We will have music, food, kite-flying, henna stalls and painting. This will be an interactive event in which we will play small games with prizes, and everyone will participate in painting a mural and small objects like coasters. This will be a free event. </span></p></div>",
        "categories": [
            "Diversity & Inclusion"
        ],
        "location": "Curry Field",
        "description": "The event will be a cultural showcase, with the theme this year being &#x201C;Truck art.\"; We will have music, food, kite-flying, henna stalls and painting. This will be an interactive event in which we will play small games with prizes, and everyone will participate in painting a mural and small objects like coasters. This will be a free event.  "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Wyatt Lawn</span></div> <div class=\"description\"><p>Come join the Vanderbilt Running Club and run our annual 5K! All proceeds benefit the Monroe Carell Jr. Children's Hospital at Vanderbilt.</p></div>",
        "title": "Fools 5K Benefitting Monroe Carell Jr. Children's Hospital",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Wyatt Lawn</span></div> <div class=\"description\"><p>Come join the Vanderbilt Running Club and run our annual 5K! All proceeds benefit the Monroe Carell Jr. Children's Hospital at Vanderbilt.</p></div>",
        "categories": [
            "Athletics"
        ],
        "location": "Wyatt Lawn",
        "description": "Come join the Vanderbilt Running Club and run our annual 5K! All proceeds benefit the Monroe Carell Jr. Children';s Hospital at Vanderbilt. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Magnolia Lawn</span></div> <div class=\"description\"><p>Come join the Vanderbilt Running Club as we host our annual 5K benefitting the Monroe Carell Jr. Children's Hospital! The 5K is a run, easy route around campus.&nbsp;</p></div>",
        "title": "Fools 5K Benefitting Monroe Carell Jr. Children's Hospital",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Magnolia Lawn</span></div> <div class=\"description\"><p>Come join the Vanderbilt Running Club as we host our annual 5K benefitting the Monroe Carell Jr. Children's Hospital! The 5K is a run, easy route around campus.&nbsp;</p></div>",
        "categories": [
            "Athletics"
        ],
        "location": "Magnolia Lawn",
        "description": "Come join the Vanderbilt Running Club as we host our annual 5K benefitting the Monroe Carell Jr. Children';s Hospital! The 5K is a run, easy route around campus. ; "
    },
    {
        "time": "11:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen School of Management</span></div> <div class=\"description\"><p>TBD</p></div>",
        "title": "2nd Annual TFC Social Ventures Summit",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen School of Management</span></div> <div class=\"description\"><p>TBD</p></div>",
        "categories": [],
        "location": "Owen School of Management",
        "description": "TBD "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Phi Delta Theta</span></div> <div class=\"description\"><p>On Saturday, April 1st, the brothers of Phi Delta Theta will host our Annual Vann Webb Memorial Pig Roast, a benefit that honors the memory of our brother Vann Webb who passed away in his sophomore year at Vanderbilt from a rare form of neuroendocrine cancer.</p>\r\n<p>Vann was an outstanding student and leader on campus. In just two short years of being on campus, most everyone at Vanderbilt and within Phi Delta Theta would agree that greater than his intellect or courage was his enormous heart and personality. He was a loyal brother of our chapter and a tremendous friend that brightened the lives of everyone around him.</p>\r\n<p>The event raises proceeds for the Tennessee Chapter of the ALS Association and supports those with Lou Gehrig's disease in the Middle Tennessee area who cannot afford the care they need. It will be held at the Phi Delta Theta house, where we will enjoy live music, barbecue, a corn hole tournament, drinks, and a roasted pig from 12:00pm-3:00pm. <br /><br />Come out and help us greatly improve the lives of those with ALS by donating in whatever way possible. Tickets will be available at the Wall later this semester and checks will be graciously accepted at the door of the event itself.<span class=\"text_exposed_show\"><br /><br /></span></p></div>",
        "title": "Vann Webb Memorial Pig Roast",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Phi Delta Theta</span></div> <div class=\"description\"><p>On Saturday, April 1st, the brothers of Phi Delta Theta will host our Annual Vann Webb Memorial Pig Roast, a benefit that honors the memory of our brother Vann Webb who passed away in his sophomore year at Vanderbilt from a rare form of neuroendocrine cancer.</p>\r\n<p>Vann was an outstanding student and leader on campus. In just two short years of being on campus, most everyone at Vanderbilt and within Phi Delta Theta would agree that greater than his intellect or courage was his enormous heart and personality. He was a loyal brother of our chapter and a tremendous friend that brightened the lives of everyone around him.</p>\r\n<p>The event raises proceeds for the Tennessee Chapter of the ALS Association and supports those with Lou Gehrig's disease in the Middle Tennessee area who cannot afford the care they need. It will be held at the Phi Delta Theta house, where we will enjoy live music, barbecue, a corn hole tournament, drinks, and a roasted pig from 12:00pm-3:00pm. <br /><br />Come out and help us greatly improve the lives of those with ALS by donating in whatever way possible. Tickets will be available at the Wall later this semester and checks will be graciously accepted at the door of the event itself.<span class=\"text_exposed_show\"><br /><br /></span></p></div>",
        "categories": [
            "Fraternity (For Organizations Advised by Greek Life)"
        ],
        "location": "Phi Delta Theta",
        "description": "On Saturday, April 1st, the brothers of Phi Delta Theta will host our Annual Vann Webb Memorial Pig Roast, a benefit that honors the memory of our brother Vann Webb who passed away in his sophomore year at Vanderbilt from a rare form of neuroendocrine cancer. Vann was an outstanding student and leader on campus. In just two short years of being on campus, most everyone at Vanderbilt and within Phi Delta Theta would agree that greater than his intellect or courage was his enormous heart and personality. He was a loyal brother of our chapter and a tremendous friend that brightened the lives of everyone around him. The event raises proceeds for the Tennessee Chapter of the ALS Association and supports those with Lou Gehrig';s disease in the Middle Tennessee area who cannot afford the care they need. It will be held at the Phi Delta Theta house, where we will enjoy live music, barbecue, a corn hole tournament, drinks, and a roasted pig from 12:00pm-3:00pm.  Come out and help us greatly improve the lives of those with ALS by donating in whatever way possible. Tickets will be available at the Wall later this semester and checks will be graciously accepted at the door of the event itself. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Stambaugh</span></div> <div class=\"description\"><p>Multicultural music and food festival to raise awareness of immigrant communities and life transitions.</p></div>",
        "title": "StamJam",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Stambaugh</span></div> <div class=\"description\"><p>Multicultural music and food festival to raise awareness of immigrant communities and life transitions.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Diversity & Inclusion"
        ],
        "location": "Stambaugh",
        "description": "Multicultural music and food festival to raise awareness of immigrant communities and life transitions. "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>From 1-4 PM on Alumni Lawn, come and de-stress with puppies and dogs! There will be plenty and plenty of dogs on the lawn from various rescue groups around Nashville. Stay as long as you want and we can't wait to see you there!&nbsp;</p></div>",
        "title": "Puppy Play Date",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>From 1-4 PM on Alumni Lawn, come and de-stress with puppies and dogs! There will be plenty and plenty of dogs on the lawn from various rescue groups around Nashville. Stay as long as you want and we can't wait to see you there!&nbsp;</p></div>",
        "categories": [
            "Health & Wellness"
        ],
        "location": "Alumni Lawn",
        "description": "From 1-4 PM on Alumni Lawn, come and de-stress with puppies and dogs! There will be plenty and plenty of dogs on the lawn from various rescue groups around Nashville. Stay as long as you want and we can';t wait to see you there! ; "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:30:00\">4:30 PM</span>)</b> <div>Location: <span class=\"location\">Presentation Room</span></div> <div class=\"description\">Cancelled <br/><br/> <p><span style=\"font-weight: 400;\">The event will open with a performance from a performing arts group, either a dance or a song from a choir or acapella group, that showcases all the turns that life can take. Then, a series of stories will follow, with experts coming onto a stage with a single microphone. The stories will follow the life of a fictional character, whose life is the compilation of different experts&rsquo; stories from over the years. First, a worker at a crisis pregnancy resource center will appear on the stage. They will tell the story of a mother who came into the clinic, desperate, seeking help to have her unborn child, who has Downs. The next story will be from a worker at a family homeless shelter, who will tell the story of one family&rsquo;s struggle to find dignity and survive as a homeless family in Nashville. Then, a Downs Syndrome activist, who has met the character, shares the story of encouraging the character to be a model. Another story will follow from a child who sees the character&rsquo;s pictures, and is inspired. There will be a few stories told about the character from the mother&rsquo;s point of view as well as from a disabilities lawyer. Finally, there will be one more story from a hospice volunteer, who describes the final moments of the character&rsquo;s life. The event will be focused on building a culture of care around people who have disabilities. We hope to partner with a performing arts organization, Vandy Spoken Word, a crisis pregnancy center, Gigi&rsquo;s Playhouse and the Down Syndrome Alliance of Nashville, Tennessee, Safe Haven (a homeless shelter), faculty of the Susan Gray school, and other members of the Nashville and Vanderbilt Community who are interested. &nbsp;</span></p></div>",
        "title": "Where There's Life, there's Hope: One Girl's Story (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:30:00\">4:30 PM</span>)</b> <div>Location: <span class=\"location\">Presentation Room</span></div> <div class=\"description\">Cancelled <br/><br/> <p><span style=\"font-weight: 400;\">The event will open with a performance from a performing arts group, either a dance or a song from a choir or acapella group, that showcases all the turns that life can take. Then, a series of stories will follow, with experts coming onto a stage with a single microphone. The stories will follow the life of a fictional character, whose life is the compilation of different experts&rsquo; stories from over the years. First, a worker at a crisis pregnancy resource center will appear on the stage. They will tell the story of a mother who came into the clinic, desperate, seeking help to have her unborn child, who has Downs. The next story will be from a worker at a family homeless shelter, who will tell the story of one family&rsquo;s struggle to find dignity and survive as a homeless family in Nashville. Then, a Downs Syndrome activist, who has met the character, shares the story of encouraging the character to be a model. Another story will follow from a child who sees the character&rsquo;s pictures, and is inspired. There will be a few stories told about the character from the mother&rsquo;s point of view as well as from a disabilities lawyer. Finally, there will be one more story from a hospice volunteer, who describes the final moments of the character&rsquo;s life. The event will be focused on building a culture of care around people who have disabilities. We hope to partner with a performing arts organization, Vandy Spoken Word, a crisis pregnancy center, Gigi&rsquo;s Playhouse and the Down Syndrome Alliance of Nashville, Tennessee, Safe Haven (a homeless shelter), faculty of the Susan Gray school, and other members of the Nashville and Vanderbilt Community who are interested. &nbsp;</span></p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Diversity & Inclusion"
        ],
        "location": "Presentation Room",
        "description": "Cancelled  The event will open with a performance from a performing arts group, either a dance or a song from a choir or acapella group, that showcases all the turns that life can take. Then, a series of stories will follow, with experts coming onto a stage with a single microphone. The stories will follow the life of a fictional character, whose life is the compilation of different experts&#x2019; stories from over the years. First, a worker at a crisis pregnancy resource center will appear on the stage. They will tell the story of a mother who came into the clinic, desperate, seeking help to have her unborn child, who has Downs. The next story will be from a worker at a family homeless shelter, who will tell the story of one family&#x2019;s struggle to find dignity and survive as a homeless family in Nashville. Then, a Downs Syndrome activist, who has met the character, shares the story of encouraging the character to be a model. Another story will follow from a child who sees the character&#x2019;s pictures, and is inspired. There will be a few stories told about the character from the mother&#x2019;s point of view as well as from a disabilities lawyer. Finally, there will be one more story from a hospice volunteer, who describes the final moments of the character&#x2019;s life. The event will be focused on building a culture of care around people who have disabilities. We hope to partner with a performing arts organization, Vandy Spoken Word, a crisis pregnancy center, Gigi&#x2019;s Playhouse and the Down Syndrome Alliance of Nashville, Tennessee, Safe Haven (a homeless shelter), faculty of the Susan Gray school, and other members of the Nashville and Vanderbilt Community who are interested.  ; "
    },
    {
        "time": "14:30:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:30:00\">2:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lounge</span></div> <div class=\"description\"><p>Through three topics -- Biologically, Spiritually, and Philosophically-- we will explore the beginnings of human life through both speaker and student testimonies. </p>\r\n<p>&nbsp;</p></div>",
        "title": "When Does Life Begin? A Panel Discussion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:30:00\">2:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lounge</span></div> <div class=\"description\"><p>Through three topics -- Biologically, Spiritually, and Philosophically-- we will explore the beginnings of human life through both speaker and student testimonies. </p>\r\n<p>&nbsp;</p></div>",
        "categories": [],
        "location": "Alumni Lounge",
        "description": "Through three topics -- Biologically, Spiritually, and Philosophically-- we will explore the beginnings of human life through both speaker and student testimonies.   ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>Come out to Nashville's biggest bhangra competition! College teams from all over the country will come to compete for the grand prize.</p></div>",
        "title": "Nachde Nashville",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Langford Auditorium</span></div> <div class=\"description\"><p>Come out to Nashville's biggest bhangra competition! College teams from all over the country will come to compete for the grand prize.</p></div>",
        "categories": [],
        "location": "Langford Auditorium",
        "description": "Come out to Nashville';s biggest bhangra competition! College teams from all over the country will come to compete for the grand prize. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-01",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>UCB performs our annual spring concert! We will feature our wonder musicians from all over campus as we present works by Ticheli, Bizet, Jager, Latham, and Grainger.</p></div>",
        "title": "UCB Spring Concert",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-01\">Saturday, April 1, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>UCB performs our annual spring concert! We will feature our wonder musicians from all over campus as we present works by Ticheli, Bizet, Jager, Latham, and Grainger.</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Sarratt Cinema",
        "description": "UCB performs our annual spring concert! We will feature our wonder musicians from all over campus as we present works by Ticheli, Bizet, Jager, Latham, and Grainger. "
    },
    {
        "time": "09:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt University </span></div> <div class=\"description\"><p>This event is a 5K race on Vanderbilt's Campus and all proceeds will go to one of Delta Sigma Theta Sorority, Inc.'s national philanthropies: The Lwala Clinic in Kenya. We are hoping to raise awareness for the <a href=\"http://lwalacommunityalliance.org/\">Lwala Community Alliance</a>, an organization dedicated to building the capacity of the people of Lwala to advance their own comprehensive well-being. Sign-up early and race to the finish line!</p></div>",
        "title": "Elephant Trot",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"12:00:00\">12:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt University </span></div> <div class=\"description\"><p>This event is a 5K race on Vanderbilt's Campus and all proceeds will go to one of Delta Sigma Theta Sorority, Inc.'s national philanthropies: The Lwala Clinic in Kenya. We are hoping to raise awareness for the <a href=\"http://lwalacommunityalliance.org/\">Lwala Community Alliance</a>, an organization dedicated to building the capacity of the people of Lwala to advance their own comprehensive well-being. Sign-up early and race to the finish line!</p></div>",
        "categories": [
            "Athletics",
            "Service & Philanthropy",
            "Health & Wellness",
            "Sorority (For Organizations Advised by Greek Life)"
        ],
        "location": "Vanderbilt University ",
        "description": "This event is a 5K race on Vanderbilt';s Campus and all proceeds will go to one of Delta Sigma Theta Sorority, Inc.';s national philanthropies: The Lwala Clinic in Kenya. We are hoping to raise awareness for the [Lwala Community Alliance] (http://lwalacommunityalliance.org/) , an organization dedicated to building the capacity of the people of Lwala to advance their own comprehensive well-being. Sign-up early and race to the finish line! "
    },
    {
        "time": "11:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "title": "Cereal Sundays",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "categories": [],
        "location": "Moore College Faculty Director Apartment (Smith 502)",
        "description": "Stop by Dr. L';s apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out! "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">West House Volleyball Court</span></div> <div class=\"description\"><p>The final CUP event of the year. This is your last chance to come out and support your house and hang out with all your friends from the Commons. Head over to the volleyball courts behind West House and get sandy at Vandy.</p></div>",
        "title": "Commons CUP: Volleyball Tournament",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">West House Volleyball Court</span></div> <div class=\"description\"><p>The final CUP event of the year. This is your last chance to come out and support your house and hang out with all your friends from the Commons. Head over to the volleyball courts behind West House and get sandy at Vandy.</p></div>",
        "categories": [],
        "location": "West House Volleyball Court",
        "description": "The final CUP event of the year. This is your last chance to come out and support your house and hang out with all your friends from the Commons. Head over to the volleyball courts behind West House and get sandy at Vandy. "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Branscomb Courtyard</span></div> <div class=\"description\"><p>The event is called LemonADPi and we will be having refreshments, snacks, lawn games, music, and fundraising for the Ronald McDonald House at the event.&nbsp;</p></div>",
        "title": "Spring Philanthropy Event",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Branscomb Courtyard</span></div> <div class=\"description\"><p>The event is called LemonADPi and we will be having refreshments, snacks, lawn games, music, and fundraising for the Ronald McDonald House at the event.&nbsp;</p></div>",
        "categories": [
            "Service & Philanthropy"
        ],
        "location": "Branscomb Courtyard",
        "description": "The event is called LemonADPi and we will be having refreshments, snacks, lawn games, music, and fundraising for the Ronald McDonald House at the event. ; "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Presented by&nbsp;</span><span class=\"s1\">Dianna Bell, Mellon Assistant Professor of Religious Studies.</span></p>\r\n<p class=\"p1\"><span class=\"s1\">France/Mauritania (2014) Dir. Abderrahmane Sissako. Not far from the ancient Malian city of Timbuktu, cattle herder Kidane lives peacefully in the dunes with his wife, their daughter and their twelve-year-old shepherd. In town, the people suffer from the regime of terror imposed by the Jihadists determined to control their faith. Music, laughter, cigarettes, even soccer have been banned. The women have become shadows but resist with dignity. Every day, the new improvised courts issue tragic and absurd sentences. Kidane and his family are spared the chaos that prevails in Timbuktu, their destiny changes abruptly. Arabic, French, Tamasheq, Songhay, English, and Bambara with English Subtitles. 97 minutes. Blu-ray. Presented in collaboration with the Vanderbilt Trans-Institutional Program: Africa at the Crossroads.</span></p></div>",
        "title": "iLens: Timbuktu",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Presented by&nbsp;</span><span class=\"s1\">Dianna Bell, Mellon Assistant Professor of Religious Studies.</span></p>\r\n<p class=\"p1\"><span class=\"s1\">France/Mauritania (2014) Dir. Abderrahmane Sissako. Not far from the ancient Malian city of Timbuktu, cattle herder Kidane lives peacefully in the dunes with his wife, their daughter and their twelve-year-old shepherd. In town, the people suffer from the regime of terror imposed by the Jihadists determined to control their faith. Music, laughter, cigarettes, even soccer have been banned. The women have become shadows but resist with dignity. Every day, the new improvised courts issue tragic and absurd sentences. Kidane and his family are spared the chaos that prevails in Timbuktu, their destiny changes abruptly. Arabic, French, Tamasheq, Songhay, English, and Bambara with English Subtitles. 97 minutes. Blu-ray. Presented in collaboration with the Vanderbilt Trans-Institutional Program: Africa at the Crossroads.</span></p></div>",
        "categories": [
            "Political",
            "Diversity & Inclusion",
            "International",
            "Film/Movie",
            "Visual Arts",
            "Graduate/Professional Students",
            "Religious/Spiritual"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by ;Dianna Bell, Mellon Assistant Professor of Religious Studies. France/Mauritania (2014) Dir. Abderrahmane Sissako. Not far from the ancient Malian city of Timbuktu, cattle herder Kidane lives peacefully in the dunes with his wife, their daughter and their twelve-year-old shepherd. In town, the people suffer from the regime of terror imposed by the Jihadists determined to control their faith. Music, laughter, cigarettes, even soccer have been banned. The women have become shadows but resist with dignity. Every day, the new improvised courts issue tragic and absurd sentences. Kidane and his family are spared the chaos that prevails in Timbuktu, their destiny changes abruptly. Arabic, French, Tamasheq, Songhay, English, and Bambara with English Subtitles. 97 minutes. Blu-ray. Presented in collaboration with the Vanderbilt Trans-Institutional Program: Africa at the Crossroads. "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Ingram Hall</span></div> <div class=\"description\"><p class=\"p1\">This concert will feature a variety of musical pieces sung by a choir of around 65 students from all undergraduate schools.&nbsp;This spring concert will also feature performances from various subgroups; Chamber Singers, Women's Group, and Men's Group.&nbsp;</p></div>",
        "title": "VUCC Spring Concert",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Ingram Hall</span></div> <div class=\"description\"><p class=\"p1\">This concert will feature a variety of musical pieces sung by a choir of around 65 students from all undergraduate schools.&nbsp;This spring concert will also feature performances from various subgroups; Chamber Singers, Women's Group, and Men's Group.&nbsp;</p></div>",
        "categories": [
            "Performing Arts",
            "GME - Campus Involvement",
            "Greek Member Experience"
        ],
        "location": "Ingram Hall",
        "description": "This concert will feature a variety of musical pieces sung by a choir of around 65 students from all undergraduate schools. ;This spring concert will also feature performances from various subgroups; Chamber Singers, Women';s Group, and Men';s Group. ; "
    },
    {
        "time": "17:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom</span></div> <div class=\"description\"><p>Malaysian Night is an annual cultural event that will highlight the different culture of Malaysia. This year, we will give you a glimpse of the different attractions in Malaysia including tourist spots, traditional games and the amazing food as well. As said, free food will be provided together with performances and skits about Malaysia !</p></div>",
        "title": "Malaysian Night",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom</span></div> <div class=\"description\"><p>Malaysian Night is an annual cultural event that will highlight the different culture of Malaysia. This year, we will give you a glimpse of the different attractions in Malaysia including tourist spots, traditional games and the amazing food as well. As said, free food will be provided together with performances and skits about Malaysia !</p></div>",
        "categories": [
            "Diversity & Inclusion",
            "International"
        ],
        "location": "Student Life Center Ballroom",
        "description": "Malaysian Night is an annual cultural event that will highlight the different culture of Malaysia. This year, we will give you a glimpse of the different attractions in Malaysia including tourist spots, traditional games and the amazing food as well. As said, free food will be provided together with performances and skits about Malaysia ! "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-02",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "title": "Sutherland Social",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-02\">Sunday, April 2, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "categories": [
            "The Ingram Commons"
        ],
        "location": "Sutherland House",
        "description": "Come fellowship with Sutherland residents with food and fun! "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-03",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "16:00:00",
        "date": "2017-04-03",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:00:00\">4:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\"><p>The third annual Commodore bouldering competition is free and open to Vanderbilt students and VRWC members. Competitors of all skill levels, from beginners to regulars, are encouraged to participate.<br /><br />There will be two sessions:<br /><br />Session 1: 4:00 pm &ndash; 5:30 pm<br /><br />Session 2: 5:30 pm &ndash; 7:00 pm<br /><br /><br /><br />There will be four categories in which to compete: Female Beginner (V1-V2), Male Beginner (V1-V2), Female Intermediate (V3+), and Male Intermediate (V3+). The top three climbers in each category will receive a prize!<br /><span class=\"text_exposed_show\"><br /><br /><br />Participants can reserve their climbing and bouldering time slots before the event. Time slots will go quickly, so reserve your spot today by going here.<br /><br /><br /><br />For questions or more information, email outdoorrec@vanderbilt.edu<br /><br />Contact: Sean Wilkinson,<br />Outdoor Recreation Activities Coordinator<br />(615) 936-8527</span></p></div>",
        "title": "Commodore Climb 3: The Chalk Knight Rises",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:00:00\">4:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\"><p>The third annual Commodore bouldering competition is free and open to Vanderbilt students and VRWC members. Competitors of all skill levels, from beginners to regulars, are encouraged to participate.<br /><br />There will be two sessions:<br /><br />Session 1: 4:00 pm &ndash; 5:30 pm<br /><br />Session 2: 5:30 pm &ndash; 7:00 pm<br /><br /><br /><br />There will be four categories in which to compete: Female Beginner (V1-V2), Male Beginner (V1-V2), Female Intermediate (V3+), and Male Intermediate (V3+). The top three climbers in each category will receive a prize!<br /><span class=\"text_exposed_show\"><br /><br /><br />Participants can reserve their climbing and bouldering time slots before the event. Time slots will go quickly, so reserve your spot today by going here.<br /><br /><br /><br />For questions or more information, email outdoorrec@vanderbilt.edu<br /><br />Contact: Sean Wilkinson,<br />Outdoor Recreation Activities Coordinator<br />(615) 936-8527</span></p></div>",
        "categories": [],
        "location": "Vanderbilt Recreation and Wellness Center",
        "description": "The third annual Commodore bouldering competition is free and open to Vanderbilt students and VRWC members. Competitors of all skill levels, from beginners to regulars, are encouraged to participate. There will be two sessions: Session 1: 4:00 pm &#x2013; 5:30 pm Session 2: 5:30 pm &#x2013; 7:00 pm There will be four categories in which to compete: Female Beginner (V1-V2), Male Beginner (V1-V2), Female Intermediate (V3+), and Male Intermediate (V3+). The top three climbers in each category will receive a prize! Participants can reserve their climbing and bouldering time slots before the event. Time slots will go quickly, so reserve your spot today by going here. For questions or more information, email outdoorrec@vanderbilt.edu Contact: Sean Wilkinson, Outdoor Recreation Activities Coordinator (615) 936-8527 "
    },
    {
        "time": "17:00:00",
        "date": "2017-04-03",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 410</span></div> <div class=\"description\"><p>Join us for a hands-on session!</p>\r\n<p>Interested in learning about the array of instruments available for minimally-invasive procedures in interventional radiology and surgery? Want to try your hand&nbsp;using catheters to navigate (simulated) blood vessels? Just want to see some cool \"toys\"?</p>\r\n<p>We will be hosting a combined informational and hands-on session to serve as an introduction to all things endovascular.&nbsp;</p>\r\n<p>This event is co-sponsored by VMIL (Vanderbilt Medical Innovation Laboratory).</p></div>",
        "title": "IR Interest Group: Introduction to Endovascular Tools",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">LH 410</span></div> <div class=\"description\"><p>Join us for a hands-on session!</p>\r\n<p>Interested in learning about the array of instruments available for minimally-invasive procedures in interventional radiology and surgery? Want to try your hand&nbsp;using catheters to navigate (simulated) blood vessels? Just want to see some cool \"toys\"?</p>\r\n<p>We will be hosting a combined informational and hands-on session to serve as an introduction to all things endovascular.&nbsp;</p>\r\n<p>This event is co-sponsored by VMIL (Vanderbilt Medical Innovation Laboratory).</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "LH 410",
        "description": "Join us for a hands-on session! Interested in learning about the array of instruments available for minimally-invasive procedures in interventional radiology and surgery? Want to try your hand ;using catheters to navigate (simulated) blood vessels? Just want to see some cool \";toys\";? We will be hosting a combined informational and hands-on session to serve as an introduction to all things endovascular. ; This event is co-sponsored by VMIL (Vanderbilt Medical Innovation Laboratory). "
    },
    {
        "time": "17:30:00",
        "date": "2017-04-03",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Student Life Center Ballroom</span></div> <div class=\"description\"><p>It has been another great year in the Greek Community at Vanderbilt University, and now it&rsquo;s time to recognize all of our chapters for the outstanding programs they do and the people that make our community shine! The 2017 Greek Contribution Day &amp; Chancellor Alexander Heard Greek Awards will be held on April 3, 2017 at 5:30 PM in the SLC Ballroom.<br /><br />Prior to the awards ceremony, we will be hosting the Greek Contribution Day Poster Session, where organizations will showcase contributions they have made to both their members and the Vanderbilt and Nashville community.&nbsp;</p>\r\n<p>Food and light refreshments will be served.&nbsp;</p></div>",
        "title": "2017 Greek Contribution Day and Chancellor Alexander Heard Greek Awards",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Student Life Center Ballroom</span></div> <div class=\"description\"><p>It has been another great year in the Greek Community at Vanderbilt University, and now it&rsquo;s time to recognize all of our chapters for the outstanding programs they do and the people that make our community shine! The 2017 Greek Contribution Day &amp; Chancellor Alexander Heard Greek Awards will be held on April 3, 2017 at 5:30 PM in the SLC Ballroom.<br /><br />Prior to the awards ceremony, we will be hosting the Greek Contribution Day Poster Session, where organizations will showcase contributions they have made to both their members and the Vanderbilt and Nashville community.&nbsp;</p>\r\n<p>Food and light refreshments will be served.&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience"
        ],
        "location": "Vanderbilt Student Life Center Ballroom",
        "description": "It has been another great year in the Greek Community at Vanderbilt University, and now it&#x2019;s time to recognize all of our chapters for the outstanding programs they do and the people that make our community shine! The 2017 Greek Contribution Day &; Chancellor Alexander Heard Greek Awards will be held on April 3, 2017 at 5:30 PM in the SLC Ballroom. Prior to the awards ceremony, we will be hosting the Greek Contribution Day Poster Session, where organizations will showcase contributions they have made to both their members and the Vanderbilt and Nashville community. ; Food and light refreshments will be served. ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-03",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 437</span></div> <div class=\"description\"><p>Now more than ever, it is important for primary care health professionals to be well-versed on policy topics that affect their practice and their patients. Additionally, healthcare is increasingly interdisciplinary, with the policies of one health discipline often affecting the practices and policies of others&nbsp;disciplines.&nbsp;</p>\r\n<p>Join us as we bring together students and representatives from Vanderbilt School of Medicine, Vanderbilt School of Nursing, and Lipscomb College of Pharmacy to discuss the current health policies and topics of greatest focus in each of our disciplines. Each school will provide a short presentation describing these topics, which will be followed by a group discussion on&nbsp;how these issues overlap. Additional information will be provided on current legislation related to these issues&nbsp;as well as&nbsp;ways to advocate as a healthcare provider.&nbsp;</p>\r\n<p>Dinner will be provided!</p></div>",
        "title": "PCP Interdisciplinary Policy Discussion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall 437</span></div> <div class=\"description\"><p>Now more than ever, it is important for primary care health professionals to be well-versed on policy topics that affect their practice and their patients. Additionally, healthcare is increasingly interdisciplinary, with the policies of one health discipline often affecting the practices and policies of others&nbsp;disciplines.&nbsp;</p>\r\n<p>Join us as we bring together students and representatives from Vanderbilt School of Medicine, Vanderbilt School of Nursing, and Lipscomb College of Pharmacy to discuss the current health policies and topics of greatest focus in each of our disciplines. Each school will provide a short presentation describing these topics, which will be followed by a group discussion on&nbsp;how these issues overlap. Additional information will be provided on current legislation related to these issues&nbsp;as well as&nbsp;ways to advocate as a healthcare provider.&nbsp;</p>\r\n<p>Dinner will be provided!</p></div>",
        "categories": [
            "School of Medicine",
            "Graduate/Professional Students"
        ],
        "location": "Light Hall 437",
        "description": "Now more than ever, it is important for primary care health professionals to be well-versed on policy topics that affect their practice and their patients. Additionally, healthcare is increasingly interdisciplinary, with the policies of one health discipline often affecting the practices and policies of others ;disciplines. ; Join us as we bring together students and representatives from Vanderbilt School of Medicine, Vanderbilt School of Nursing, and Lipscomb College of Pharmacy to discuss the current health policies and topics of greatest focus in each of our disciplines. Each school will provide a short presentation describing these topics, which will be followed by a group discussion on ;how these issues overlap. Additional information will be provided on current legislation related to these issues ;as well as ;ways to advocate as a healthcare provider. ; Dinner will be provided! "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-03",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">OACS</span></div> <div class=\"description\"><p>Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the <a href=\"http://www.thenashvillefoodproject.org/\" target=\"_blank\">Nashville Food Project</a>. Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply.</p></div>",
        "title": "Redefine",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">OACS</span></div> <div class=\"description\"><p>Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the <a href=\"http://www.thenashvillefoodproject.org/\" target=\"_blank\">Nashville Food Project</a>. Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply.</p></div>",
        "categories": [
            "Service & Philanthropy",
            "International"
        ],
        "location": "OACS",
        "description": "Students will immerse themselves in the conceptualization of community service as it relates to U.S. communities and how or if the same ideas translate across cultures. Redefine exposes students to local community needs by partnering with the [Nashville Food Project] (http://www.thenashvillefoodproject.org/) . Students will serve with a non-profit organization that is delivering real impact in Nashville through its mission of cultivating community and alleviating hunger. A central goal of Redefine is the development of friendships amongst people from different countries. Undergraduate and graduate students from all disciplines are encouraged to apply. "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-03",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Wilson 103</span></div> <div class=\"description\"><p>For Sexual Assault Awareness Month, Project Safe will host a screening of a documentary that examines the effects of social media and cyber bullying on families, friends, schools and communities when two underage young women find that sexual assault crimes against them have been caught on camera.</p></div>",
        "title": "Sexual Assault Awareness Month Film Screening: Audrie and Daisy",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-03\">Monday, April 3, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Wilson 103</span></div> <div class=\"description\"><p>For Sexual Assault Awareness Month, Project Safe will host a screening of a documentary that examines the effects of social media and cyber bullying on families, friends, schools and communities when two underage young women find that sexual assault crimes against them have been caught on camera.</p></div>",
        "categories": [
            "Health & Wellness",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Wilson 103",
        "description": "For Sexual Assault Awareness Month, Project Safe will host a screening of a documentary that examines the effects of social media and cyber bullying on families, friends, schools and communities when two underage young women find that sexual assault crimes against them have been caught on camera. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "GME - Healthy Behaviors",
            "Greek Member Experience"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Multiple locations</span></div> <div class=\"description\"><p>Pre-departure orientation sessions co-hosted by GEO and DIS for students studying abroad in Copenhagen</p></div>",
        "title": "DIS Copenhagen Pre-Departure Orientations",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Multiple locations</span></div> <div class=\"description\"><p>Pre-departure orientation sessions co-hosted by GEO and DIS for students studying abroad in Copenhagen</p></div>",
        "categories": [],
        "location": "Multiple locations",
        "description": "Pre-departure orientation sessions co-hosted by GEO and DIS for students studying abroad in Copenhagen "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall</span></div> <div class=\"description\"><p><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\" color=\"black\" face=\"Arial,sans-serif\">Dr. Charlene Dewey, M.D., M.Ed., FACP, the Assistant Dean for Educator Development&nbsp;</font></font><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\" color=\"black\" face=\"Arial,sans-serif\">and the&nbsp;</font></font><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\" color=\"black\" face=\"Arial,sans-serif\">Chair of the Faculty Physician Wellness Committee&nbsp;will be presenting on the professional behaviors of wellness, resiliency, stress, burnout, and impairment. She will address&nbsp;evidence of risk for physicians and the current literature on rates for burnout. From there, she will discuss Biblical examples that can help clinicians and trainees think through these challenges in their personal practice of medicine.&nbsp;We hope to see you there!</font></font></p></div>",
        "title": "Professionalism: A Behavioral Comparison of the Ph...",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall</span></div> <div class=\"description\"><p><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\" color=\"black\" face=\"Arial,sans-serif\">Dr. Charlene Dewey, M.D., M.Ed., FACP, the Assistant Dean for Educator Development&nbsp;</font></font><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\" color=\"black\" face=\"Arial,sans-serif\">and the&nbsp;</font></font><font size=\"2\" face=\"Calibri,sans-serif\"><font size=\"2\" color=\"black\" face=\"Arial,sans-serif\">Chair of the Faculty Physician Wellness Committee&nbsp;will be presenting on the professional behaviors of wellness, resiliency, stress, burnout, and impairment. She will address&nbsp;evidence of risk for physicians and the current literature on rates for burnout. From there, she will discuss Biblical examples that can help clinicians and trainees think through these challenges in their personal practice of medicine.&nbsp;We hope to see you there!</font></font></p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall",
        "description": "Dr. Charlene Dewey, M.D., M.Ed., FACP, the Assistant Dean for Educator Development ;and the ;Chair of the Faculty Physician Wellness Committee ;will be presenting on the professional behaviors of wellness, resiliency, stress, burnout, and impairment. She will address ;evidence of risk for physicians and the current literature on rates for burnout. From there, she will discuss Biblical examples that can help clinicians and trainees think through these challenges in their personal practice of medicine. ;We hope to see you there! "
    },
    {
        "time": "12:10:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:10:00\">12:10 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore Room 218, Vanderbilt Law School</span></div> <div class=\"description\"><p>The Energy, Environment and Land Use Program presents Private Sector Demand for Renewable Power panel on Tuesday, April 4, 2017 from 12:10-1:00 p.m. in Moore Room 218.</p>\r\n<p>The panel will feature: <a href=\"http://fa.unc.edu/enterprises/avc/\">Brad Ives</a>, University of North Carolina at Chapel Hill, Steve Chriss, Wal-Mart Stores, Inc., <a href=\"https://www.southernenvironment.org/staff/amanda-garcia\">Amanda Garcia</a>, Southern Environmental Law Center, <a href=\"https://www.customerfirstrenewables.com/about-us/leadership-team/gary-farha-2/\">Gary Farha</a>, CustomerFirst Renewables, and Professor <a href=\"https://law.vanderbilt.edu/bio/jim-rossi\">Jim Rossi</a>. The panel will be moderated by Professor <a href=\"https://law.vanderbilt.edu/bio/michael-vandenbergh\">Mike Vandenbergh</a>.&nbsp;</p>\r\n<p>Brad Ives is Associate Vice Chancellor for Campus Enterprises and Chief Sustainability Officer at UNC-Chapel Hill. Prior to joining UNC-Chapel Hill, Ives served as Assistant Secretary for Natural Resources with the N.C. Department of Environment and Natural Resources.</p>\r\n<p>Steve Chriss is the Director of Energy and Strategy Analysis at Wal-Mart Stores, Inc. Chriss is responsible for managing Walmart's interventions in utility rate-related proceedings and for tracking and managing Walmart's regulatory and legislative cost exposure from changes in electric and natural gas rates.&nbsp;</p>\r\n<p>Amanda Garcia is a staff attorney at the Southern Environmental Law Center's Nashville office. SELC is a nonprofit organization dedicated to protecting natural resources.&nbsp;</p>\r\n<p>Gary Farha is the Founder, President and CEO of CustomerFirst Renewables, an advisory services firm that designs and builds renewable energy solutions to customers.&nbsp;</p>\r\n<p>This event is cosponsored by the Energy, Environment and Land Use Program, Climate Change Research Network, Environmental Law Society, and the Southern Environmental Law Center. Lunch will be provided.</p>\r\n<p>&nbsp;</p></div>",
        "title": "Private Sector Demand for Renewable Power Panel",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:10:00\">12:10 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore Room 218, Vanderbilt Law School</span></div> <div class=\"description\"><p>The Energy, Environment and Land Use Program presents Private Sector Demand for Renewable Power panel on Tuesday, April 4, 2017 from 12:10-1:00 p.m. in Moore Room 218.</p>\r\n<p>The panel will feature: <a href=\"http://fa.unc.edu/enterprises/avc/\">Brad Ives</a>, University of North Carolina at Chapel Hill, Steve Chriss, Wal-Mart Stores, Inc., <a href=\"https://www.southernenvironment.org/staff/amanda-garcia\">Amanda Garcia</a>, Southern Environmental Law Center, <a href=\"https://www.customerfirstrenewables.com/about-us/leadership-team/gary-farha-2/\">Gary Farha</a>, CustomerFirst Renewables, and Professor <a href=\"https://law.vanderbilt.edu/bio/jim-rossi\">Jim Rossi</a>. The panel will be moderated by Professor <a href=\"https://law.vanderbilt.edu/bio/michael-vandenbergh\">Mike Vandenbergh</a>.&nbsp;</p>\r\n<p>Brad Ives is Associate Vice Chancellor for Campus Enterprises and Chief Sustainability Officer at UNC-Chapel Hill. Prior to joining UNC-Chapel Hill, Ives served as Assistant Secretary for Natural Resources with the N.C. Department of Environment and Natural Resources.</p>\r\n<p>Steve Chriss is the Director of Energy and Strategy Analysis at Wal-Mart Stores, Inc. Chriss is responsible for managing Walmart's interventions in utility rate-related proceedings and for tracking and managing Walmart's regulatory and legislative cost exposure from changes in electric and natural gas rates.&nbsp;</p>\r\n<p>Amanda Garcia is a staff attorney at the Southern Environmental Law Center's Nashville office. SELC is a nonprofit organization dedicated to protecting natural resources.&nbsp;</p>\r\n<p>Gary Farha is the Founder, President and CEO of CustomerFirst Renewables, an advisory services firm that designs and builds renewable energy solutions to customers.&nbsp;</p>\r\n<p>This event is cosponsored by the Energy, Environment and Land Use Program, Climate Change Research Network, Environmental Law Society, and the Southern Environmental Law Center. Lunch will be provided.</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Academic",
            "Law School",
            "Environmental/Sustainability"
        ],
        "location": "Moore Room 218, Vanderbilt Law School",
        "description": "The Energy, Environment and Land Use Program presents Private Sector Demand for Renewable Power panel on Tuesday, April 4, 2017 from 12:10-1:00 p.m. in Moore Room 218. The panel will feature: [Brad Ives] (http://fa.unc.edu/enterprises/avc/) , University of North Carolina at Chapel Hill, Steve Chriss, Wal-Mart Stores, Inc., [Amanda Garcia] (https://www.southernenvironment.org/staff/amanda-garcia) , Southern Environmental Law Center, [Gary Farha] (https://www.customerfirstrenewables.com/about-us/leadership-team/gary-farha-2/) , CustomerFirst Renewables, and Professor [Jim Rossi] (https://law.vanderbilt.edu/bio/jim-rossi) . The panel will be moderated by Professor [Mike Vandenbergh] (https://law.vanderbilt.edu/bio/michael-vandenbergh) . ; Brad Ives is Associate Vice Chancellor for Campus Enterprises and Chief Sustainability Officer at UNC-Chapel Hill. Prior to joining UNC-Chapel Hill, Ives served as Assistant Secretary for Natural Resources with the N.C. Department of Environment and Natural Resources. Steve Chriss is the Director of Energy and Strategy Analysis at Wal-Mart Stores, Inc. Chriss is responsible for managing Walmart';s interventions in utility rate-related proceedings and for tracking and managing Walmart';s regulatory and legislative cost exposure from changes in electric and natural gas rates. ; Amanda Garcia is a staff attorney at the Southern Environmental Law Center';s Nashville office. SELC is a nonprofit organization dedicated to protecting natural resources. ; Gary Farha is the Founder, President and CEO of CustomerFirst Renewables, an advisory services firm that designs and builds renewable energy solutions to customers. ; This event is cosponsored by the Energy, Environment and Land Use Program, Climate Change Research Network, Environmental Law Society, and the Southern Environmental Law Center. Lunch will be provided.  ; "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "Health & Wellness",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Hall</span></div> <div class=\"description\"><p>The Engineering Council will be holding a professional development day including a Linkedin Workshop and professional headshots.</p></div>",
        "title": "Professional Development Day",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Hall</span></div> <div class=\"description\"><p>The Engineering Council will be holding a professional development day including a Linkedin Workshop and professional headshots.</p></div>",
        "categories": [],
        "location": "Featheringill Hall",
        "description": "The Engineering Council will be holding a professional development day including a Linkedin Workshop and professional headshots. "
    },
    {
        "time": "15:30:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Hawkins Field </span></div> <div class=\"description\"><p>Come out and support the Vanderbilt Baseball team as they take on Southeast Louisiana at home!&nbsp;</p></div>",
        "title": "Vanderbilt Baseball vs. Southeast Louisiana",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Hawkins Field </span></div> <div class=\"description\"><p>Come out and support the Vanderbilt Baseball team as they take on Southeast Louisiana at home!&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Campus Involvement"
        ],
        "location": "Hawkins Field ",
        "description": "Come out and support the Vanderbilt Baseball team as they take on Southeast Louisiana at home! ; "
    },
    {
        "time": "17:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Multi-Purpose Room</span></div> <div class=\"description\"><p><span class=\"_4n-j fsl\">The Escalation Workshop is a 90-minute training consisting of a video and facilitated discussion on the topic of relationship violence. Participants learn about the prevalence and warning signs of dating violence and how to support a friend.</span></p></div>",
        "title": "Escalation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Multi-Purpose Room</span></div> <div class=\"description\"><p><span class=\"_4n-j fsl\">The Escalation Workshop is a 90-minute training consisting of a video and facilitated discussion on the topic of relationship violence. Participants learn about the prevalence and warning signs of dating violence and how to support a friend.</span></p></div>",
        "categories": [
            "Greek Member Experience",
            "Health & Wellness",
            "GME - Healthy Behaviors"
        ],
        "location": "Kissam Multi-Purpose Room",
        "description": "The Escalation Workshop is a 90-minute training consisting of a video and facilitated discussion on the topic of relationship violence. Participants learn about the prevalence and warning signs of dating violence and how to support a friend. "
    },
    {
        "time": "17:30:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">The Wond'ry</span></div> <div class=\"description\"><p>AKPsi and the Wond'ry are teaming up to bring recongized brokerage innovator and social entrepreneur, Tom Sosnoff, to Nasvhille. In addition to the talk itself, there will be food, GME, and... berets (yes, multiple).<br /><br />In his career, Tom has pursued a vision to educate retail investors and to build both a superior trading software platform and a brokerage firm that specialize in options.<br /><br />Tom co-founded thinkorswim in 1999, tastytrade in 2011, and newly launched tastyworks in 2017. Tom successfully sold thinkorswim for $606 million and continues to innovate in the financial space as the co-host of tasytrade Live, the most-watched online financial network in the world.</p></div>",
        "title": "Tom Sosnoff: Running with Risk and Opportunity",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">The Wond'ry</span></div> <div class=\"description\"><p>AKPsi and the Wond'ry are teaming up to bring recongized brokerage innovator and social entrepreneur, Tom Sosnoff, to Nasvhille. In addition to the talk itself, there will be food, GME, and... berets (yes, multiple).<br /><br />In his career, Tom has pursued a vision to educate retail investors and to build both a superior trading software platform and a brokerage firm that specialize in options.<br /><br />Tom co-founded thinkorswim in 1999, tastytrade in 2011, and newly launched tastyworks in 2017. Tom successfully sold thinkorswim for $606 million and continues to innovate in the financial space as the co-host of tasytrade Live, the most-watched online financial network in the world.</p></div>",
        "categories": [
            "Career Development"
        ],
        "location": "The Wond'ry",
        "description": "AKPsi and the Wond';ry are teaming up to bring recongized brokerage innovator and social entrepreneur, Tom Sosnoff, to Nasvhille. In addition to the talk itself, there will be food, GME, and... berets (yes, multiple). In his career, Tom has pursued a vision to educate retail investors and to build both a superior trading software platform and a brokerage firm that specialize in options. Tom co-founded thinkorswim in 1999, tastytrade in 2011, and newly launched tastyworks in 2017. Tom successfully sold thinkorswim for $606 million and continues to innovate in the financial space as the co-host of tasytrade Live, the most-watched online financial network in the world. "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "title": "Vandy Wesley Weekly Dinner and Community",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "categories": [
            "Health & Wellness",
            "Religious/Spiritual"
        ],
        "location": "Div School Reading Room (through the courtyard next to Benton Chapel)",
        "description": "Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond.  ;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community.  ; All are welcome!! "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Central Library Community Room</span></div> <div class=\"description\"><p>Join the Women of Sigma Lambda Gamma as we host a discussion on the outlook of multiculturalism from an institutional point of view. This event comes on the tail of a series of policies and motions up for discussion here on campus. We have Vice Chancellor and Chief Diversity Officer Dr. George Hill coming to speak to us on behalf of the Office of Equity, Diversity and Inclusion. A light reception will follow questions.</p></div>",
        "title": "Ball of Confusion ft. Vice Chancellor Hill",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Central Library Community Room</span></div> <div class=\"description\"><p>Join the Women of Sigma Lambda Gamma as we host a discussion on the outlook of multiculturalism from an institutional point of view. This event comes on the tail of a series of policies and motions up for discussion here on campus. We have Vice Chancellor and Chief Diversity Officer Dr. George Hill coming to speak to us on behalf of the Office of Equity, Diversity and Inclusion. A light reception will follow questions.</p></div>",
        "categories": [],
        "location": "Central Library Community Room",
        "description": "Join the Women of Sigma Lambda Gamma as we host a discussion on the outlook of multiculturalism from an institutional point of view. This event comes on the tail of a series of policies and motions up for discussion here on campus. We have Vice Chancellor and Chief Diversity Officer Dr. George Hill coming to speak to us on behalf of the Office of Equity, Diversity and Inclusion. A light reception will follow questions. "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Furman 114</span></div> <div class=\"description\"><p>We will announce the winner of our March Madness for Global Health fundraiser. We will also discuss the clinic in Neno, Malawi that the funds will be going to and the work being done there.</p></div>",
        "title": "March Madness for Global Health",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Furman 114</span></div> <div class=\"description\"><p>We will announce the winner of our March Madness for Global Health fundraiser. We will also discuss the clinic in Neno, Malawi that the funds will be going to and the work being done there.</p></div>",
        "categories": [],
        "location": "Furman 114",
        "description": "We will announce the winner of our March Madness for Global Health fundraiser. We will also discuss the clinic in Neno, Malawi that the funds will be going to and the work being done there. "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Rand 308</span></div> <div class=\"description\"><p>This fourth installment of Crossroads will take the time to discuss how arts on campus and in our world interacts with LGBTQi life.&nbsp;</p></div>",
        "title": "Crossroads, a Conversation Series: Arts and LGBTQi Life",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Rand 308</span></div> <div class=\"description\"><p>This fourth installment of Crossroads will take the time to discuss how arts on campus and in our world interacts with LGBTQi life.&nbsp;</p></div>",
        "categories": [
            "Performing Arts",
            "LGBTQI Life"
        ],
        "location": "Rand 308",
        "description": "This fourth installment of Crossroads will take the time to discuss how arts on campus and in our world interacts with LGBTQi life. ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Center C216</span></div> <div class=\"description\"><p>The Vanderbilt Historical Review will be hosting a panel to discuss the first 100 days of Donald Trump's presidency. We will be discussing what he has accomplished thus far, what he plans to do in the remaining weeks, and the historical importance of the first 100 days in office. We plan to bring several professors from history, political science, and the law school for this upcoming panel. Light refreshments will be served.</p></div>",
        "title": "Political History Panel: Trump's First 100 Days",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Center C216</span></div> <div class=\"description\"><p>The Vanderbilt Historical Review will be hosting a panel to discuss the first 100 days of Donald Trump's presidency. We will be discussing what he has accomplished thus far, what he plans to do in the remaining weeks, and the historical importance of the first 100 days in office. We plan to bring several professors from history, political science, and the law school for this upcoming panel. Light refreshments will be served.</p></div>",
        "categories": [
            "Political",
            "Academic"
        ],
        "location": "Kissam Center C216",
        "description": "The Vanderbilt Historical Review will be hosting a panel to discuss the first 100 days of Donald Trump';s presidency. We will be discussing what he has accomplished thus far, what he plans to do in the remaining weeks, and the historical importance of the first 100 days in office. We plan to bring several professors from history, political science, and the law school for this upcoming panel. Light refreshments will be served. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-04",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lounge 206</span></div> <div class=\"description\"><p>topic tbd&nbsp;</p></div>",
        "title": "Fireside Chat #8",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-04\">Tuesday, April 4, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lounge 206</span></div> <div class=\"description\"><p>topic tbd&nbsp;</p></div>",
        "categories": [],
        "location": "Alumni Lounge 206",
        "description": "topic tbd ; "
    },
    {
        "time": "09:15:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Law School - Flynn Auditorium </span></div> <div class=\"description\"><p><a href=\"http://www.ohchr.org/EN/AboutUs/Pages/HighCommissioner.aspx\">Zeid Ra'ad Al Hussein</a>, the United Nations High Commissioner for Human Rights, will speak about his role as the head of the <a href=\"http://www.ohchr.org/EN/Pages/Home.aspx\">Office of the High Commissioner for Human Rights</a> at the <a href=\"https://law.vanderbilt.edu/\">Vanderbilt Law School</a> on Wednesday, April 5, 2017 at noon in Flynn Auditorium.&nbsp;</p>\r\n<p>Since the start of the United Nations in 1945, human rights &nbsp;has been a central part of the programming within the UN organization. The Office of the High Commissioner for Human Rights (OHCHR) ensures that the human rights perspective is included in all United Nations programs. Governments are tasked with the responsibility to protect human rights and the OHCHR provides assistance to those governments in order to implement an international human rights standard.&nbsp;</p>\r\n<p>The office is staffed by over 900 civil servants who work with various governments and organizations to promote and protect human rights through treaties, education, research and other advocacy activities.&nbsp;</p>\r\n<p>Zeid has served as the High Commissioner since September 2014. He is the first Asian, Muslim and Arab to serve as the High Commissioner and is the seventh individual to lead the office. Zeid previously served as Jordan's Permanent Representative to the United Nations in New York and as Jordan's Ambassador to the United States. He has worked for the UN in different capacities since 1996. Zeid holds a Bachelor of Arts degree from Johns Hopkins University and a Doctorate in Philosophy from Cambridge University.&nbsp;</p>\r\n<p>The event is free and open to the public. Sponsored by the <a href=\"https://law.vanderbilt.edu/academics/academic-programs/international-legal-studies/index.php\">International Legal Studies Program</a>.&nbsp;</p></div>",
        "title": "A Conversation with the High Commissioner for Human Rights Zeid Ra'ad Al Hussein",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Law School - Flynn Auditorium </span></div> <div class=\"description\"><p><a href=\"http://www.ohchr.org/EN/AboutUs/Pages/HighCommissioner.aspx\">Zeid Ra'ad Al Hussein</a>, the United Nations High Commissioner for Human Rights, will speak about his role as the head of the <a href=\"http://www.ohchr.org/EN/Pages/Home.aspx\">Office of the High Commissioner for Human Rights</a> at the <a href=\"https://law.vanderbilt.edu/\">Vanderbilt Law School</a> on Wednesday, April 5, 2017 at noon in Flynn Auditorium.&nbsp;</p>\r\n<p>Since the start of the United Nations in 1945, human rights &nbsp;has been a central part of the programming within the UN organization. The Office of the High Commissioner for Human Rights (OHCHR) ensures that the human rights perspective is included in all United Nations programs. Governments are tasked with the responsibility to protect human rights and the OHCHR provides assistance to those governments in order to implement an international human rights standard.&nbsp;</p>\r\n<p>The office is staffed by over 900 civil servants who work with various governments and organizations to promote and protect human rights through treaties, education, research and other advocacy activities.&nbsp;</p>\r\n<p>Zeid has served as the High Commissioner since September 2014. He is the first Asian, Muslim and Arab to serve as the High Commissioner and is the seventh individual to lead the office. Zeid previously served as Jordan's Permanent Representative to the United Nations in New York and as Jordan's Ambassador to the United States. He has worked for the UN in different capacities since 1996. Zeid holds a Bachelor of Arts degree from Johns Hopkins University and a Doctorate in Philosophy from Cambridge University.&nbsp;</p>\r\n<p>The event is free and open to the public. Sponsored by the <a href=\"https://law.vanderbilt.edu/academics/academic-programs/international-legal-studies/index.php\">International Legal Studies Program</a>.&nbsp;</p></div>",
        "categories": [
            "Academic",
            "Law School",
            "Diversity & Inclusion",
            "International"
        ],
        "location": "Vanderbilt Law School - Flynn Auditorium ",
        "description": "[Zeid Ra';ad Al Hussein] (http://www.ohchr.org/EN/AboutUs/Pages/HighCommissioner.aspx) , the United Nations High Commissioner for Human Rights, will speak about his role as the head of the [Office of the High Commissioner for Human Rights] (http://www.ohchr.org/EN/Pages/Home.aspx) at the [Vanderbilt Law School] (https://law.vanderbilt.edu/) on Wednesday, April 5, 2017 at noon in Flynn Auditorium. ; Since the start of the United Nations in 1945, human rights  ;has been a central part of the programming within the UN organization. The Office of the High Commissioner for Human Rights (OHCHR) ensures that the human rights perspective is included in all United Nations programs. Governments are tasked with the responsibility to protect human rights and the OHCHR provides assistance to those governments in order to implement an international human rights standard. ; The office is staffed by over 900 civil servants who work with various governments and organizations to promote and protect human rights through treaties, education, research and other advocacy activities. ; Zeid has served as the High Commissioner since September 2014. He is the first Asian, Muslim and Arab to serve as the High Commissioner and is the seventh individual to lead the office. Zeid previously served as Jordan';s Permanent Representative to the United Nations in New York and as Jordan';s Ambassador to the United States. He has worked for the UN in different capacities since 1996. Zeid holds a Bachelor of Arts degree from Johns Hopkins University and a Doctorate in Philosophy from Cambridge University. ; The event is free and open to the public. Sponsored by the [International Legal Studies Program] (https://law.vanderbilt.edu/academics/academic-programs/international-legal-studies/index.php) . ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">ESB</span></div> <div class=\"description\"><p>Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events</p></div>",
        "title": "M.E. Graduate Student Seminar",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">ESB</span></div> <div class=\"description\"><p>Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events</p></div>",
        "categories": [],
        "location": "ESB",
        "description": "Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM.</p>\r\n<p>Join us as we \"live among the psalms\" in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God's presence, and a blessing.</p>\r\n<p>&nbsp;</p></div>",
        "title": "One Psalm",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM.</p>\r\n<p>Join us as we \"live among the psalms\" in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God's presence, and a blessing.</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Religious/Spiritual"
        ],
        "location": "Benton Chapel",
        "description": "The Lenten Journey began with Ash Wednesday and continues each week during Lent on Wednesdays in Benton Chapel from 12:10 PM - 12: 25 PM. Join us as we \";live among the psalms\"; in this Lenten Season. Each Wednesday we will share in the reading of a psalm, a prayer, a short time of quiet to pause and reflect in God';s presence, and a blessing.  ; "
    },
    {
        "time": "12:15:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:15:00\">12:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:45:00\">12:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>This alcohol and other drug education presentation will prepare hosts to have safe and successful events through the discussion of Tennessee State Law, Vanderbilt Policy, and DUI prevention strategies.&nbsp; The presentation is approximately 30 minutes in length and is required annually for hosts of events where alcohol is present.</p></div>",
        "title": "Graduate/Professional Student Host Responsibility Training",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:15:00\">12:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:45:00\">12:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>This alcohol and other drug education presentation will prepare hosts to have safe and successful events through the discussion of Tennessee State Law, Vanderbilt Policy, and DUI prevention strategies.&nbsp; The presentation is approximately 30 minutes in length and is required annually for hosts of events where alcohol is present.</p></div>",
        "categories": [],
        "location": "Center for Student Wellbeing",
        "description": "This alcohol and other drug education presentation will prepare hosts to have safe and successful events through the discussion of Tennessee State Law, Vanderbilt Policy, and DUI prevention strategies. ; The presentation is approximately 30 minutes in length and is required annually for hosts of events where alcohol is present. "
    },
    {
        "time": "12:30:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:30:00\">12:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Peabody Campus, Home Economics Building #104</span></div> <div class=\"description\"><p>Sponsored by PILS (Peabody International Lunch Series)</p>\r\n<p><strong><a href=\"https://www.mailman.columbia.edu/people/our-faculty/jpa1\">John Allegrante, Ph.D.</a></strong>, Professor of Health Education, Mailman School of Public Health, Columbia University discusses what the United States can learn from Iceland. Allegrante was a Fulbright U.S. Scholar in Iceland in 2007. Lunch will be provided to those who <a href=\"https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA\" target=\"_blank\">RSVP by March 27, 2017</a>.</p>\r\n<ul>\r\n<li><strong>Date:</strong> Wednesday, April 5</li>\r\n<li><strong>Time: </strong>12:30 - 1:30 p.m.</li>\r\n<li><strong>Location:</strong>&nbsp;Home Economics Building #104, College of Education and Human Development, Peabody College, Vanderbilt University</li>\r\n<li><strong>Parking: </strong>For off-campus attendees, on-street&nbsp;parking spaces are located along Magnolia Circle and 19th Avenue South (<a href=\"http://cpc-fis.vanderbilt.edu/pdf/VisitorCampusMap.pdf\" target=\"_blank\">click here for a map</a>).</li>\r\n</ul></div>",
        "title": "National Public Health Week - What Can We Learn Fr...",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:30:00\">12:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Peabody Campus, Home Economics Building #104</span></div> <div class=\"description\"><p>Sponsored by PILS (Peabody International Lunch Series)</p>\r\n<p><strong><a href=\"https://www.mailman.columbia.edu/people/our-faculty/jpa1\">John Allegrante, Ph.D.</a></strong>, Professor of Health Education, Mailman School of Public Health, Columbia University discusses what the United States can learn from Iceland. Allegrante was a Fulbright U.S. Scholar in Iceland in 2007. Lunch will be provided to those who <a href=\"https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA\" target=\"_blank\">RSVP by March 27, 2017</a>.</p>\r\n<ul>\r\n<li><strong>Date:</strong> Wednesday, April 5</li>\r\n<li><strong>Time: </strong>12:30 - 1:30 p.m.</li>\r\n<li><strong>Location:</strong>&nbsp;Home Economics Building #104, College of Education and Human Development, Peabody College, Vanderbilt University</li>\r\n<li><strong>Parking: </strong>For off-campus attendees, on-street&nbsp;parking spaces are located along Magnolia Circle and 19th Avenue South (<a href=\"http://cpc-fis.vanderbilt.edu/pdf/VisitorCampusMap.pdf\" target=\"_blank\">click here for a map</a>).</li>\r\n</ul></div>",
        "categories": [
            "International",
            "Health & Wellness",
            "Graduate/Professional Students",
            "School of Medicine"
        ],
        "location": "Peabody Campus, Home Economics Building #104",
        "description": "Sponsored by PILS (Peabody International Lunch Series) [John Allegrante, Ph.D.] (https://www.mailman.columbia.edu/people/our-faculty/jpa1) , Professor of Health Education, Mailman School of Public Health, Columbia University discusses what the United States can learn from Iceland. Allegrante was a Fulbright U.S. Scholar in Iceland in 2007. Lunch will be provided to those who [RSVP by March 27, 2017] (https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA) . ---Date: Wednesday, April 5  ---Time: 12:30 - 1:30 p.m.  ---Location: ;Home Economics Building #104, College of Education and Human Development, Peabody College, Vanderbilt University  ---Parking: For off-campus attendees, on-street ;parking spaces are located along Magnolia Circle and 19th Avenue South ( [click here for a map] (http://cpc-fis.vanderbilt.edu/pdf/VisitorCampusMap.pdf) ).  "
    },
    {
        "time": "14:30:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:30:00\">2:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:30:00\">3:30 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance</span></div> <div class=\"description\"><div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">Please join the Federalist Society,, Phi Delta Phi, and the Branstetter Program in Renaissance at 2:30 pm&nbsp;as we host a conversation about the judicial confirmation process between the Honorable Reed O'Connor of the&nbsp;United States District Court for the Northern District of Texas and Professor Brian T. Fitzpatrick. &nbsp;</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">&nbsp;</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">Judge O'Connor graduated from South Texas College of Law in 1989. He worked in private practice, as an assistant district attorney, and as assistant United States Attorney before working on the U.S. Senate Committee on the Judiciary from 2003 to 2007. &nbsp;In 2007, Judge O'Connor was nominated by President George W. Bush and confirmed by the United States Senate to the United States District Court for the Northern District of Texas.</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">&nbsp;</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">Professor Fitzpatrick graduated&nbsp;first in his class at Harvard Law School. He then clerked for Supreme Court Justice Antonin Scalia and 9th Circuit Judge Diarmuid O'Scannlain.&nbsp;Between his time as a clerk and professor, Professor Fitzpatrick served as Special Counsel for Supreme Court Nominations to Senator John Cornyn.</font></div></div>",
        "title": "Advise and Consent: A Conversation about the Judicial Confirmation Process",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:30:00\">2:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:30:00\">3:30 PM</span>)</b> <div>Location: <span class=\"location\">Renaissance</span></div> <div class=\"description\"><div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">Please join the Federalist Society,, Phi Delta Phi, and the Branstetter Program in Renaissance at 2:30 pm&nbsp;as we host a conversation about the judicial confirmation process between the Honorable Reed O'Connor of the&nbsp;United States District Court for the Northern District of Texas and Professor Brian T. Fitzpatrick. &nbsp;</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">&nbsp;</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">Judge O'Connor graduated from South Texas College of Law in 1989. He worked in private practice, as an assistant district attorney, and as assistant United States Attorney before working on the U.S. Senate Committee on the Judiciary from 2003 to 2007. &nbsp;In 2007, Judge O'Connor was nominated by President George W. Bush and confirmed by the United States Senate to the United States District Court for the Northern District of Texas.</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">&nbsp;</font></div>\r\n<div class=\"WordSection1\"><font size=\"2\" face=\"Segoe UI\">Professor Fitzpatrick graduated&nbsp;first in his class at Harvard Law School. He then clerked for Supreme Court Justice Antonin Scalia and 9th Circuit Judge Diarmuid O'Scannlain.&nbsp;Between his time as a clerk and professor, Professor Fitzpatrick served as Special Counsel for Supreme Court Nominations to Senator John Cornyn.</font></div></div>",
        "categories": [
            "Law School"
        ],
        "location": "Renaissance",
        "description": "Please join the Federalist Society,, Phi Delta Phi, and the Branstetter Program in Renaissance at 2:30 pm ;as we host a conversation about the judicial confirmation process between the Honorable Reed O';Connor of the ;United States District Court for the Northern District of Texas and Professor Brian T. Fitzpatrick.  ;  ; Judge O';Connor graduated from South Texas College of Law in 1989. He worked in private practice, as an assistant district attorney, and as assistant United States Attorney before working on the U.S. Senate Committee on the Judiciary from 2003 to 2007.  ;In 2007, Judge O';Connor was nominated by President George W. Bush and confirmed by the United States Senate to the United States District Court for the Northern District of Texas.  ; Professor Fitzpatrick graduated ;first in his class at Harvard Law School. He then clerked for Supreme Court Justice Antonin Scalia and 9th Circuit Judge Diarmuid O';Scannlain. ;Between his time as a clerk and professor, Professor Fitzpatrick served as Special Counsel for Supreme Court Nominations to Senator John Cornyn. "
    },
    {
        "time": "17:30:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">ISSS Lobby</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend <strong>Curricular Practical Training (CPT)</strong>&nbsp;and/or <strong>Optional Practical Training (OPT)</strong> workshops and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n<li>OPT is a 12-month employment authorization, related to a student&rsquo;s field of study, that can be used during or after academic studies are complete.</li>\r\n</ul>\r\n<p><em>Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services?</em></p>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT and/or OPT workshop will now be <u>required</u> before applying for employment authorization.&nbsp;</strong><strong><em>Spots are limited!</em></strong></p></div>",
        "title": "OPT Workshop",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">ISSS Lobby</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend <strong>Curricular Practical Training (CPT)</strong>&nbsp;and/or <strong>Optional Practical Training (OPT)</strong> workshops and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n<li>OPT is a 12-month employment authorization, related to a student&rsquo;s field of study, that can be used during or after academic studies are complete.</li>\r\n</ul>\r\n<p><em>Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services?</em></p>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT and/or OPT workshop will now be <u>required</u> before applying for employment authorization.&nbsp;</strong><strong><em>Spots are limited!</em></strong></p></div>",
        "categories": [
            "International",
            "Career Development"
        ],
        "location": "ISSS Lobby",
        "description": "F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!! Have you ever thought about working off campus or interning for a company in the United States? Attend Curricular Practical Training (CPT) ;and/or Optional Practical Training (OPT) workshops and get the facts about how to apply for employment authorization. ---CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment. ;  ---OPT is a 12-month employment authorization, related to a student&#x2019;s field of study, that can be used during or after academic studies are complete.  Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services? Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States? These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall. ; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States. ; CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&#x2019;s, master&#x2019;s, doctoral). ; If you have an interest to work off campus, please sign up for the Spring ;workshops. ;Attendance at a CPT and/or OPT workshop will now be required before applying for employment authorization. ;Spots are limited! "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall 201</span></div> <div class=\"description\"><p>The Woman to Watch series is the educational branch of WIB. These events are hosted by a variety of businesspeople offering expertise and insight on different topics pertaining to career development. Our partners, the Women&rsquo;s Business Association at Owen, also host events in this series. The name derives from the goal to empower and educate our members by bringing in inspirational businesspeople.</p></div>",
        "title": "Woman to Watch, Event 3, Krissy DeAlejandro",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall 201</span></div> <div class=\"description\"><p>The Woman to Watch series is the educational branch of WIB. These events are hosted by a variety of businesspeople offering expertise and insight on different topics pertaining to career development. Our partners, the Women&rsquo;s Business Association at Owen, also host events in this series. The name derives from the goal to empower and educate our members by bringing in inspirational businesspeople.</p></div>",
        "categories": [
            "Career Development",
            "Diversity & Inclusion",
            "Women & Gender Issues",
            "Greek Member Experience",
            "GME - Personal Development"
        ],
        "location": "Alumni Hall 201",
        "description": "The Woman to Watch series is the educational branch of WIB. These events are hosted by a variety of businesspeople offering expertise and insight on different topics pertaining to career development. Our partners, the Women&#x2019;s Business Association at Owen, also host events in this series. The name derives from the goal to empower and educate our members by bringing in inspirational businesspeople. "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">New Rand</span></div> <div class=\"description\"><p>A collaborative performance featuring many of Vanderbilt's dance organizations. &nbsp;</p></div>",
        "title": "FLASHDANCE",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:30:00\">8:30 PM</span>)</b> <div>Location: <span class=\"location\">New Rand</span></div> <div class=\"description\"><p>A collaborative performance featuring many of Vanderbilt's dance organizations. &nbsp;</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "New Rand",
        "description": "A collaborative performance featuring many of Vanderbilt';s dance organizations.  ; "
    },
    {
        "time": "19:30:00",
        "date": "2017-04-05",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:15:00\">9:15 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Tara McKay, Assistant Professor of Medicine, Health, &amp; Society, and Assistant Professor of Health Policy.</p>\r\n<p><strong>USA (2016) </strong>Dir: Tiffany Rhynard. This documentary film follows the personal transformation and activism of Moises Serrano, a young, undocumented and queer immigrant living in rural North Carolina. It is anticipated that Mr. Serrano will be in attendance at the screening. English. 90 min. DVD. <em>Presented in collaboration with the Center for Medicine, Health, &amp; Society</em>; The <em>Latino &amp; Latina Studies Program, and LGBTQI Life.</em></p></div>",
        "title": "iLens: Forbidden: Queer & Undocumented in Rural America",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-05\">Wednesday, April 5, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:15:00\">9:15 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented by Tara McKay, Assistant Professor of Medicine, Health, &amp; Society, and Assistant Professor of Health Policy.</p>\r\n<p><strong>USA (2016) </strong>Dir: Tiffany Rhynard. This documentary film follows the personal transformation and activism of Moises Serrano, a young, undocumented and queer immigrant living in rural North Carolina. It is anticipated that Mr. Serrano will be in attendance at the screening. English. 90 min. DVD. <em>Presented in collaboration with the Center for Medicine, Health, &amp; Society</em>; The <em>Latino &amp; Latina Studies Program, and LGBTQI Life.</em></p></div>",
        "categories": [
            "Political",
            "Diversity & Inclusion",
            "Visual Arts",
            "Film/Movie",
            "LGBTQI Life"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by Tara McKay, Assistant Professor of Medicine, Health, &; Society, and Assistant Professor of Health Policy. USA (2016) Dir: Tiffany Rhynard. This documentary film follows the personal transformation and activism of Moises Serrano, a young, undocumented and queer immigrant living in rural North Carolina. It is anticipated that Mr. Serrano will be in attendance at the screening. English. 90 min. DVD. Presented in collaboration with the Center for Medicine, Health, &; Society; The Latino &; Latina Studies Program, and LGBTQI Life. "
    },
    {
        "time": "09:00:00",
        "date": "2017-04-06",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience",
            "Health & Wellness",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-06",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 216/220</span></div> <div class=\"description\"><p>Have you ever been in the midst of a conversation, or overheard an insensitive remark and found yourself, standing there, in silence, thinking &ldquo;What can I say in response to that?&rdquo; Or, have you ever seen someone treated unjustly, such as being ignored or overlooked in a setting, and you wondered if it was due to that person&rsquo;s identity (race, ethnicity, &nbsp;gender, or other visible quality)?&nbsp;&nbsp;&nbsp; Have you ever then wondered, &ldquo;what should I have done?&rdquo; &nbsp;&nbsp;This session will focus on how to address those uncomfortable situations. The intent is offer tools and suggestions which will help you address such situations as they occur in everyday life. Facilitated by Dr. Frank Dobson and Kathryn Farkas, Graduate Assistant.</p></div>",
        "title": "Talk About it Thursday: Breaking the Cycle: Speaking Up Against Everday Bigotry",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 216/220</span></div> <div class=\"description\"><p>Have you ever been in the midst of a conversation, or overheard an insensitive remark and found yourself, standing there, in silence, thinking &ldquo;What can I say in response to that?&rdquo; Or, have you ever seen someone treated unjustly, such as being ignored or overlooked in a setting, and you wondered if it was due to that person&rsquo;s identity (race, ethnicity, &nbsp;gender, or other visible quality)?&nbsp;&nbsp;&nbsp; Have you ever then wondered, &ldquo;what should I have done?&rdquo; &nbsp;&nbsp;This session will focus on how to address those uncomfortable situations. The intent is offer tools and suggestions which will help you address such situations as they occur in everyday life. Facilitated by Dr. Frank Dobson and Kathryn Farkas, Graduate Assistant.</p></div>",
        "categories": [
            "Diversity & Inclusion"
        ],
        "location": "Sarratt 216/220",
        "description": "Have you ever been in the midst of a conversation, or overheard an insensitive remark and found yourself, standing there, in silence, thinking &#x201C;What can I say in response to that?&#x201D; Or, have you ever seen someone treated unjustly, such as being ignored or overlooked in a setting, and you wondered if it was due to that person&#x2019;s identity (race, ethnicity,  ;gender, or other visible quality)? ; ; ; Have you ever then wondered, &#x201C;what should I have done?&#x201D;  ; ;This session will focus on how to address those uncomfortable situations. The intent is offer tools and suggestions which will help you address such situations as they occur in everyday life. Facilitated by Dr. Frank Dobson and Kathryn Farkas, Graduate Assistant. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-06",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Patio</span></div> <div class=\"description\"><p>The Engineering Council will be holding a de-stress event, open to all engineering students.</p></div>",
        "title": "April De-Stress Event",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Patio</span></div> <div class=\"description\"><p>The Engineering Council will be holding a de-stress event, open to all engineering students.</p></div>",
        "categories": [],
        "location": "Featheringill Patio",
        "description": "The Engineering Council will be holding a de-stress event, open to all engineering students. "
    },
    {
        "time": "15:00:00",
        "date": "2017-04-06",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Nashville CARES</span></div> <div class=\"description\"><p><strong><a href=\"http://www.nashvillecares.org/\" target=\"_blank\">Nashville CARES</a></strong>&nbsp;is a community-based, 501(c)(3) nonprofit AIDS service organization that works to end the HIV/AIDS epidemic in Middle Tennessee through education, advocacy, and support for those at risk or living with HIV. A group of&nbsp;Vanderbilt students will sort and pack safe sex kits to be distributed at educational outreach events. All are welcome to participate.</p>\r\n<ul>\r\n<li><strong>Date: </strong>Thursday, April 6</li>\r\n<li><strong>Time:</strong> 3 - 5 p.m.</li>\r\n<li><strong>Location: </strong>633 Thompson Lane, Nashville, TN 37204&nbsp;</li>\r\n<li><strong>Transportation:&nbsp;</strong><a href=\"https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA\" target=\"_blank\">Click here to participate in the carpool as a driver or passenger</a>.</li>\r\n</ul></div>",
        "title": "National Public Health Week -  Service Activity at...",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Nashville CARES</span></div> <div class=\"description\"><p><strong><a href=\"http://www.nashvillecares.org/\" target=\"_blank\">Nashville CARES</a></strong>&nbsp;is a community-based, 501(c)(3) nonprofit AIDS service organization that works to end the HIV/AIDS epidemic in Middle Tennessee through education, advocacy, and support for those at risk or living with HIV. A group of&nbsp;Vanderbilt students will sort and pack safe sex kits to be distributed at educational outreach events. All are welcome to participate.</p>\r\n<ul>\r\n<li><strong>Date: </strong>Thursday, April 6</li>\r\n<li><strong>Time:</strong> 3 - 5 p.m.</li>\r\n<li><strong>Location: </strong>633 Thompson Lane, Nashville, TN 37204&nbsp;</li>\r\n<li><strong>Transportation:&nbsp;</strong><a href=\"https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA\" target=\"_blank\">Click here to participate in the carpool as a driver or passenger</a>.</li>\r\n</ul></div>",
        "categories": [
            "Service & Philanthropy",
            "Health & Wellness",
            "Graduate/Professional Students",
            "Volunteer Opportunities Calendar",
            "School of Medicine"
        ],
        "location": "Nashville CARES",
        "description": "[Nashville CARES] (http://www.nashvillecares.org/)  ;is a community-based, 501(c)(3) nonprofit AIDS service organization that works to end the HIV/AIDS epidemic in Middle Tennessee through education, advocacy, and support for those at risk or living with HIV. A group of ;Vanderbilt students will sort and pack safe sex kits to be distributed at educational outreach events. All are welcome to participate. ---Date: Thursday, April 6  ---Time: 3 - 5 p.m.  ---Location: 633 Thompson Lane, Nashville, TN 37204 ;  ---Transportation: ; [Click here to participate in the carpool as a driver or passenger] (https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA) .  "
    },
    {
        "text": "<b><span class=\"dtstart\" title=\"2017-04-06T15:00:00\">Thursday, April 6, 2017 (3:00 PM)</span> - <span class=\"dtend\" title=\"2017-04-09T12:00:00\">Sunday, April 9, 2017 (12:00 PM)</span></b> <div>Location: <span class=\"location\">VUSM</span></div> <div class=\"description\"><p>Accepted students will&nbsp;be on campus to learn about VUSM.</p></div>",
        "title": "Second Look Weekend 2017",
        "summary": "<b><span class=\"dtstart\" title=\"2017-04-06T15:00:00\">Thursday, April 6, 2017 (3:00 PM)</span> - <span class=\"dtend\" title=\"2017-04-09T12:00:00\">Sunday, April 9, 2017 (12:00 PM)</span></b> <div>Location: <span class=\"location\">VUSM</span></div> <div class=\"description\"><p>Accepted students will&nbsp;be on campus to learn about VUSM.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "VUSM",
        "description": "Accepted students will ;be on campus to learn about VUSM. "
    },
    {
        "time": "15:15:00",
        "date": "2017-04-06",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-06",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Vanderbilt Off-Broadway is proud to present <em>The&nbsp;25th Annual Putnam County Spelling Bee</em>, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium,<em>&nbsp;The 25th Annual Putnam County Spelling Bee</em> is the can't-miss musical comedy event of the spring!</span></p></div>",
        "title": "Vanderbilt Off-Broadway Presents: 25th Annual Putnam County Spelling Bee",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Vanderbilt Off-Broadway is proud to present <em>The&nbsp;25th Annual Putnam County Spelling Bee</em>, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium,<em>&nbsp;The 25th Annual Putnam County Spelling Bee</em> is the can't-miss musical comedy event of the spring!</span></p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Campus Involvement",
            "Performing Arts"
        ],
        "location": "Sarratt Cinema",
        "description": "Vanderbilt Off-Broadway is proud to present The ;25th Annual Putnam County Spelling Bee, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium, ;The 25th Annual Putnam County Spelling Bee is the can';t-miss musical comedy event of the spring! "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-06",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students!</p>\r\n<p>THIS QUINTESSENCE OF DUST by Cory Hinkle<br />Directed by Benjamin Kitchens<br />A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&hellip; and then the end of the world happened.<br /><br />THE BALLAD OF 423 AND 424 by Nicholas C. Pappas<br />Directed by Benjamin Kitchens<br />When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&rsquo;s knock?<br /><br />THE WEDDING GUEST by Steve Moulds<br />Directed by Hannah Lazarz<br />You&rsquo;re getting married tomorrow. The people you love are here. It&rsquo;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&mdash;the cousin no one&rsquo;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&rsquo;ve ever made&mdash;well, at least he won&rsquo;t come. Unless he does.</p></div>",
        "title": "Spring Directing Showcase",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-06\">Thursday, April 6, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students!</p>\r\n<p>THIS QUINTESSENCE OF DUST by Cory Hinkle<br />Directed by Benjamin Kitchens<br />A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&hellip; and then the end of the world happened.<br /><br />THE BALLAD OF 423 AND 424 by Nicholas C. Pappas<br />Directed by Benjamin Kitchens<br />When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&rsquo;s knock?<br /><br />THE WEDDING GUEST by Steve Moulds<br />Directed by Hannah Lazarz<br />You&rsquo;re getting married tomorrow. The people you love are here. It&rsquo;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&mdash;the cousin no one&rsquo;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&rsquo;ve ever made&mdash;well, at least he won&rsquo;t come. Unless he does.</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Neely Auditorium",
        "description": "Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students! THIS QUINTESSENCE OF DUST by Cory Hinkle Directed by Benjamin Kitchens A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&#x2026; and then the end of the world happened. THE BALLAD OF 423 AND 424 by Nicholas C. Pappas Directed by Benjamin Kitchens When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&#x2019;s knock? THE WEDDING GUEST by Steve Moulds Directed by Hannah Lazarz You&#x2019;re getting married tomorrow. The people you love are here. It&#x2019;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&#x2014;the cousin no one&#x2019;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&#x2019;ve ever made&#x2014;well, at least he won&#x2019;t come. Unless he does. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Graduate/Professional Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p><span style=\"font-size: 13px;\">Do you ever find your thoughts wandering to your never-ending to do list and five minutes later to that time two weeks ago when you said something embarrassing? &nbsp;Mindfulness is paying attention in a particular way, on purpose, and non-judgmentally in a present moment. </span><span style=\"font-size: 13px;\">Students will become more knowledgeable about mindfulness practices, the science of and research related to mindfulness, exercises that foster a deeper understanding of mindfulness, and relaxation techniques to use when faced with stress. Students will be challenged to think on their own about how to integrate what they learned from the session into their day-to-day life. </span></p></div>",
        "title": "Introduction to Mindfulness",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p><span style=\"font-size: 13px;\">Do you ever find your thoughts wandering to your never-ending to do list and five minutes later to that time two weeks ago when you said something embarrassing? &nbsp;Mindfulness is paying attention in a particular way, on purpose, and non-judgmentally in a present moment. </span><span style=\"font-size: 13px;\">Students will become more knowledgeable about mindfulness practices, the science of and research related to mindfulness, exercises that foster a deeper understanding of mindfulness, and relaxation techniques to use when faced with stress. Students will be challenged to think on their own about how to integrate what they learned from the session into their day-to-day life. </span></p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Do you ever find your thoughts wandering to your never-ending to do list and five minutes later to that time two weeks ago when you said something embarrassing?  ;Mindfulness is paying attention in a particular way, on purpose, and non-judgmentally in a present moment. Students will become more knowledgeable about mindfulness practices, the science of and research related to mindfulness, exercises that foster a deeper understanding of mindfulness, and relaxation techniques to use when faced with stress. Students will be challenged to think on their own about how to integrate what they learned from the session into their day-to-day life.  "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt MPH Program Classroom</span></div> <div class=\"description\"><p><strong><a href=\"https://www.linkedin.com/in/victorwumd/\" target=\"_blank\">Victor Wu, M.D., M.P.H.</a></strong>, Chief Medical Officer of <a href=\"https://www.tn.gov/tenncare/\" target=\"_blank\">TennCare</a>, discusses Medicaid in Tennessee under the new administration. Lunch will be provided to those who <a href=\"https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA\" target=\"_blank\">RSVP by March 27, 2017</a>.</p>\r\n<ul>\r\n<li><strong>Date:</strong> Friday, April 7</li>\r\n<li><strong>Time: </strong>12 &ndash; 1 p.m.&nbsp;</li>\r\n<li><strong>Location:</strong> MPH Classroom #2600, Village at Vanderbilt, 1500 21st Avenue South</li>\r\n<li><strong>Parking: </strong>One-hour visitor parking is available in the surface lot directly behind the building. Patient/Visitor parking is&nbsp;located on level P1 of the building's underground parking garage.</li>\r\n</ul></div>",
        "title": "National Public Health Week - Medicaid under the T...",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt MPH Program Classroom</span></div> <div class=\"description\"><p><strong><a href=\"https://www.linkedin.com/in/victorwumd/\" target=\"_blank\">Victor Wu, M.D., M.P.H.</a></strong>, Chief Medical Officer of <a href=\"https://www.tn.gov/tenncare/\" target=\"_blank\">TennCare</a>, discusses Medicaid in Tennessee under the new administration. Lunch will be provided to those who <a href=\"https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA\" target=\"_blank\">RSVP by March 27, 2017</a>.</p>\r\n<ul>\r\n<li><strong>Date:</strong> Friday, April 7</li>\r\n<li><strong>Time: </strong>12 &ndash; 1 p.m.&nbsp;</li>\r\n<li><strong>Location:</strong> MPH Classroom #2600, Village at Vanderbilt, 1500 21st Avenue South</li>\r\n<li><strong>Parking: </strong>One-hour visitor parking is available in the surface lot directly behind the building. Patient/Visitor parking is&nbsp;located on level P1 of the building's underground parking garage.</li>\r\n</ul></div>",
        "categories": [
            "School of Medicine",
            "Political",
            "Health & Wellness",
            "Graduate/Professional Students"
        ],
        "location": "Vanderbilt MPH Program Classroom",
        "description": "[Victor Wu, M.D., M.P.H.] (https://www.linkedin.com/in/victorwumd/) , Chief Medical Officer of [TennCare] (https://www.tn.gov/tenncare/) , discusses Medicaid in Tennessee under the new administration. Lunch will be provided to those who [RSVP by March 27, 2017] (https://redcap.vanderbilt.edu/surveys/?s=38ARFJCRFA) . ---Date: Friday, April 7  ---Time: 12 &#x2013; 1 p.m. ;  ---Location: MPH Classroom #2600, Village at Vanderbilt, 1500 21st Avenue South  ---Parking: One-hour visitor parking is available in the surface lot directly behind the building. Patient/Visitor parking is ;located on level P1 of the building';s underground parking garage.  "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore </span></div> <div class=\"description\"><p>The International Law Society, Middle Eastern Law Students Association, and Law Students for Social Justice are proud to welcome Professor Laurie Blank of Emory Law School to speak on the extent to which states may use self-defense against terrorist organizations. States using military force to protect their territory, their inhabitants and their interests is, of course, nothing new.&nbsp;&nbsp;But the U.S.&rsquo;s ongoing reliance on self-defense for fifteen-plus years post-9/11 &ndash; including in locations and against groups not contemplated at the time of the 9/11 attacks &ndash; raises essential questions about the extent of self-defense: how far can a state go when acting in self-defense &mdash; both in the geographical sense and in the sense of the legitimate aims of using force &mdash; and for how long does this right of self-defense last?</p>\r\n<p><a href=\"http://law.emory.edu/faculty-and-scholarship/faculty-profiles/blank-profile.html\">Professor Blank</a> is a the Director of the International Humanitarian Law Clinic at Emory Law School and co-director of a multi-year project on military training programs in the law of war. She has written numerous books and articles on international humanitarian law and is an expert on the law of war. Before joining Emory&rsquo;s faculty, Professor Blank worked for the United States Mission to the United Nations, the State Department, and the United States Institute of Peace. She received her J.D. from New York University Law School.</p></div>",
        "title": "The Extent of Self-Defense Against Terrorists: How Far and How Long?",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore </span></div> <div class=\"description\"><p>The International Law Society, Middle Eastern Law Students Association, and Law Students for Social Justice are proud to welcome Professor Laurie Blank of Emory Law School to speak on the extent to which states may use self-defense against terrorist organizations. States using military force to protect their territory, their inhabitants and their interests is, of course, nothing new.&nbsp;&nbsp;But the U.S.&rsquo;s ongoing reliance on self-defense for fifteen-plus years post-9/11 &ndash; including in locations and against groups not contemplated at the time of the 9/11 attacks &ndash; raises essential questions about the extent of self-defense: how far can a state go when acting in self-defense &mdash; both in the geographical sense and in the sense of the legitimate aims of using force &mdash; and for how long does this right of self-defense last?</p>\r\n<p><a href=\"http://law.emory.edu/faculty-and-scholarship/faculty-profiles/blank-profile.html\">Professor Blank</a> is a the Director of the International Humanitarian Law Clinic at Emory Law School and co-director of a multi-year project on military training programs in the law of war. She has written numerous books and articles on international humanitarian law and is an expert on the law of war. Before joining Emory&rsquo;s faculty, Professor Blank worked for the United States Mission to the United Nations, the State Department, and the United States Institute of Peace. She received her J.D. from New York University Law School.</p></div>",
        "categories": [
            "Academic",
            "International",
            "Law School",
            "Political"
        ],
        "location": "Moore ",
        "description": "The International Law Society, Middle Eastern Law Students Association, and Law Students for Social Justice are proud to welcome Professor Laurie Blank of Emory Law School to speak on the extent to which states may use self-defense against terrorist organizations. States using military force to protect their territory, their inhabitants and their interests is, of course, nothing new. ; ;But the U.S.&#x2019;s ongoing reliance on self-defense for fifteen-plus years post-9/11 &#x2013; including in locations and against groups not contemplated at the time of the 9/11 attacks &#x2013; raises essential questions about the extent of self-defense: how far can a state go when acting in self-defense &#x2014; both in the geographical sense and in the sense of the legitimate aims of using force &#x2014; and for how long does this right of self-defense last? [Professor Blank] (http://law.emory.edu/faculty-and-scholarship/faculty-profiles/blank-profile.html) is a the Director of the International Humanitarian Law Clinic at Emory Law School and co-director of a multi-year project on military training programs in the law of war. She has written numerous books and articles on international humanitarian law and is an expert on the law of war. Before joining Emory&#x2019;s faculty, Professor Blank worked for the United States Mission to the United Nations, the State Department, and the United States Institute of Peace. She received her J.D. from New York University Law School. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Hall</span></div> <div class=\"description\"><p>The Engineering Council will be holding a free lunch&nbsp;for all engineering students.</p></div>",
        "title": "April Lunch Social",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill Hall</span></div> <div class=\"description\"><p>The Engineering Council will be holding a free lunch&nbsp;for all engineering students.</p></div>",
        "categories": [],
        "location": "Featheringill Hall",
        "description": "The Engineering Council will be holding a free lunch ;for all engineering students. "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 112</span></div> <div class=\"description\"><p>The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &ndash; resulting in the reduction of violence. This educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) as well as&nbsp;introduces and develops skills needed for bystander intervention strategies.</p></div>",
        "title": "Green Dot Bystander Intervention Training",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"17:00:00\">5:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 112</span></div> <div class=\"description\"><p>The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &ndash; resulting in the reduction of violence. This educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) as well as&nbsp;introduces and develops skills needed for bystander intervention strategies.</p></div>",
        "categories": [
            "Health & Wellness",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Sarratt 112",
        "description": "The Green Dot bystander intervention program is a comprehensive approach to sexual violence prevention that capitalizes on the power of peer and cultural influences. Green Dot challenges all campus community members to be active bystanders, and seeks to engage students, through awareness, education, and skills-practice, in proactive behaviors that establish intolerance of violence as the norm, as well as reactive interventions in high-risk situations &#x2013; resulting in the reduction of violence. This educational program reviews the types of power-based personal violence (sexual assault, intimate partner violence, and stalking) as well as ;introduces and develops skills needed for bystander intervention strategies. "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:45:00\">7:45 PM</span>)</b> <div>Location: <span class=\"location\">Flynn</span></div> <div class=\"description\"><p>Vanderbilt Law School's talent show. The talent show takes place during the second Admitted Student's Weekend. April 7, 2017 -- 6:30 PM.&nbsp;</p></div>",
        "title": "The Last Commodore Standing",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:45:00\">7:45 PM</span>)</b> <div>Location: <span class=\"location\">Flynn</span></div> <div class=\"description\"><p>Vanderbilt Law School's talent show. The talent show takes place during the second Admitted Student's Weekend. April 7, 2017 -- 6:30 PM.&nbsp;</p></div>",
        "categories": [
            "Law School"
        ],
        "location": "Flynn",
        "description": "Vanderbilt Law School';s talent show. The talent show takes place during the second Admitted Student';s Weekend. April 7, 2017 -- 6:30 PM. ; "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">The Bishop Joseph Johnson Black Cultural Center (The BCC)</span></div> <div class=\"description\"><p>Join Vandy Spoken Word in celebrating the art of spoken word! All are welcome to come and perform anything they have written.</p></div>",
        "title": "Vandy Spoken Word Presents: April Open Mic",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">The Bishop Joseph Johnson Black Cultural Center (The BCC)</span></div> <div class=\"description\"><p>Join Vandy Spoken Word in celebrating the art of spoken word! All are welcome to come and perform anything they have written.</p></div>",
        "categories": [
            "Visual Arts",
            "Alcohol Free Late Night Programming",
            "Diversity & Inclusion",
            "Performing Arts"
        ],
        "location": "The Bishop Joseph Johnson Black Cultural Center (The BCC)",
        "description": "Join Vandy Spoken Word in celebrating the art of spoken word! All are welcome to come and perform anything they have written. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students!</p>\r\n<p>THIS QUINTESSENCE OF DUST by Cory Hinkle<br />Directed by Benjamin Kitchens<br />A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&hellip; and then the end of the world happened.<br /><br />THE BALLAD OF 423 AND 424 by Nicholas C. Pappas<br />Directed by Benjamin Kitchens<br />When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&rsquo;s knock?<br /><br />THE WEDDING GUEST by Steve Moulds<br />Directed by Hannah Lazarz<br />You&rsquo;re getting married tomorrow. The people you love are here. It&rsquo;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&mdash;the cousin no one&rsquo;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&rsquo;ve ever made&mdash;well, at least he won&rsquo;t come. Unless he does.</p></div>",
        "title": "Spring Directing Showcase",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students!</p>\r\n<p>THIS QUINTESSENCE OF DUST by Cory Hinkle<br />Directed by Benjamin Kitchens<br />A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&hellip; and then the end of the world happened.<br /><br />THE BALLAD OF 423 AND 424 by Nicholas C. Pappas<br />Directed by Benjamin Kitchens<br />When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&rsquo;s knock?<br /><br />THE WEDDING GUEST by Steve Moulds<br />Directed by Hannah Lazarz<br />You&rsquo;re getting married tomorrow. The people you love are here. It&rsquo;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&mdash;the cousin no one&rsquo;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&rsquo;ve ever made&mdash;well, at least he won&rsquo;t come. Unless he does.</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Neely Auditorium",
        "description": "Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students! THIS QUINTESSENCE OF DUST by Cory Hinkle Directed by Benjamin Kitchens A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&#x2026; and then the end of the world happened. THE BALLAD OF 423 AND 424 by Nicholas C. Pappas Directed by Benjamin Kitchens When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&#x2019;s knock? THE WEDDING GUEST by Steve Moulds Directed by Hannah Lazarz You&#x2019;re getting married tomorrow. The people you love are here. It&#x2019;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&#x2014;the cousin no one&#x2019;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&#x2019;ve ever made&#x2014;well, at least he won&#x2019;t come. Unless he does. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-07",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Vanderbilt Off-Broadway is proud to present <em>The&nbsp;25th Annual Putnam County Spelling Bee</em>, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium,<em>&nbsp;The 25th Annual Putnam County Spelling Bee</em> is the can't-miss musical comedy event of the spring!</span></p></div>",
        "title": "Vanderbilt Off-Broadway Presents: 25th Annual Putnam County Spelling Bee",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-07\">Friday, April 7, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Vanderbilt Off-Broadway is proud to present <em>The&nbsp;25th Annual Putnam County Spelling Bee</em>, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium,<em>&nbsp;The 25th Annual Putnam County Spelling Bee</em> is the can't-miss musical comedy event of the spring!</span></p></div>",
        "categories": [
            "Performing Arts",
            "Greek Member Experience",
            "GME - Campus Involvement"
        ],
        "location": "Sarratt Cinema",
        "description": "Vanderbilt Off-Broadway is proud to present The ;25th Annual Putnam County Spelling Bee, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium, ;The 25th Annual Putnam County Spelling Bee is the can';t-miss musical comedy event of the spring! "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-08",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>Holi is the Indian festival of color, which celebrates the victory of good over evil. Join us on Alumni Lawn for pizza, music, and gulal (colored powder)!</p></div>",
        "title": "Holi",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Lawn</span></div> <div class=\"description\"><p>Holi is the Indian festival of color, which celebrates the victory of good over evil. Join us on Alumni Lawn for pizza, music, and gulal (colored powder)!</p></div>",
        "categories": [
            "GME - Diversity & Inclusion",
            "Greek Member Experience"
        ],
        "location": "Alumni Lawn",
        "description": "Holi is the Indian festival of color, which celebrates the victory of good over evil. Join us on Alumni Lawn for pizza, music, and gulal (colored powder)! "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-08",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill 136</span></div> <div class=\"description\"><p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;VANDY LAND 3 will be much like its predecessors. It's an event that will feature tournaments for Super Smash Bros. games for veterans, casuals, and beginners alike. Outsiders are welcome! If you don't want to play in the tournaments you are free to come, hangout, and play casually.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:769,&quot;3&quot;:{&quot;1&quot;:0},&quot;11&quot;:4,&quot;12&quot;:0}\">VANDY LAND 3 will be much like its predecessors. It's an event that will feature tournaments for Super Smash Bros. games for veterans, casuals, and beginners alike. Outsiders are welcome! If you don't want to play in the tournaments you are free to come, hangout, and play casually.</span></p></div>",
        "title": "VANDY LAND 3",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Featheringill 136</span></div> <div class=\"description\"><p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;VANDY LAND 3 will be much like its predecessors. It's an event that will feature tournaments for Super Smash Bros. games for veterans, casuals, and beginners alike. Outsiders are welcome! If you don't want to play in the tournaments you are free to come, hangout, and play casually.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:769,&quot;3&quot;:{&quot;1&quot;:0},&quot;11&quot;:4,&quot;12&quot;:0}\">VANDY LAND 3 will be much like its predecessors. It's an event that will feature tournaments for Super Smash Bros. games for veterans, casuals, and beginners alike. Outsiders are welcome! If you don't want to play in the tournaments you are free to come, hangout, and play casually.</span></p></div>",
        "categories": [
            "Performing Arts",
            "Diversity & Inclusion",
            "Visual Arts",
            "Athletics",
            "Religious/Spiritual"
        ],
        "location": "Featheringill 136",
        "description": "VANDY LAND 3 will be much like its predecessors. It';s an event that will feature tournaments for Super Smash Bros. games for veterans, casuals, and beginners alike. Outsiders are welcome! If you don';t want to play in the tournaments you are free to come, hangout, and play casually. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-08",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students!</p>\r\n<p>THIS QUINTESSENCE OF DUST by Cory Hinkle<br />Directed by Benjamin Kitchens<br />A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&hellip; and then the end of the world happened.<br /><br />THE BALLAD OF 423 AND 424 by Nicholas C. Pappas<br />Directed by Benjamin Kitchens<br />When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&rsquo;s knock?<br /><br />THE WEDDING GUEST by Steve Moulds<br />Directed by Hannah Lazarz<br />You&rsquo;re getting married tomorrow. The people you love are here. It&rsquo;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&mdash;the cousin no one&rsquo;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&rsquo;ve ever made&mdash;well, at least he won&rsquo;t come. Unless he does.</p></div>",
        "title": "Spring Directing Showcase",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students!</p>\r\n<p>THIS QUINTESSENCE OF DUST by Cory Hinkle<br />Directed by Benjamin Kitchens<br />A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&hellip; and then the end of the world happened.<br /><br />THE BALLAD OF 423 AND 424 by Nicholas C. Pappas<br />Directed by Benjamin Kitchens<br />When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&rsquo;s knock?<br /><br />THE WEDDING GUEST by Steve Moulds<br />Directed by Hannah Lazarz<br />You&rsquo;re getting married tomorrow. The people you love are here. It&rsquo;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&mdash;the cousin no one&rsquo;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&rsquo;ve ever made&mdash;well, at least he won&rsquo;t come. Unless he does.</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Neely Auditorium",
        "description": "Come see these three one acts, directed by senior theatre majors and featuring current Vanderbilt students! THIS QUINTESSENCE OF DUST by Cory Hinkle Directed by Benjamin Kitchens A play about that time when Jane went on vacation to Los Angeles to meet up with friends, but in a moment of weakness had coffee with her ex-boyfriend Chip&#x2026; and then the end of the world happened. THE BALLAD OF 423 AND 424 by Nicholas C. Pappas Directed by Benjamin Kitchens When a new neighbor moves in next door to one of the most popular and reclusive novelists in the world, she knocks his entire obsessive routine out of balance. In this opening-and-closing-door ballet of love and loneliness, will either be brave enough to answer the other&#x2019;s knock? THE WEDDING GUEST by Steve Moulds Directed by Hannah Lazarz You&#x2019;re getting married tomorrow. The people you love are here. It&#x2019;s a beautiful day. And if you happen to have invited your distant cousin to the wedding&#x2014;the cousin no one&#x2019;s seen in years, whose net worth is many hundreds of millions, who inspires you to reconsider, with existential dread, every choice you&#x2019;ve ever made&#x2014;well, at least he won&#x2019;t come. Unless he does. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-08",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Vanderbilt Off-Broadway is proud to present <em>The&nbsp;25th Annual Putnam County Spelling Bee</em>, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium,<em>&nbsp;The 25th Annual Putnam County Spelling Bee</em> is the can't-miss musical comedy event of the spring!</span></p></div>",
        "title": "Vanderbilt Off-Broadway Presents: 25th Annual Putnam County Spelling Bee",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-08\">Saturday, April 8, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p class=\"p1\"><span class=\"s1\">Vanderbilt Off-Broadway is proud to present <em>The&nbsp;25th Annual Putnam County Spelling Bee</em>, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium,<em>&nbsp;The 25th Annual Putnam County Spelling Bee</em> is the can't-miss musical comedy event of the spring!</span></p></div>",
        "categories": [
            "Performing Arts",
            "Greek Member Experience",
            "GME - Campus Involvement"
        ],
        "location": "Sarratt Cinema",
        "description": "Vanderbilt Off-Broadway is proud to present The ;25th Annual Putnam County Spelling Bee, a laugh-out-loud musical about a misfit band of kids competing for the chance to represent Putnam County at the National Spelling Bee. With fierce competition, sabotage, magical feet, a few too many juice boxes, the trials of puberty, and much Pandemonium, ;The 25th Annual Putnam County Spelling Bee is the can';t-miss musical comedy event of the spring! "
    },
    {
        "time": "11:00:00",
        "date": "2017-04-09",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "title": "Cereal Sundays",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "categories": [],
        "location": "Moore College Faculty Director Apartment (Smith 502)",
        "description": "Stop by Dr. L';s apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out! "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-09",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Smith 502</span></div> <div class=\"description\"><p>Join us for a casual meal in Dr.L's faculty director apartment! There is no RSVP and no formal program - Just come, eat, and chat!&nbsp;</p></div>",
        "title": "Moore College Sunday Dinner",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Smith 502</span></div> <div class=\"description\"><p>Join us for a casual meal in Dr.L's faculty director apartment! There is no RSVP and no formal program - Just come, eat, and chat!&nbsp;</p></div>",
        "categories": [],
        "location": "Smith 502",
        "description": "Join us for a casual meal in Dr.L';s faculty director apartment! There is no RSVP and no formal program - Just come, eat, and chat! ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-09",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Scales 3</span></div> <div class=\"description\"><p>Scales 3 bi-weekly floor program&nbsp;</p></div>",
        "title": "Sweats and Shows",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Scales 3</span></div> <div class=\"description\"><p>Scales 3 bi-weekly floor program&nbsp;</p></div>",
        "categories": [],
        "location": "Scales 3",
        "description": "Scales 3 bi-weekly floor program ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-09",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "title": "Sutherland Social",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-09\">Sunday, April 9, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "categories": [
            "The Ingram Commons"
        ],
        "location": "Sutherland House",
        "description": "Come fellowship with Sutherland residents with food and fun! "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-10",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Flynn Auditorium</span></div> <div class=\"description\"><p>How to Win a Record $2.5 Billion Patent Verdict: a Conversation Between Lead Counsel Stephanie Parker (&lsquo;84) and Professor Sean Seymore.</p>\r\n<p>Vanderbilt law alumna Stephanie Parker and law professor Sean Seymore will discuss Idenix Pharmaceutical&rsquo;s willful patent infringement lawsuit against Gilead Sciences.&nbsp; Idenix, a unit of Merck &amp; Co., accused Gilead of using a patented invention as the basis for Gilead&rsquo;s blockbuster drugs for the potentially deadly liver disease hepatitis C. &nbsp;&nbsp;After a nine-day trial, the jury concluded that Gilead willfully infringed on Idenix&rsquo;s valid patent.&nbsp; The jury ordered Gilead to pay $2.54 billion to Idenix, the biggest patent-infringement verdict in U.S. history.&nbsp; The award is more than 50% higher than the next highest jury award in a patent suit, and it far exceeds the median award of $1.5 million in patent suits.</p>\r\n<p>Ms. Parker is based in Jones Day&rsquo;s Atlanta office.&nbsp;Her practice has been focused on products liability and mass tort cases for clients in the tobacco, chemical, pharmaceutical, gasoline, medical device and automotive industries. &nbsp;This was Ms. Parker&rsquo;s first intellectual property case.</p>\r\n<p>In 2015, Ms. Parker was named head of Jones Day&rsquo;s products liability practice, and in 2016, she accepted the duty to lead the 425-lawyer business and tort litigation group.</p>\r\n<p>Professor Seymore is a nationally recognized expert on patent law and litigation.</p>\r\n<p>This event is open to Vanderbilt students and faculty. Catered lunch will be provided. &nbsp;Sponsored by the Branstetter Program and the Vanderbilt IP Association.</p></div>",
        "title": "How to Win a Record $2.5 Billion Patent Verdict: a Conversation Between Lead Counsel Stephanie Parker (‘84) and Professor Sean Seymore.",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Flynn Auditorium</span></div> <div class=\"description\"><p>How to Win a Record $2.5 Billion Patent Verdict: a Conversation Between Lead Counsel Stephanie Parker (&lsquo;84) and Professor Sean Seymore.</p>\r\n<p>Vanderbilt law alumna Stephanie Parker and law professor Sean Seymore will discuss Idenix Pharmaceutical&rsquo;s willful patent infringement lawsuit against Gilead Sciences.&nbsp; Idenix, a unit of Merck &amp; Co., accused Gilead of using a patented invention as the basis for Gilead&rsquo;s blockbuster drugs for the potentially deadly liver disease hepatitis C. &nbsp;&nbsp;After a nine-day trial, the jury concluded that Gilead willfully infringed on Idenix&rsquo;s valid patent.&nbsp; The jury ordered Gilead to pay $2.54 billion to Idenix, the biggest patent-infringement verdict in U.S. history.&nbsp; The award is more than 50% higher than the next highest jury award in a patent suit, and it far exceeds the median award of $1.5 million in patent suits.</p>\r\n<p>Ms. Parker is based in Jones Day&rsquo;s Atlanta office.&nbsp;Her practice has been focused on products liability and mass tort cases for clients in the tobacco, chemical, pharmaceutical, gasoline, medical device and automotive industries. &nbsp;This was Ms. Parker&rsquo;s first intellectual property case.</p>\r\n<p>In 2015, Ms. Parker was named head of Jones Day&rsquo;s products liability practice, and in 2016, she accepted the duty to lead the 425-lawyer business and tort litigation group.</p>\r\n<p>Professor Seymore is a nationally recognized expert on patent law and litigation.</p>\r\n<p>This event is open to Vanderbilt students and faculty. Catered lunch will be provided. &nbsp;Sponsored by the Branstetter Program and the Vanderbilt IP Association.</p></div>",
        "categories": [
            "Law School"
        ],
        "location": "Flynn Auditorium",
        "description": "How to Win a Record $2.5 Billion Patent Verdict: a Conversation Between Lead Counsel Stephanie Parker (&#x2018;84) and Professor Sean Seymore. Vanderbilt law alumna Stephanie Parker and law professor Sean Seymore will discuss Idenix Pharmaceutical&#x2019;s willful patent infringement lawsuit against Gilead Sciences. ; Idenix, a unit of Merck &; Co., accused Gilead of using a patented invention as the basis for Gilead&#x2019;s blockbuster drugs for the potentially deadly liver disease hepatitis C.  ; ;After a nine-day trial, the jury concluded that Gilead willfully infringed on Idenix&#x2019;s valid patent. ; The jury ordered Gilead to pay $2.54 billion to Idenix, the biggest patent-infringement verdict in U.S. history. ; The award is more than 50% higher than the next highest jury award in a patent suit, and it far exceeds the median award of $1.5 million in patent suits. Ms. Parker is based in Jones Day&#x2019;s Atlanta office. ;Her practice has been focused on products liability and mass tort cases for clients in the tobacco, chemical, pharmaceutical, gasoline, medical device and automotive industries.  ;This was Ms. Parker&#x2019;s first intellectual property case. In 2015, Ms. Parker was named head of Jones Day&#x2019;s products liability practice, and in 2016, she accepted the duty to lead the 425-lawyer business and tort litigation group. Professor Seymore is a nationally recognized expert on patent law and litigation. This event is open to Vanderbilt students and faculty. Catered lunch will be provided.  ;Sponsored by the Branstetter Program and the Vanderbilt IP Association. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-10",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Law School</span></div> <div class=\"description\"><p class=\"p1\">Join WLSA on Monday, April 10th<span class=\"s1\"><sup>th</sup></span> at 12:00pm in Hyatt, as Dean Miller leads a panel of several Nashville-area female lawyers working in human trafficking.&nbsp;</p>\r\n<p class=\"p1\">The panel will consist of several prominent figures in the legal community, including:</p>\r\n<p class=\"p1\"><strong>Meera Ballal</strong>,&nbsp;Volunteer at End Slavery Tennessee</p>\r\n<p class=\"p1\"><strong>Lynne Ingram,&nbsp;</strong>Assistant United States Attorney and&nbsp;Human Trafficking Task Force Coordinator at the U.S. Attorney's Office</p>\r\n<p class=\"p1\"><strong>Tammy Meade,&nbsp;</strong>Assistant District Attorney at the District Attorney's Office and head of the DA's sex trafficking unit&nbsp;</p>\r\n<p class=\"p1\">The panelists will discuss the legal framework designed to prevent sex trafficking and protect victims, including the Trafficking Victims Protection Act,&nbsp;and other legal resources designed to address sex trafficking.&nbsp;</p>\r\n<p class=\"p1\">Boxed lunch will be provided. &nbsp;</p></div>",
        "title": "Sex Trafficking and the Law",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Law School</span></div> <div class=\"description\"><p class=\"p1\">Join WLSA on Monday, April 10th<span class=\"s1\"><sup>th</sup></span> at 12:00pm in Hyatt, as Dean Miller leads a panel of several Nashville-area female lawyers working in human trafficking.&nbsp;</p>\r\n<p class=\"p1\">The panel will consist of several prominent figures in the legal community, including:</p>\r\n<p class=\"p1\"><strong>Meera Ballal</strong>,&nbsp;Volunteer at End Slavery Tennessee</p>\r\n<p class=\"p1\"><strong>Lynne Ingram,&nbsp;</strong>Assistant United States Attorney and&nbsp;Human Trafficking Task Force Coordinator at the U.S. Attorney's Office</p>\r\n<p class=\"p1\"><strong>Tammy Meade,&nbsp;</strong>Assistant District Attorney at the District Attorney's Office and head of the DA's sex trafficking unit&nbsp;</p>\r\n<p class=\"p1\">The panelists will discuss the legal framework designed to prevent sex trafficking and protect victims, including the Trafficking Victims Protection Act,&nbsp;and other legal resources designed to address sex trafficking.&nbsp;</p>\r\n<p class=\"p1\">Boxed lunch will be provided. &nbsp;</p></div>",
        "categories": [
            "Law School",
            "International",
            "Women & Gender Issues",
            "Academic"
        ],
        "location": "Vanderbilt Law School",
        "description": "Join WLSA on Monday, April 10thth at 12:00pm in Hyatt, as Dean Miller leads a panel of several Nashville-area female lawyers working in human trafficking. ; The panel will consist of several prominent figures in the legal community, including: Meera Ballal, ;Volunteer at End Slavery Tennessee Lynne Ingram, ;Assistant United States Attorney and ;Human Trafficking Task Force Coordinator at the U.S. Attorney';s Office Tammy Meade, ;Assistant District Attorney at the District Attorney';s Office and head of the DA';s sex trafficking unit ; The panelists will discuss the legal framework designed to prevent sex trafficking and protect victims, including the Trafficking Victims Protection Act, ;and other legal resources designed to address sex trafficking. ; Boxed lunch will be provided.  ; "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-10",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "17:30:00",
        "date": "2017-04-10",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">ISSS Lobby</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend a&nbsp;<strong>Curricular Practical Training (CPT)</strong>&nbsp;workshop and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n</ul>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT workshop will now be <u>required</u> before applying for employment authorization. </strong><strong><em>Spots are limited!</em></strong></p></div>",
        "title": "CPT Workshop",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:30:00\">6:30 PM</span>)</b> <div>Location: <span class=\"location\">ISSS Lobby</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend a&nbsp;<strong>Curricular Practical Training (CPT)</strong>&nbsp;workshop and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n</ul>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT workshop will now be <u>required</u> before applying for employment authorization. </strong><strong><em>Spots are limited!</em></strong></p></div>",
        "categories": [
            "International",
            "Career Development"
        ],
        "location": "ISSS Lobby",
        "description": "F-1 Students interested to work off campus, attend a CPT workshop!!! Have you ever thought about working off campus or interning for a company in the United States? Attend a ;Curricular Practical Training (CPT) ;workshop and get the facts about how to apply for employment authorization. ---CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment. ;  Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States? These are examples of some of the information you will learn by attending one of the CPT workshops this fall. ; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States. ; CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&#x2019;s, master&#x2019;s, doctoral). ; If you have an interest to work off campus, please sign up for the Spring ;workshops. ;Attendance at a CPT workshop will now be required before applying for employment authorization. Spots are limited! "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-10",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Delta Tau Delta</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Delta Tau Delta's Faculty Speaker Series is back this semester with a new lineup of fantastic professors and employees of Vanderbilt. On a select number of Mondays at 6pm this semester, the Delta Tau Delta Chapter will host a professor for an informal conversation on topics of interest. Past speakers have talked on educational reform, the current immigration crisis, and personal finance.</p></div>",
        "title": "Spring Faculty Speaker Series 4 (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-10\">Monday, April 10, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Delta Tau Delta</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Delta Tau Delta's Faculty Speaker Series is back this semester with a new lineup of fantastic professors and employees of Vanderbilt. On a select number of Mondays at 6pm this semester, the Delta Tau Delta Chapter will host a professor for an informal conversation on topics of interest. Past speakers have talked on educational reform, the current immigration crisis, and personal finance.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Faculty Engagement"
        ],
        "location": "Delta Tau Delta",
        "description": "Cancelled  Delta Tau Delta';s Faculty Speaker Series is back this semester with a new lineup of fantastic professors and employees of Vanderbilt. On a select number of Mondays at 6pm this semester, the Delta Tau Delta Chapter will host a professor for an informal conversation on topics of interest. Past speakers have talked on educational reform, the current immigration crisis, and personal finance. "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "GME - Healthy Behaviors",
            "Greek Member Experience"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience",
            "Health & Wellness",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "17:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Get crafty at the Vanderbilt Recreation and Wellness Center on April 11<sup>th</sup> from 5-7pm. Leisurely sip on yummy mock-tails and listen to live music by a local Nashville guitarist while creating vibrant watercolor coasters.</p>\r\n<p>&nbsp;</p>\r\n<p>For questions about this and other Wellness programs, contact Jennifer Ray at <a href=\"mailto:jennifer.e.ray@vanderbilt.edu\">mailto:jennifer.e.ray@vanderbilt.edu</a>or call the Welcome Desk at 615-343-6627.</p></div>",
        "title": "Craft & Chill (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Recreation and Wellness Center</span></div> <div class=\"description\">Cancelled <br/><br/> <p>Get crafty at the Vanderbilt Recreation and Wellness Center on April 11<sup>th</sup> from 5-7pm. Leisurely sip on yummy mock-tails and listen to live music by a local Nashville guitarist while creating vibrant watercolor coasters.</p>\r\n<p>&nbsp;</p>\r\n<p>For questions about this and other Wellness programs, contact Jennifer Ray at <a href=\"mailto:jennifer.e.ray@vanderbilt.edu\">mailto:jennifer.e.ray@vanderbilt.edu</a>or call the Welcome Desk at 615-343-6627.</p></div>",
        "categories": [],
        "location": "Vanderbilt Recreation and Wellness Center",
        "description": "Cancelled  Get crafty at the Vanderbilt Recreation and Wellness Center on April 11th from 5-7pm. Leisurely sip on yummy mock-tails and listen to live music by a local Nashville guitarist while creating vibrant watercolor coasters.  ; For questions about this and other Wellness programs, contact Jennifer Ray at [mailto:jennifer.e.ray@vanderbilt.edu] (mailto:jennifer.e.ray@vanderbilt.edu) or call the Welcome Desk at 615-343-6627. "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Wyatt Center 330 - Rotunda</span></div> <div class=\"description\"><p>WIB&rsquo;s main program is the Mentorship Program, in which we pair students with businesswomen to network in an organized fashion. Businesswomen include a variety of people from around Nashville and from the Owen School of Management, ranging in industries from healthcare to retail. This program aligns with our mission to empower future female leaders by engaging a network of advocates for businesswomen&rsquo;s ambitions. By providing opportunities for students to network, we hope to assist in advancing the careers and personal development of Vanderbilt undergraduate students.</p></div>",
        "title": "Mentorship Program",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Wyatt Center 330 - Rotunda</span></div> <div class=\"description\"><p>WIB&rsquo;s main program is the Mentorship Program, in which we pair students with businesswomen to network in an organized fashion. Businesswomen include a variety of people from around Nashville and from the Owen School of Management, ranging in industries from healthcare to retail. This program aligns with our mission to empower future female leaders by engaging a network of advocates for businesswomen&rsquo;s ambitions. By providing opportunities for students to network, we hope to assist in advancing the careers and personal development of Vanderbilt undergraduate students.</p></div>",
        "categories": [
            "Diversity & Inclusion",
            "Career Development",
            "Greek Member Experience",
            "Women & Gender Issues",
            "GME - Personal Development"
        ],
        "location": "Wyatt Center 330 - Rotunda",
        "description": "WIB&#x2019;s main program is the Mentorship Program, in which we pair students with businesswomen to network in an organized fashion. Businesswomen include a variety of people from around Nashville and from the Owen School of Management, ranging in industries from healthcare to retail. This program aligns with our mission to empower future female leaders by engaging a network of advocates for businesswomen&#x2019;s ambitions. By providing opportunities for students to network, we hope to assist in advancing the careers and personal development of Vanderbilt undergraduate students. "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "title": "Vandy Wesley Weekly Dinner and Community",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "categories": [
            "Health & Wellness",
            "Religious/Spiritual"
        ],
        "location": "Div School Reading Room (through the courtyard next to Benton Chapel)",
        "description": "Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond.  ;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community.  ; All are welcome!! "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Center Classroom, Room C216</span></div> <div class=\"description\"><p>Come hear 5 Young Alumni share advice about Vanderbilt and transitioning to<br />the working world. This \"if-I-knew-then-what-I-know-now\" information can<br />only come from alumni who have done it all before. The panelists come from all walks of life and have pursued varying career paths since graduation.</p>\r\n<p>FREE DINNER FROM CHICK-FIL-A!</p></div>",
        "title": "5 Under 25: Young Alumni Panel",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:30:00\">7:30 PM</span>)</b> <div>Location: <span class=\"location\">Kissam Center Classroom, Room C216</span></div> <div class=\"description\"><p>Come hear 5 Young Alumni share advice about Vanderbilt and transitioning to<br />the working world. This \"if-I-knew-then-what-I-know-now\" information can<br />only come from alumni who have done it all before. The panelists come from all walks of life and have pursued varying career paths since graduation.</p>\r\n<p>FREE DINNER FROM CHICK-FIL-A!</p></div>",
        "categories": [
            "Career Development"
        ],
        "location": "Kissam Center Classroom, Room C216",
        "description": "Come hear 5 Young Alumni share advice about Vanderbilt and transitioning to the working world. This \";if-I-knew-then-what-I-know-now\"; information can only come from alumni who have done it all before. The panelists come from all walks of life and have pursued varying career paths since graduation. FREE DINNER FROM CHICK-FIL-A! "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">TBD</span></div> <div class=\"description\"><p>The Vanderbilt Historical Review will be giving a brief presentation on the history of the Civil War in Tennessee. We will be discussing our past trips to the Hermitage and the Carnton plantation and the historical significance of remembrance. There will also be an open discussion on interesting Civil War historical facts.</p></div>",
        "title": "Civil War History: Open Discussion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">TBD</span></div> <div class=\"description\"><p>The Vanderbilt Historical Review will be giving a brief presentation on the history of the Civil War in Tennessee. We will be discussing our past trips to the Hermitage and the Carnton plantation and the historical significance of remembrance. There will also be an open discussion on interesting Civil War historical facts.</p></div>",
        "categories": [
            "Academic",
            "Greek Member Experience",
            "GME - Diversity & Inclusion"
        ],
        "location": "TBD",
        "description": "The Vanderbilt Historical Review will be giving a brief presentation on the history of the Civil War in Tennessee. We will be discussing our past trips to the Hermitage and the Carnton plantation and the historical significance of remembrance. There will also be an open discussion on interesting Civil War historical facts. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-11",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Come hear the the Vanderbilt Variations sing at their Spring Concert!</p></div>",
        "title": "Variations Spring Concert",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-11\">Tuesday, April 11, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Come hear the the Vanderbilt Variations sing at their Spring Concert!</p></div>",
        "categories": [],
        "location": "Sarratt Cinema",
        "description": "Come hear the the Vanderbilt Variations sing at their Spring Concert! "
    },
    {
        "time": "09:15:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 325/327</span></div> <div class=\"description\"><p>We live in a country where people of differing religious traditions are interacting more than ever before. This could potentially create barriers between people or allow for strengthened cooperation.</p>\r\n<p>Come hear from a panel of undergraduate and graduate students who spent their spring break in Washington DC meeting with different religious leaders and attending a variety of different religious traditions&rsquo; worship services. Listen to stories about how interfaith work is positively improving the political climate and helping shift religious discourse and walk away with practical ways you can use interfaith work on Vanderbilt&rsquo;s campus.</p>\r\n<p>Presentation by&nbsp;Brea Rodriguez-Harris, Byron Tyler Coles, and Rev. Dr. Mark Forrester, ISSS and OUCRL</p>\r\n<p>*Language regarding interfaith work used above is borrowed from the Interfaith Youth Corps website</p></div>",
        "title": "World on Wednesdays: Religious Pluralism in the United States Capital",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 325/327</span></div> <div class=\"description\"><p>We live in a country where people of differing religious traditions are interacting more than ever before. This could potentially create barriers between people or allow for strengthened cooperation.</p>\r\n<p>Come hear from a panel of undergraduate and graduate students who spent their spring break in Washington DC meeting with different religious leaders and attending a variety of different religious traditions&rsquo; worship services. Listen to stories about how interfaith work is positively improving the political climate and helping shift religious discourse and walk away with practical ways you can use interfaith work on Vanderbilt&rsquo;s campus.</p>\r\n<p>Presentation by&nbsp;Brea Rodriguez-Harris, Byron Tyler Coles, and Rev. Dr. Mark Forrester, ISSS and OUCRL</p>\r\n<p>*Language regarding interfaith work used above is borrowed from the Interfaith Youth Corps website</p></div>",
        "categories": [
            "International",
            "Religious/Spiritual"
        ],
        "location": "Sarratt 325/327",
        "description": "We live in a country where people of differing religious traditions are interacting more than ever before. This could potentially create barriers between people or allow for strengthened cooperation. Come hear from a panel of undergraduate and graduate students who spent their spring break in Washington DC meeting with different religious leaders and attending a variety of different religious traditions&#x2019; worship services. Listen to stories about how interfaith work is positively improving the political climate and helping shift religious discourse and walk away with practical ways you can use interfaith work on Vanderbilt&#x2019;s campus. Presentation by ;Brea Rodriguez-Harris, Byron Tyler Coles, and Rev. Dr. Mark Forrester, ISSS and OUCRL *Language regarding interfaith work used above is borrowed from the Interfaith Youth Corps website "
    },
    {
        "time": "15:30:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us at the Center for Student Wellbeing as Dean Beasley,&nbsp;Dean of the Commons,&nbsp;leads a 30 minute guided meditation session.&nbsp; The goal of this practice&nbsp;is to&nbsp;reduce stress and develop resiliency strategies.&nbsp;&nbsp;&nbsp;</p></div>",
        "title": "Guided Meditation with Dean Beasley",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:30:00\">3:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us at the Center for Student Wellbeing as Dean Beasley,&nbsp;Dean of the Commons,&nbsp;leads a 30 minute guided meditation session.&nbsp; The goal of this practice&nbsp;is to&nbsp;reduce stress and develop resiliency strategies.&nbsp;&nbsp;&nbsp;</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us at the Center for Student Wellbeing as Dean Beasley, ;Dean of the Commons, ;leads a 30 minute guided meditation session. ; The goal of this practice ;is to ;reduce stress and develop resiliency strategies. ; ; ; "
    },
    {
        "time": "16:30:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:30:00\">4:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">2144 Fairfax Ave, Nashville, TN 37212</span></div> <div class=\"description\"><p>The Nashville Ronald McDonald House provides an affordable &ldquo;home away from home&rdquo; and other resources for families and their children in need. We will be preparing dinner for the residents and eating with them.</p>\r\n<p>&nbsp;</p>\r\n<p>This is part of our ongoing recruitment series. Please email clara.chu@vanderbilt.edu if you are interested in attending this event.</p></div>",
        "title": "Ronald McDonald House Dinner [National]",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:30:00\">4:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">2144 Fairfax Ave, Nashville, TN 37212</span></div> <div class=\"description\"><p>The Nashville Ronald McDonald House provides an affordable &ldquo;home away from home&rdquo; and other resources for families and their children in need. We will be preparing dinner for the residents and eating with them.</p>\r\n<p>&nbsp;</p>\r\n<p>This is part of our ongoing recruitment series. Please email clara.chu@vanderbilt.edu if you are interested in attending this event.</p></div>",
        "categories": [
            "Service & Philanthropy"
        ],
        "location": "2144 Fairfax Ave, Nashville, TN 37212",
        "description": "The Nashville Ronald McDonald House provides an affordable &#x201C;home away from home&#x201D; and other resources for families and their children in need. We will be preparing dinner for the residents and eating with them.  ; This is part of our ongoing recruitment series. Please email clara.chu@vanderbilt.edu if you are interested in attending this event. "
    },
    {
        "time": "17:00:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall TBA</span></div> <div class=\"description\"><p>Recent years have seen an explosion in imaging and interventional capabilities&nbsp;for diagnosis and treatment of patients with acute ischemic stroke. But who is a candidate for endovascular therapy? What patients benefit and what outcomes can physicians and patient families expect?</p>\r\n<p>Join us to discuss the salient studies on endovascular stroke intervention. This session will be of particular interest to students interested in interventional radiology, neurology, or neurosurgery, but all students, house staff, and faculty are welcome to attend.</p>\r\n<p>Dr. Michael Froehler, Assistant Professor of Neurology and Neurosurgery and Director of the Cerebrovascular Program at VUMC, will moderate the discussion.</p>\r\n<p>Note that date may change.</p></div>",
        "title": "IR Interest Group: Stroke Intervention Journal Club",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:00:00\">5:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">Light Hall TBA</span></div> <div class=\"description\"><p>Recent years have seen an explosion in imaging and interventional capabilities&nbsp;for diagnosis and treatment of patients with acute ischemic stroke. But who is a candidate for endovascular therapy? What patients benefit and what outcomes can physicians and patient families expect?</p>\r\n<p>Join us to discuss the salient studies on endovascular stroke intervention. This session will be of particular interest to students interested in interventional radiology, neurology, or neurosurgery, but all students, house staff, and faculty are welcome to attend.</p>\r\n<p>Dr. Michael Froehler, Assistant Professor of Neurology and Neurosurgery and Director of the Cerebrovascular Program at VUMC, will moderate the discussion.</p>\r\n<p>Note that date may change.</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Light Hall TBA",
        "description": "Recent years have seen an explosion in imaging and interventional capabilities ;for diagnosis and treatment of patients with acute ischemic stroke. But who is a candidate for endovascular therapy? What patients benefit and what outcomes can physicians and patient families expect? Join us to discuss the salient studies on endovascular stroke intervention. This session will be of particular interest to students interested in interventional radiology, neurology, or neurosurgery, but all students, house staff, and faculty are welcome to attend. Dr. Michael Froehler, Assistant Professor of Neurology and Neurosurgery and Director of the Cerebrovascular Program at VUMC, will moderate the discussion. Note that date may change. "
    },
    {
        "time": "17:30:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Location will be sent in a confirmation email</span></div> <div class=\"description\"><p>Learn how to put your best fork forward in Life After Vanderbilt, wowing fellow diners at every interview or business meeting. Join other almost-alumni in receiving etiquette pointer while guided through a multi-course meal at a nearby fine dining restaurant. Special guest Perry Brandt(BA'74, JD'77) will offer insight that will help you conquer and prevail in all social and business settings!</p>\r\n<p>Senior Etiquette Dinner</p>\r\n<p>Wednesday, April 12</p>\r\n<p>5:30-7pm</p>\r\n<p>&nbsp;</p>\r\n<p>Exact location will be specified in confirmation emails.&nbsp;</p>\r\n<p>Business attire expected.</p>\r\n<p>Valet and validated garage parking available.</p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-size: 8.5pt; font-family: 'Verdana','sans-serif'; color: black;\">Seating is extremely limited, so complete <a href=\"https://docs.google.com/forms/d/e/1FAIpQLSeZXtZ0ILGBtBy-n_1DFYD9kFXeiXqNRYjy-meTNd_VktC2Yg/viewform\">this form&nbsp;</a>NOW to RSVP. (You must receive a confirmation email for admittance. All students who RSVP will recieve notice of their registration or waiting list status.)</span></p>\r\n<p>&nbsp;</p>\r\n<p>This event is part of the \"Life After Vanderbilt\" Series and&nbsp;sponsored by your Vanderbilt Alumni Association.</p></div>",
        "title": "Life After Vanderbilt- Senior Etiquette Dinner",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Location will be sent in a confirmation email</span></div> <div class=\"description\"><p>Learn how to put your best fork forward in Life After Vanderbilt, wowing fellow diners at every interview or business meeting. Join other almost-alumni in receiving etiquette pointer while guided through a multi-course meal at a nearby fine dining restaurant. Special guest Perry Brandt(BA'74, JD'77) will offer insight that will help you conquer and prevail in all social and business settings!</p>\r\n<p>Senior Etiquette Dinner</p>\r\n<p>Wednesday, April 12</p>\r\n<p>5:30-7pm</p>\r\n<p>&nbsp;</p>\r\n<p>Exact location will be specified in confirmation emails.&nbsp;</p>\r\n<p>Business attire expected.</p>\r\n<p>Valet and validated garage parking available.</p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-size: 8.5pt; font-family: 'Verdana','sans-serif'; color: black;\">Seating is extremely limited, so complete <a href=\"https://docs.google.com/forms/d/e/1FAIpQLSeZXtZ0ILGBtBy-n_1DFYD9kFXeiXqNRYjy-meTNd_VktC2Yg/viewform\">this form&nbsp;</a>NOW to RSVP. (You must receive a confirmation email for admittance. All students who RSVP will recieve notice of their registration or waiting list status.)</span></p>\r\n<p>&nbsp;</p>\r\n<p>This event is part of the \"Life After Vanderbilt\" Series and&nbsp;sponsored by your Vanderbilt Alumni Association.</p></div>",
        "categories": [
            "Career Development"
        ],
        "location": "Location will be sent in a confirmation email",
        "description": "Learn how to put your best fork forward in Life After Vanderbilt, wowing fellow diners at every interview or business meeting. Join other almost-alumni in receiving etiquette pointer while guided through a multi-course meal at a nearby fine dining restaurant. Special guest Perry Brandt(BA';74, JD';77) will offer insight that will help you conquer and prevail in all social and business settings! Senior Etiquette Dinner Wednesday, April 12 5:30-7pm  ; Exact location will be specified in confirmation emails. ; Business attire expected. Valet and validated garage parking available.  ; Seating is extremely limited, so complete [this form ;] (https://docs.google.com/forms/d/e/1FAIpQLSeZXtZ0ILGBtBy-n_1DFYD9kFXeiXqNRYjy-meTNd_VktC2Yg/viewform) NOW to RSVP. (You must receive a confirmation email for admittance. All students who RSVP will recieve notice of their registration or waiting list status.)  ; This event is part of the \";Life After Vanderbilt\"; Series and ;sponsored by your Vanderbilt Alumni Association. "
    },
    {
        "time": "17:30:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Buttrick Hall 102</span></div> <div class=\"description\"><p>Many Peabody students don't understand how the career center can help them if you're not going into consulting or business. Come learn about the multitude of resources that the Career Center has for you as a peabody student. We will cover summer internships, getting a job after graduation, and just generally figuring out what you may want to do if you're not sure yet. There will be FREE LinkedIn headshots taken at the beginning of the event</p></div>",
        "title": "Peabody College and the Career Center",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"17:30:00\">5:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Buttrick Hall 102</span></div> <div class=\"description\"><p>Many Peabody students don't understand how the career center can help them if you're not going into consulting or business. Come learn about the multitude of resources that the Career Center has for you as a peabody student. We will cover summer internships, getting a job after graduation, and just generally figuring out what you may want to do if you're not sure yet. There will be FREE LinkedIn headshots taken at the beginning of the event</p></div>",
        "categories": [
            "Career Development"
        ],
        "location": "Buttrick Hall 102",
        "description": "Many Peabody students don';t understand how the career center can help them if you';re not going into consulting or business. Come learn about the multitude of resources that the Career Center has for you as a peabody student. We will cover summer internships, getting a job after graduation, and just generally figuring out what you may want to do if you';re not sure yet. There will be FREE LinkedIn headshots taken at the beginning of the event "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Sarratt</span></div> <div class=\"description\">Cancelled <br/><br/> <p><span style=\"font-weight: 400;\">The Women to Watch Lecture Series provides an opportunity to all members of WIB and all members of the Vanderbilt community and invited guests to learn about the different sectors of the business world and improve various business-related skills. These lecture series are for purely educational purposes and will be hosted by Owen Women or businesswomen from Nashville and the surrounding areas. </span></p></div>",
        "title": "Woman to Watch (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Vanderbilt Sarratt</span></div> <div class=\"description\">Cancelled <br/><br/> <p><span style=\"font-weight: 400;\">The Women to Watch Lecture Series provides an opportunity to all members of WIB and all members of the Vanderbilt community and invited guests to learn about the different sectors of the business world and improve various business-related skills. These lecture series are for purely educational purposes and will be hosted by Owen Women or businesswomen from Nashville and the surrounding areas. </span></p></div>",
        "categories": [
            "Career Development",
            "Women & Gender Issues"
        ],
        "location": "Vanderbilt Sarratt",
        "description": "Cancelled  The Women to Watch Lecture Series provides an opportunity to all members of WIB and all members of the Vanderbilt community and invited guests to learn about the different sectors of the business world and improve various business-related skills. These lecture series are for purely educational purposes and will be hosted by Owen Women or businesswomen from Nashville and the surrounding areas.  "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 216/220</span></div> <div class=\"description\"><div class=\"container\">\r\n<div id=\"seccontent\">\r\n<div class=\"secmain\">\r\n<p>Join the Vanderbilt Interfaith Council in a discussion about the fate of religion in today&rsquo;s national and global contexts. Our panelists will be religious leaders and scholars representing many of the world&rsquo;s largest religions.</p>\r\n</div>\r\n</div>\r\n</div>\r\n<p>&nbsp;</p></div>",
        "title": "Interfaith Panel Discussion",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt 216/220</span></div> <div class=\"description\"><div class=\"container\">\r\n<div id=\"seccontent\">\r\n<div class=\"secmain\">\r\n<p>Join the Vanderbilt Interfaith Council in a discussion about the fate of religion in today&rsquo;s national and global contexts. Our panelists will be religious leaders and scholars representing many of the world&rsquo;s largest religions.</p>\r\n</div>\r\n</div>\r\n</div>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Religious/Spiritual",
            "Greek Member Experience",
            "GME - Diversity & Inclusion"
        ],
        "location": "Sarratt 216/220",
        "description": "Join the Vanderbilt Interfaith Council in a discussion about the fate of religion in today&#x2019;s national and global contexts. Our panelists will be religious leaders and scholars representing many of the world&#x2019;s largest religions.  ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Commons Center 233</span></div> <div class=\"description\"><div class=\"x_section\">\r\n<div class=\"x_section x_clearfix\">\r\n<p>At this required Alternate VUceptor Orientation, individuals who were offered a position on the alternates list will be given more information about their&nbsp;roles, training, and the process of becoming a VUceptor. &nbsp;This orientation is not optional. &nbsp;It will likely not last the full amount of time listed.</p>\r\n</div>\r\n</div></div>",
        "title": "Alternate VUceptor Orientation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Commons Center 233</span></div> <div class=\"description\"><div class=\"x_section\">\r\n<div class=\"x_section x_clearfix\">\r\n<p>At this required Alternate VUceptor Orientation, individuals who were offered a position on the alternates list will be given more information about their&nbsp;roles, training, and the process of becoming a VUceptor. &nbsp;This orientation is not optional. &nbsp;It will likely not last the full amount of time listed.</p>\r\n</div>\r\n</div></div>",
        "categories": [],
        "location": "Commons Center 233",
        "description": "At this required Alternate VUceptor Orientation, individuals who were offered a position on the alternates list will be given more information about their ;roles, training, and the process of becoming a VUceptor.  ;This orientation is not optional.  ;It will likely not last the full amount of time listed. "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Room 309 Buttrick Hall</span></div> <div class=\"description\"><p><strong>Come practice public speaking in a safe and fun environment!</strong> The MC of the meeting, the toastmaster, leads us through the evening&rsquo;s events while educating and entertaining everyone with facts/stories that coincide with a theme that he/she has chosen. Themes can range from Waffle House to zoning issues and everywhere in-between. The first half of the meeting consists of prepared speeches followed by an impromptu speaking section where everyone has the opportunity to participate. The second half of the meeting is run by the general evaluator and the evaluation team. The evaluation team gives positive criticism and encouragement to both individuals and the group as a whole. They provide us with specific advice, so we can actively improve our public speaking skills. Meetings are on the 2nd and 4th Wednesday of each month at 6pm in the 3rd floor of Buttrick hall. All in the Vanderbilt community and greater Nashville community are welcome to join!</p></div>",
        "title": "Vanderbilt Toastmasters General Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Room 309 Buttrick Hall</span></div> <div class=\"description\"><p><strong>Come practice public speaking in a safe and fun environment!</strong> The MC of the meeting, the toastmaster, leads us through the evening&rsquo;s events while educating and entertaining everyone with facts/stories that coincide with a theme that he/she has chosen. Themes can range from Waffle House to zoning issues and everywhere in-between. The first half of the meeting consists of prepared speeches followed by an impromptu speaking section where everyone has the opportunity to participate. The second half of the meeting is run by the general evaluator and the evaluation team. The evaluation team gives positive criticism and encouragement to both individuals and the group as a whole. They provide us with specific advice, so we can actively improve our public speaking skills. Meetings are on the 2nd and 4th Wednesday of each month at 6pm in the 3rd floor of Buttrick hall. All in the Vanderbilt community and greater Nashville community are welcome to join!</p></div>",
        "categories": [],
        "location": "Room 309 Buttrick Hall",
        "description": "Come practice public speaking in a safe and fun environment! The MC of the meeting, the toastmaster, leads us through the evening&#x2019;s events while educating and entertaining everyone with facts/stories that coincide with a theme that he/she has chosen. Themes can range from Waffle House to zoning issues and everywhere in-between. The first half of the meeting consists of prepared speeches followed by an impromptu speaking section where everyone has the opportunity to participate. The second half of the meeting is run by the general evaluator and the evaluation team. The evaluation team gives positive criticism and encouragement to both individuals and the group as a whole. They provide us with specific advice, so we can actively improve our public speaking skills. Meetings are on the 2nd and 4th Wednesday of each month at 6pm in the 3rd floor of Buttrick hall. All in the Vanderbilt community and greater Nashville community are welcome to join! "
    },
    {
        "time": "19:30:00",
        "date": "2017-04-12",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p><em>Presented by: Avery Dickins de Gir&oacute;n, Executive Director of the Center for Latin American Studies</em></p>\r\n<p><strong>USA&nbsp;(2015) </strong>Dir: Jayro Bustamente.&nbsp;</p>\r\n<p class=\"p1\"><span class=\"s1\">Ixcanul (which translates to &lsquo;volcano&rsquo; in Kaqchikel Mayan) is the coming-of-age story of Maria, a 17-year-old Mayan girl reluctant to embark on an arranged marriage with the coffee plantation foreman. The film illustrates the larger social issues confronting Guatemala&rsquo;s indigenous people caught between rural and contemporary urban lifeways. &nbsp;This brilliant directorial debut captures the contrast between the characters&rsquo; rich customs and history and the exploitation they face.&nbsp; The film was Guatemala&rsquo;s first-ever entry into the Best Foreign Language Film Oscar (2015).&nbsp; Kaqchikel with English subtitles. 100 Minutes. <em>Presented in Collaboration with the Center for Latin American Studies.</em></span></p></div>",
        "title": "iLens: Ixcanul",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-12\">Wednesday, April 12, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:30:00\">9:30 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p><em>Presented by: Avery Dickins de Gir&oacute;n, Executive Director of the Center for Latin American Studies</em></p>\r\n<p><strong>USA&nbsp;(2015) </strong>Dir: Jayro Bustamente.&nbsp;</p>\r\n<p class=\"p1\"><span class=\"s1\">Ixcanul (which translates to &lsquo;volcano&rsquo; in Kaqchikel Mayan) is the coming-of-age story of Maria, a 17-year-old Mayan girl reluctant to embark on an arranged marriage with the coffee plantation foreman. The film illustrates the larger social issues confronting Guatemala&rsquo;s indigenous people caught between rural and contemporary urban lifeways. &nbsp;This brilliant directorial debut captures the contrast between the characters&rsquo; rich customs and history and the exploitation they face.&nbsp; The film was Guatemala&rsquo;s first-ever entry into the Best Foreign Language Film Oscar (2015).&nbsp; Kaqchikel with English subtitles. 100 Minutes. <em>Presented in Collaboration with the Center for Latin American Studies.</em></span></p></div>",
        "categories": [
            "International",
            "Religious/Spiritual",
            "Film/Movie",
            "Visual Arts"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented by: Avery Dickins de Gir&#xF3;n, Executive Director of the Center for Latin American Studies USA ;(2015) Dir: Jayro Bustamente. ; Ixcanul (which translates to &#x2018;volcano&#x2019; in Kaqchikel Mayan) is the coming-of-age story of Maria, a 17-year-old Mayan girl reluctant to embark on an arranged marriage with the coffee plantation foreman. The film illustrates the larger social issues confronting Guatemala&#x2019;s indigenous people caught between rural and contemporary urban lifeways.  ;This brilliant directorial debut captures the contrast between the characters&#x2019; rich customs and history and the exploitation they face. ; The film was Guatemala&#x2019;s first-ever entry into the Best Foreign Language Film Oscar (2015). ; Kaqchikel with English subtitles. 100 Minutes. Presented in Collaboration with the Center for Latin American Studies. "
    },
    {
        "time": "09:00:00",
        "date": "2017-04-13",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:00:00\">10:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "Health & Wellness",
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-13",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p><span style=\"font-size: 13px;\">While our academic skills support services are very helpful to students who are experiencing academic difficulties, they are also beneficial to anyone who wishes to become a more efficient learner. </span></p></div>",
        "title": "Academic Skills & Time Management",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p><span style=\"font-size: 13px;\">While our academic skills support services are very helpful to students who are experiencing academic difficulties, they are also beneficial to anyone who wishes to become a more efficient learner. </span></p></div>",
        "categories": [
            "GME - Healthy Behaviors",
            "Greek Member Experience"
        ],
        "location": "Center for Student Wellbeing",
        "description": "While our academic skills support services are very helpful to students who are experiencing academic difficulties, they are also beneficial to anyone who wishes to become a more efficient learner.  "
    },
    {
        "time": "15:15:00",
        "date": "2017-04-13",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:15:00\">3:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:45:00\">3:45 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-13",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>\"What good is sitting alone in your room? &nbsp;Come hear the music play...\" &nbsp;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation. &nbsp;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike. &nbsp;\"It's only a cabaret, old chum, and I love a cabaret.\"&nbsp;Directed by Christin Essin,&nbsp;Assistant Professor of Theatre.</p>\r\n<p>Performed&nbsp;April 13, 14, 15 at&nbsp;8pm.</p></div>",
        "title": "Cabaret Vanderbilt: Gender Play",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>\"What good is sitting alone in your room? &nbsp;Come hear the music play...\" &nbsp;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation. &nbsp;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike. &nbsp;\"It's only a cabaret, old chum, and I love a cabaret.\"&nbsp;Directed by Christin Essin,&nbsp;Assistant Professor of Theatre.</p>\r\n<p>Performed&nbsp;April 13, 14, 15 at&nbsp;8pm.</p></div>",
        "categories": [
            "GME - Diversity & Inclusion",
            "Greek Member Experience",
            "Performing Arts"
        ],
        "location": "Neely Auditorium",
        "description": "\";What good is sitting alone in your room?  ;Come hear the music play...\";  ;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation.  ;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike.  ;\";It';s only a cabaret, old chum, and I love a cabaret.\"; ;Directed by Christin Essin, ;Assistant Professor of Theatre. Performed ;April 13, 14, 15 at ;8pm. "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-13",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt</span></div> <div class=\"description\"><p>Variations will perform at VPAC's Encore Event</p></div>",
        "title": "Variations at VPAC Encore",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-13\">Thursday, April 13, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt</span></div> <div class=\"description\"><p>Variations will perform at VPAC's Encore Event</p></div>",
        "categories": [],
        "location": "Sarratt",
        "description": "Variations will perform at VPAC';s Encore Event "
    },
    {
        "time": "09:30:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:30:00\">9:30 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Stapleton Lounge</span></div> <div class=\"description\"><p>Monday morning coffee in the Stapleton lobby to&nbsp;start the week off with a caffeine boost</p></div>",
        "title": "Stape Coffee",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:30:00\">9:30 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Stapleton Lounge</span></div> <div class=\"description\"><p>Monday morning coffee in the Stapleton lobby to&nbsp;start the week off with a caffeine boost</p></div>",
        "categories": [],
        "location": "Stapleton Lounge",
        "description": "Monday morning coffee in the Stapleton lobby to ;start the week off with a caffeine boost "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Graduate/Professional Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Ray Room - Vanderbilt Law School</span></div> <div class=\"description\"><p>The Tennessee Association of Criminal Defense Lawyers (TACDL) is one of the nation&rsquo;s oldest state criminal bar associations. Since 1973, TACDL&nbsp;members have worked tirelessly to support the work of the criminal defense bar, educate lawyers and act as a voice for the bar and the citizen accused in the judicial, legislative and executive branches of government. TACDL&nbsp;provides members with the services they need to serve the citizens of this state and all those found within her borders who find themselves charged with a crime.</p>\r\n<p>TACDL members will be at Vanderbilt Law School on Friday, April 14th, at 12:00 PM to discuss how students can join the organization, what benefits will be available to students, and bar exam preparation opportunities. Lunch will be served!</p></div>",
        "title": "Tennessee Association of Criminal Defense Lawyers Information Session",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Ray Room - Vanderbilt Law School</span></div> <div class=\"description\"><p>The Tennessee Association of Criminal Defense Lawyers (TACDL) is one of the nation&rsquo;s oldest state criminal bar associations. Since 1973, TACDL&nbsp;members have worked tirelessly to support the work of the criminal defense bar, educate lawyers and act as a voice for the bar and the citizen accused in the judicial, legislative and executive branches of government. TACDL&nbsp;provides members with the services they need to serve the citizens of this state and all those found within her borders who find themselves charged with a crime.</p>\r\n<p>TACDL members will be at Vanderbilt Law School on Friday, April 14th, at 12:00 PM to discuss how students can join the organization, what benefits will be available to students, and bar exam preparation opportunities. Lunch will be served!</p></div>",
        "categories": [
            "Law School"
        ],
        "location": "Ray Room - Vanderbilt Law School",
        "description": "The Tennessee Association of Criminal Defense Lawyers (TACDL) is one of the nation&#x2019;s oldest state criminal bar associations. Since 1973, TACDL ;members have worked tirelessly to support the work of the criminal defense bar, educate lawyers and act as a voice for the bar and the citizen accused in the judicial, legislative and executive branches of government. TACDL ;provides members with the services they need to serve the citizens of this state and all those found within her borders who find themselves charged with a crime. TACDL members will be at Vanderbilt Law School on Friday, April 14th, at 12:00 PM to discuss how students can join the organization, what benefits will be available to students, and bar exam preparation opportunities. Lunch will be served! "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen Graduate School of Management</span></div> <div class=\"description\"><p>Meet our new board!</p></div>",
        "title": "Lunch & Learn",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Owen Graduate School of Management</span></div> <div class=\"description\"><p>Meet our new board!</p></div>",
        "categories": [],
        "location": "Owen Graduate School of Management",
        "description": "Meet our new board! "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Delta Tau Delta</span></div> <div class=\"description\"><p>Delta Tau Delta's annual spring philanthropy benefitting JDRF. Intended Learning Outcomes include civic engagement, philanthropic giving, and educational information on JDRF and the work they do.</p></div>",
        "title": "Spring Philanthropy Event",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Delta Tau Delta</span></div> <div class=\"description\"><p>Delta Tau Delta's annual spring philanthropy benefitting JDRF. Intended Learning Outcomes include civic engagement, philanthropic giving, and educational information on JDRF and the work they do.</p></div>",
        "categories": [],
        "location": "Delta Tau Delta",
        "description": "Delta Tau Delta';s annual spring philanthropy benefitting JDRF. Intended Learning Outcomes include civic engagement, philanthropic giving, and educational information on JDRF and the work they do. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>Good Friday service on April 14 at 12:10 PM in Benton Chapel</p></div>",
        "title": "Ecumenical Good Friday Service",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"12:30:00\">12:30 PM</span>)</b> <div>Location: <span class=\"location\">Benton Chapel</span></div> <div class=\"description\"><p>Good Friday service on April 14 at 12:10 PM in Benton Chapel</p></div>",
        "categories": [
            "Religious/Spiritual"
        ],
        "location": "Benton Chapel",
        "description": "Good Friday service on April 14 at 12:10 PM in Benton Chapel "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Memorial Gym Studio C</span></div> <div class=\"description\"><p>VUPointe Ballet Theatre presents our production of <em>Swan Lake&nbsp;</em>as well as original student works and featured guest artists.&nbsp;Reception to follow.&nbsp;</p></div>",
        "title": "VUPointe Ballet's Spring Performance",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Memorial Gym Studio C</span></div> <div class=\"description\"><p>VUPointe Ballet Theatre presents our production of <em>Swan Lake&nbsp;</em>as well as original student works and featured guest artists.&nbsp;Reception to follow.&nbsp;</p></div>",
        "categories": [
            "Performing Arts",
            "Greek Member Experience",
            "GME - Campus Involvement"
        ],
        "location": "Memorial Gym Studio C",
        "description": "VUPointe Ballet Theatre presents our production of Swan Lake ;as well as original student works and featured guest artists. ;Reception to follow. ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>\"What good is sitting alone in your room? &nbsp;Come hear the music play...\" &nbsp;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation. &nbsp;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike. &nbsp;\"It's only a cabaret, old chum, and I love a cabaret.\"&nbsp;Directed by Christin Essin,&nbsp;Assistant Professor of Theatre.</p>\r\n<p>Performed&nbsp;April 13, 14, 15 at&nbsp;8pm.</p></div>",
        "title": "Cabaret Vanderbilt: Gender Play",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>\"What good is sitting alone in your room? &nbsp;Come hear the music play...\" &nbsp;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation. &nbsp;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike. &nbsp;\"It's only a cabaret, old chum, and I love a cabaret.\"&nbsp;Directed by Christin Essin,&nbsp;Assistant Professor of Theatre.</p>\r\n<p>Performed&nbsp;April 13, 14, 15 at&nbsp;8pm.</p></div>",
        "categories": [
            "Performing Arts",
            "Greek Member Experience",
            "GME - Diversity & Inclusion"
        ],
        "location": "Neely Auditorium",
        "description": "\";What good is sitting alone in your room?  ;Come hear the music play...\";  ;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation.  ;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike.  ;\";It';s only a cabaret, old chum, and I love a cabaret.\"; ;Directed by Christin Essin, ;Assistant Professor of Theatre. Performed ;April 13, 14, 15 at ;8pm. "
    },
    {
        "time": "21:00:00",
        "date": "2017-04-14",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"21:00:00\">9:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\">Cancelled <br/><br/> <p>VUPointe presents <em>Swan Lake </em>as well as original student works,&nbsp;featuring guest artists, Vanderbilt Dance Theatre, and live music performed by Blaire students. Reception to follow.&nbsp;</p></div>",
        "title": "VUPointe's Spring Performance (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-14\">Friday, April 14, 2017</span> (<span\tclass=\"value\"\ttitle=\"21:00:00\">9:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\">Cancelled <br/><br/> <p>VUPointe presents <em>Swan Lake </em>as well as original student works,&nbsp;featuring guest artists, Vanderbilt Dance Theatre, and live music performed by Blaire students. Reception to follow.&nbsp;</p></div>",
        "categories": [
            "MVE - Arts Track",
            "My Vanderbilt Experience",
            "Performing Arts"
        ],
        "location": "Sarratt Cinema",
        "description": "Cancelled  VUPointe presents Swan Lake as well as original student works, ;featuring guest artists, Vanderbilt Dance Theatre, and live music performed by Blaire students. Reception to follow. ; "
    },
    {
        "time": "12:15:00",
        "date": "2017-04-15",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:15:00\">12:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:30:00\">2:30 PM</span>)</b> <div>Location: <span class=\"location\">Hawkins Field </span></div> <div class=\"description\"><p>Come out to Hawkins Field to watch some SEC baseball as Vanderbilt takes on Florida at home!&nbsp;</p></div>",
        "title": "Vanderbilt Baseball vs. Florida",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:15:00\">12:15 PM</span></span> - <span class=\"dtend\"\ttitle=\"14:30:00\">2:30 PM</span>)</b> <div>Location: <span class=\"location\">Hawkins Field </span></div> <div class=\"description\"><p>Come out to Hawkins Field to watch some SEC baseball as Vanderbilt takes on Florida at home!&nbsp;</p></div>",
        "categories": [
            "GME - Campus Involvement",
            "Greek Member Experience"
        ],
        "location": "Hawkins Field ",
        "description": "Come out to Hawkins Field to watch some SEC baseball as Vanderbilt takes on Florida at home! ; "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-15",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Ingram Hall</span></div> <div class=\"description\"><div class=\"page\" title=\"Page 10\">\r\n<div class=\"section\">\r\n<div class=\"layoutArea\">\r\n<div class=\"column\">\r\n<p>Enjoy an evening with the Vanderbilt Commodore Orchestra! The VCO brings together undergraduate and graduate students from all of the schools of Vanderbilt, as well as members of the Nashville community who are united in their love of making great music. Led by professor Jeremy Wilson, the concert will include exciting and exhilarating pieces!</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div></div>",
        "title": "Vanderbilt Commodore Orchestra Spring 2017 Concert",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Ingram Hall</span></div> <div class=\"description\"><div class=\"page\" title=\"Page 10\">\r\n<div class=\"section\">\r\n<div class=\"layoutArea\">\r\n<div class=\"column\">\r\n<p>Enjoy an evening with the Vanderbilt Commodore Orchestra! The VCO brings together undergraduate and graduate students from all of the schools of Vanderbilt, as well as members of the Nashville community who are united in their love of making great music. Led by professor Jeremy Wilson, the concert will include exciting and exhilarating pieces!</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Campus Involvement"
        ],
        "location": "Ingram Hall",
        "description": "Enjoy an evening with the Vanderbilt Commodore Orchestra! The VCO brings together undergraduate and graduate students from all of the schools of Vanderbilt, as well as members of the Nashville community who are united in their love of making great music. Led by professor Jeremy Wilson, the concert will include exciting and exhilarating pieces! "
    },
    {
        "time": "19:30:00",
        "date": "2017-04-15",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:45:00\">9:45 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented Tara McKay, Assistant Professor of Medicine, Health, &amp; Society, and Assistant Professor of Health Policy.</p>\r\n<p><strong>UK (2016) </strong>Dir. Ken Loach. Winner of the Palme d&rsquo;Or at the 2016 Cannes Film Festival, the film is a gripping, human tale about the impact one man can make. Gruff but goodhearted, Daniel Blake (Dave Johns) is a man out of time: a widowed woodworker who&rsquo;s never owned a computer, he lives according to his own common sense moral code. But after a heart attack leaves him unable to work and the state welfare system fails him, the stubbornly self-reliant Daniel must stand up and fight for his dignity, leading a one-man crusade for compassion that will transform the lives of a struggling single mother (Hayley Squires) and her two children. Graced with humor and heart,&nbsp;<em>I, Daniel Blake&nbsp;</em>is a moving, much-needed reminder of the power of empathy. English. Rated R. 100 min. Blu-ray</p></div>",
        "title": "iLens: I, Daniel Blake",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:45:00\">9:45 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Presented Tara McKay, Assistant Professor of Medicine, Health, &amp; Society, and Assistant Professor of Health Policy.</p>\r\n<p><strong>UK (2016) </strong>Dir. Ken Loach. Winner of the Palme d&rsquo;Or at the 2016 Cannes Film Festival, the film is a gripping, human tale about the impact one man can make. Gruff but goodhearted, Daniel Blake (Dave Johns) is a man out of time: a widowed woodworker who&rsquo;s never owned a computer, he lives according to his own common sense moral code. But after a heart attack leaves him unable to work and the state welfare system fails him, the stubbornly self-reliant Daniel must stand up and fight for his dignity, leading a one-man crusade for compassion that will transform the lives of a struggling single mother (Hayley Squires) and her two children. Graced with humor and heart,&nbsp;<em>I, Daniel Blake&nbsp;</em>is a moving, much-needed reminder of the power of empathy. English. Rated R. 100 min. Blu-ray</p></div>",
        "categories": [
            "International",
            "Diversity & Inclusion",
            "Political",
            "Health & Wellness",
            "Graduate/Professional Students",
            "Visual Arts",
            "Film/Movie"
        ],
        "location": "Sarratt Cinema",
        "description": "Presented Tara McKay, Assistant Professor of Medicine, Health, &; Society, and Assistant Professor of Health Policy. UK (2016) Dir. Ken Loach. Winner of the Palme d&#x2019;Or at the 2016 Cannes Film Festival, the film is a gripping, human tale about the impact one man can make. Gruff but goodhearted, Daniel Blake (Dave Johns) is a man out of time: a widowed woodworker who&#x2019;s never owned a computer, he lives according to his own common sense moral code. But after a heart attack leaves him unable to work and the state welfare system fails him, the stubbornly self-reliant Daniel must stand up and fight for his dignity, leading a one-man crusade for compassion that will transform the lives of a struggling single mother (Hayley Squires) and her two children. Graced with humor and heart, ;I, Daniel Blake ;is a moving, much-needed reminder of the power of empathy. English. Rated R. 100 min. Blu-ray "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-15",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>\"What good is sitting alone in your room? &nbsp;Come hear the music play...\" &nbsp;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation. &nbsp;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike. &nbsp;\"It's only a cabaret, old chum, and I love a cabaret.\"&nbsp;Directed by Christin Essin,&nbsp;Assistant Professor of Theatre.</p>\r\n<p>Performed&nbsp;April 13, 14, 15 at&nbsp;8pm.</p></div>",
        "title": "Cabaret Vanderbilt: Gender Play",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-15\">Saturday, April 15, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Neely Auditorium</span></div> <div class=\"description\"><p>\"What good is sitting alone in your room? &nbsp;Come hear the music play...\" &nbsp;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation. &nbsp;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike. &nbsp;\"It's only a cabaret, old chum, and I love a cabaret.\"&nbsp;Directed by Christin Essin,&nbsp;Assistant Professor of Theatre.</p>\r\n<p>Performed&nbsp;April 13, 14, 15 at&nbsp;8pm.</p></div>",
        "categories": [
            "Performing Arts",
            "GME - Diversity & Inclusion",
            "Greek Member Experience"
        ],
        "location": "Neely Auditorium",
        "description": "\";What good is sitting alone in your room?  ;Come hear the music play...\";  ;VUTheatre presents an original performance inspired by early twentieth century European cabaret culture, a playfully irreverent and experimental variety show that invites audiences into a world where gender is fluid and open for interpretation.  ;Actors, singers, dancers, and, of course, a mysterious master of ceremonies will use the stage as a playground for constructing identity, exploring and shattering stereotypes, charming and alarming old and young alike.  ;\";It';s only a cabaret, old chum, and I love a cabaret.\"; ;Directed by Christin Essin, ;Assistant Professor of Theatre. Performed ;April 13, 14, 15 at ;8pm. "
    },
    {
        "time": "11:00:00",
        "date": "2017-04-16",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-16\">Sunday, April 16, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "title": "Cereal Sundays",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-16\">Sunday, April 16, 2017</span> (<span\tclass=\"value\"\ttitle=\"11:00:00\">11:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"14:00:00\">2:00 PM</span>)</b> <div>Location: <span class=\"location\">Moore College Faculty Director Apartment (Smith 502)</span></div> <div class=\"description\"><p>Stop by Dr. L's apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out!</p></div>",
        "categories": [],
        "location": "Moore College Faculty Director Apartment (Smith 502)",
        "description": "Stop by Dr. L';s apartment on Sunday mornings from 11:00am to 2:00pm to get some breakfast cereal and hang out! "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-16",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-16\">Sunday, April 16, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "title": "Sutherland Social",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-16\">Sunday, April 16, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sutherland House</span></div> <div class=\"description\"><p>Come fellowship with Sutherland residents with food and fun!</p></div>",
        "categories": [
            "The Ingram Commons"
        ],
        "location": "Sutherland House",
        "description": "Come fellowship with Sutherland residents with food and fun! "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-17",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">SLC LL Rooms 1, 2</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend a&nbsp;<strong>Curricular Practical Training (CPT)</strong>&nbsp;workshop and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n</ul>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT workshop will now be <u>required</u> before applying for employment authorization. </strong><strong><em>Spots are limited!</em></strong></p></div>",
        "title": "CPT Workshop",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">SLC LL Rooms 1, 2</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend a&nbsp;<strong>Curricular Practical Training (CPT)</strong>&nbsp;workshop and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n</ul>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT workshop will now be <u>required</u> before applying for employment authorization. </strong><strong><em>Spots are limited!</em></strong></p></div>",
        "categories": [
            "Career Development",
            "International"
        ],
        "location": "SLC LL Rooms 1, 2",
        "description": "F-1 Students interested to work off campus, attend a CPT workshop!!! Have you ever thought about working off campus or interning for a company in the United States? Attend a ;Curricular Practical Training (CPT) ;workshop and get the facts about how to apply for employment authorization. ---CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment. ;  Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States? These are examples of some of the information you will learn by attending one of the CPT workshops this fall. ; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States. ; CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&#x2019;s, master&#x2019;s, doctoral). ; If you have an interest to work off campus, please sign up for the Spring ;workshops. ;Attendance at a CPT workshop will now be required before applying for employment authorization. Spots are limited! "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-17",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">407 A-D Light Hall</span></div> <div class=\"description\"><p>-</p></div>",
        "title": "April CCO Meeting",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">407 A-D Light Hall</span></div> <div class=\"description\"><p>-</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "407 A-D Light Hall",
        "description": "- "
    },
    {
        "time": "14:00:00",
        "date": "2017-04-17",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"14:00:00\">2:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"15:00:00\">3:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-17",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall Reading Room</span></div> <div class=\"description\"><p>&nbsp;Ready to connect across lines of difference? Join the Office of Equity, Diversity and Inclusion for a dinner with students who desire to connect and share with folks who wouldn&rsquo;t otherwise have a chance to meet, in order to expand our circles of care and understanding. Share moments, recent and long passed, in which you were made to feel unwelcome or unworthy as well as reflect on moments of comfort and solidarity. We welcome everyone to be whomever they authentically are, in their bodies and identities, and to share their America, at its best rather than its worst. &nbsp;</p></div>",
        "title": "#100Days100Dinners: Where Do We Go From Here?",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"20:00:00\">8:00 PM</span>)</b> <div>Location: <span class=\"location\">Alumni Hall Reading Room</span></div> <div class=\"description\"><p>&nbsp;Ready to connect across lines of difference? Join the Office of Equity, Diversity and Inclusion for a dinner with students who desire to connect and share with folks who wouldn&rsquo;t otherwise have a chance to meet, in order to expand our circles of care and understanding. Share moments, recent and long passed, in which you were made to feel unwelcome or unworthy as well as reflect on moments of comfort and solidarity. We welcome everyone to be whomever they authentically are, in their bodies and identities, and to share their America, at its best rather than its worst. &nbsp;</p></div>",
        "categories": [
            "Health & Wellness",
            "Diversity & Inclusion"
        ],
        "location": "Alumni Hall Reading Room",
        "description": " ;Ready to connect across lines of difference? Join the Office of Equity, Diversity and Inclusion for a dinner with students who desire to connect and share with folks who wouldn&#x2019;t otherwise have a chance to meet, in order to expand our circles of care and understanding. Share moments, recent and long passed, in which you were made to feel unwelcome or unworthy as well as reflect on moments of comfort and solidarity. We welcome everyone to be whomever they authentically are, in their bodies and identities, and to share their America, at its best rather than its worst.  ; "
    },
    {
        "time": "20:00:00",
        "date": "2017-04-17",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Join the women of Voce a Cappella for their spring concert! In Voce we love to sing and enjoy being able to share that with the Vanderbilt community. At our concert this semester,&nbsp;we'll perform songs by&nbsp;Wrabel, HAIM, Marren Morris, Ariana Grande, and many more! The concert will take place in Sarratt Cinema and admission will be free. Join us in for some great music performed entirely a cappella, free chick-fil-a, and GME credit (Campus Involvement). We hope to see you there!</p>\r\n<p>&nbsp;</p></div>",
        "title": "Voce A Cappella Spring Concert",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-17\">Monday, April 17, 2017</span> (<span\tclass=\"value\"\ttitle=\"20:00:00\">8:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Sarratt Cinema</span></div> <div class=\"description\"><p>Join the women of Voce a Cappella for their spring concert! In Voce we love to sing and enjoy being able to share that with the Vanderbilt community. At our concert this semester,&nbsp;we'll perform songs by&nbsp;Wrabel, HAIM, Marren Morris, Ariana Grande, and many more! The concert will take place in Sarratt Cinema and admission will be free. Join us in for some great music performed entirely a cappella, free chick-fil-a, and GME credit (Campus Involvement). We hope to see you there!</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Performing Arts"
        ],
        "location": "Sarratt Cinema",
        "description": "Join the women of Voce a Cappella for their spring concert! In Voce we love to sing and enjoy being able to share that with the Vanderbilt community. At our concert this semester, ;we';ll perform songs by ;Wrabel, HAIM, Marren Morris, Ariana Grande, and many more! The concert will take place in Sarratt Cinema and admission will be free. Join us in for some great music performed entirely a cappella, free chick-fil-a, and GME credit (Campus Involvement). We hope to see you there!  ; "
    },
    {
        "time": "09:00:00",
        "date": "2017-04-18",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">SLC LL Room 1, 2</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend <strong>Curricular Practical Training (CPT)</strong>&nbsp;and/or <strong>Optional Practical Training (OPT)</strong> workshops and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n<li>OPT is a 12-month employment authorization, related to a student&rsquo;s field of study, that can be used during or after academic studies are complete.</li>\r\n</ul>\r\n<p><em>Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services?</em></p>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT and/or OPT workshop will now be <u>required</u> before applying for employment authorization.&nbsp;</strong><strong><em>Spots are limited!</em></strong></p></div>",
        "title": "OPT Workshop",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:00:00\">9:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"10:30:00\">10:30 AM</span>)</b> <div>Location: <span class=\"location\">SLC LL Room 1, 2</span></div> <div class=\"description\"><p><strong>F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!!</strong></p>\r\n<p>Have you ever thought about working off campus or interning for a company in the United States?</p>\r\n<p>Attend <strong>Curricular Practical Training (CPT)</strong>&nbsp;and/or <strong>Optional Practical Training (OPT)</strong> workshops and get the facts about how to apply for employment authorization.</p>\r\n<ul>\r\n<li>CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment.&nbsp;</li>\r\n<li>OPT is a 12-month employment authorization, related to a student&rsquo;s field of study, that can be used during or after academic studies are complete.</li>\r\n</ul>\r\n<p><em>Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services?</em></p>\r\n<p><em>Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States?</em></p>\r\n<p>These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall.&nbsp; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States.&nbsp;</p>\r\n<p><em>CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&rsquo;s, master&rsquo;s, doctoral).&nbsp;</em></p>\r\n<p><strong>If you have an interest to work off campus, please sign up for the Spring&nbsp;workshops.&nbsp;Attendance at a CPT and/or OPT workshop will now be <u>required</u> before applying for employment authorization.&nbsp;</strong><strong><em>Spots are limited!</em></strong></p></div>",
        "categories": [
            "Career Development",
            "International"
        ],
        "location": "SLC LL Room 1, 2",
        "description": "F-1 Students interested to work off campus, attend a CPT and/or OPT workshop!!! Have you ever thought about working off campus or interning for a company in the United States? Attend Curricular Practical Training (CPT) ;and/or Optional Practical Training (OPT) workshops and get the facts about how to apply for employment authorization. ---CPT is an academic experience which allows students to apply knowledge gained through coursework during their academic program in a work environment. ;  ---OPT is a 12-month employment authorization, related to a student&#x2019;s field of study, that can be used during or after academic studies are complete.  Did you know that it takes more than 90 days for an OPT application to be approved by the United States Customs and Immigration Services? Did you know that CPT employment counts all days including weekends, holidays, and travel outside the United States? These are examples of some of the information you will learn by attending one of the OPT or CPT workshops this fall. ; If you are an F-1 student, you have the option to apply for employment authorization to be used during or after your academic studies in the United States. ; CPT and OPT are only for students who have a declared major in a degree-seeking program (bachelor&#x2019;s, master&#x2019;s, doctoral). ; If you have an interest to work off campus, please sign up for the Spring ;workshops. ;Attendance at a CPT and/or OPT workshop will now be required before applying for employment authorization. ;Spots are limited! "
    },
    {
        "time": "10:00:00",
        "date": "2017-04-18",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "title": "Gentle Yoga",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"10:00:00\">10:00 AM</span></span> - <span class=\"dtend\"\ttitle=\"11:00:00\">11:00 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a gentle yoga session.&nbsp;&nbsp;Yoga practice&nbsp;is a&nbsp;helpful tool to build resiliency, gain flexibility,&nbsp;and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a gentle yoga session. ; ;Yoga practice ;is a ;helpful tool to build resiliency, gain flexibility, ;and reduce stress. "
    },
    {
        "time": "13:00:00",
        "date": "2017-04-18",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "title": "Guided Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"13:00:00\">1:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:30:00\">1:30 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for a guided meditation practice. &nbsp;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.&nbsp;</p></div>",
        "categories": [
            "GME - Healthy Behaviors",
            "Greek Member Experience",
            "Health & Wellness"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for a guided meditation practice.  ;This meditation is led, with a focus toward managing negative and anxious thoughts. With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. ; "
    },
    {
        "time": "16:00:00",
        "date": "2017-04-18",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:00:00\">4:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">201 Alumni Hall</span></div> <div class=\"description\"><p>Vanderbilt Women in Science and Engineering</p>\r\n<p><strong>Elevator </strong><strong>Talk </strong><strong>Salon</strong></p>\r\n<p><strong>April 18, 2017</strong></p>\r\n<p><strong>4-6 PM</strong></p>\r\n<p><strong>Alumni Hall 201</strong></p>\r\n<p><u>4-5 PM </u>Elevator Talk presentations</p>\r\n<p><u>5-6 PM </u>Reception &ndash; Meet and Mingle</p>\r\n<p><strong>Come meet VU-WiSE members and </strong><strong>learn about the work </strong><strong>women are doing in Vanderbilt STEM</strong></p>\r\n<p>&nbsp;</p></div>",
        "title": "2017 Elevator Salon",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"16:00:00\">4:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"18:00:00\">6:00 PM</span>)</b> <div>Location: <span class=\"location\">201 Alumni Hall</span></div> <div class=\"description\"><p>Vanderbilt Women in Science and Engineering</p>\r\n<p><strong>Elevator </strong><strong>Talk </strong><strong>Salon</strong></p>\r\n<p><strong>April 18, 2017</strong></p>\r\n<p><strong>4-6 PM</strong></p>\r\n<p><strong>Alumni Hall 201</strong></p>\r\n<p><u>4-5 PM </u>Elevator Talk presentations</p>\r\n<p><u>5-6 PM </u>Reception &ndash; Meet and Mingle</p>\r\n<p><strong>Come meet VU-WiSE members and </strong><strong>learn about the work </strong><strong>women are doing in Vanderbilt STEM</strong></p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "Career Development"
        ],
        "location": "201 Alumni Hall",
        "description": "Vanderbilt Women in Science and Engineering Elevator Talk Salon April 18, 2017 4-6 PM Alumni Hall 201 4-5 PM Elevator Talk presentations 5-6 PM Reception &#x2013; Meet and Mingle Come meet VU-WiSE members and learn about the work women are doing in Vanderbilt STEM  ; "
    },
    {
        "time": "18:00:00",
        "date": "2017-04-18",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "title": "Vandy Wesley Weekly Dinner and Community",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-18\">Tuesday, April 18, 2017</span> (<span\tclass=\"value\"\ttitle=\"18:00:00\">6:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"19:00:00\">7:00 PM</span>)</b> <div>Location: <span class=\"location\">Div School Reading Room (through the courtyard next to Benton Chapel)</span></div> <div class=\"description\"><p>Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond. &nbsp;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community. &nbsp;</p>\r\n<p>All are welcome!!</p></div>",
        "categories": [
            "Health & Wellness",
            "Religious/Spiritual"
        ],
        "location": "Div School Reading Room (through the courtyard next to Benton Chapel)",
        "description": "Vandy Wesley is a community on a spiritual journey to make an impact on Vanderbilt, middle TN and beyond.  ;Each week we meet for delicious dinner catered by the cookery, discussion, time for reflection, singing hymns/worship songs, and building community.  ; All are welcome!! "
    },
    {
        "time": "09:15:00",
        "date": "2017-04-19",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "title": "Silent Meditation",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"09:15:00\">9:15 AM</span></span> - <span class=\"dtend\"\ttitle=\"09:45:00\">9:45 AM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Join us in the Center for Student Wellbeing for silent meditation practice.&nbsp; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Join us in the Center for Student Wellbeing for silent meditation practice. ; With practice, meditation helps to quiet the mind, build resiliency, and reduce stress. "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-19",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">202 Light Hall</span></div> <div class=\"description\"><p style=\"text-align: center;\">David Conklin, MD</p>\r\n<p style=\"text-align: center;\">Bedside Matters is a relatively new venture for VUMC. &nbsp;This is a forum that is intended to be for you, the front line workers, to help you deal with some of the difficult personal and emotional issues that arise in caring for patients. &nbsp;We hope that it will lead to strengthened relationships between patients and care givers and that it will help to preserve the human connection in healthcare. &nbsp;<br /><br />We meet in Light Hall, from 12-1. The meetings are scheduled monthly on the third Wednesday. &nbsp;Since we are meeting at this hour, feel free to bring a brown bag lunch. CME credits are available by signing up on the sign in sheets at the live event. &nbsp;CEU&rsquo;s are available as well.&nbsp;<br /><br />Bedside Matters is an outgrowth of the Schwartz Rounds, formerly held monthly in the Oncology Center. Drs. Malcolm Arnold and Barbara Murphy and social worker Cindy Tinker have for many years supported that effort, and are to be commended for it. &nbsp;They have graciously agreed that it could be renamed and repurposed so that all of VUMC might be able to participate in it. &nbsp;We have programs that include discussion of patients and situations arising from many areas of VUMC, including VUH, the clinics, and Children&rsquo;s Hospital and the Psychiatric Hospital. &nbsp;If any of you have an interest in participating in the planning of future meetings please contact me, and we will be glad to include you.&nbsp;<br /><br />What are we about here? We intend for these rounds to help focus our attention on the delivery of compassionate healthcare. Financial pressures and administrative demands mean that you have less time with patients, and the focus on timely treatment and shortened length of stay results in less time to discern the impact that illness can have on the patient and family. On top of that, many caregivers today are frustrated and anxious and under great pressure, with no structured outlet for expressing their feelings, or with little preparation for the difficult communication issues that are inevitably a part of patient care. &nbsp;These rounds offer a regularly scheduled time to discuss openly and honestly the social and emotional issues that arise in caring for patients and families. &nbsp;In contrast to the typical rounds the focus here is on the human dimensions of medicine. &nbsp;You, as care-givers, have an opportunity to share your experiences, thoughts, and feelings on thought-provoking topics drawn from actual patient cases. As a result of participating in Bedside Matters we believe that caregivers will be better equipped to form meaningful, personal connections with patients and colleagues, and they will have greater insights into their own responses and feelings.&nbsp;<br /><br />Usually a panel of 4 or 5 people each present an aspect of the case from their point of view. &nbsp;After the presentations by the panelists we will open it up to questions and comments from the audience. &nbsp;Please be respectful of the comments expressed by others. &nbsp;Be open-minded and fully present for the discussion. &nbsp;Be honest and express whatever is on your mind. Listen to where others are coming from and what they are saying. Be willing to hear an opinion that is different from your own. And finally, what is said in the room, stays in the room. Maintain a focus on improving your own performance and that of the organization and the work of your team.&nbsp;</p></div>",
        "title": "Bedside Matters - Searching for Empathy with Hateful Patients",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">202 Light Hall</span></div> <div class=\"description\"><p style=\"text-align: center;\">David Conklin, MD</p>\r\n<p style=\"text-align: center;\">Bedside Matters is a relatively new venture for VUMC. &nbsp;This is a forum that is intended to be for you, the front line workers, to help you deal with some of the difficult personal and emotional issues that arise in caring for patients. &nbsp;We hope that it will lead to strengthened relationships between patients and care givers and that it will help to preserve the human connection in healthcare. &nbsp;<br /><br />We meet in Light Hall, from 12-1. The meetings are scheduled monthly on the third Wednesday. &nbsp;Since we are meeting at this hour, feel free to bring a brown bag lunch. CME credits are available by signing up on the sign in sheets at the live event. &nbsp;CEU&rsquo;s are available as well.&nbsp;<br /><br />Bedside Matters is an outgrowth of the Schwartz Rounds, formerly held monthly in the Oncology Center. Drs. Malcolm Arnold and Barbara Murphy and social worker Cindy Tinker have for many years supported that effort, and are to be commended for it. &nbsp;They have graciously agreed that it could be renamed and repurposed so that all of VUMC might be able to participate in it. &nbsp;We have programs that include discussion of patients and situations arising from many areas of VUMC, including VUH, the clinics, and Children&rsquo;s Hospital and the Psychiatric Hospital. &nbsp;If any of you have an interest in participating in the planning of future meetings please contact me, and we will be glad to include you.&nbsp;<br /><br />What are we about here? We intend for these rounds to help focus our attention on the delivery of compassionate healthcare. Financial pressures and administrative demands mean that you have less time with patients, and the focus on timely treatment and shortened length of stay results in less time to discern the impact that illness can have on the patient and family. On top of that, many caregivers today are frustrated and anxious and under great pressure, with no structured outlet for expressing their feelings, or with little preparation for the difficult communication issues that are inevitably a part of patient care. &nbsp;These rounds offer a regularly scheduled time to discuss openly and honestly the social and emotional issues that arise in caring for patients and families. &nbsp;In contrast to the typical rounds the focus here is on the human dimensions of medicine. &nbsp;You, as care-givers, have an opportunity to share your experiences, thoughts, and feelings on thought-provoking topics drawn from actual patient cases. As a result of participating in Bedside Matters we believe that caregivers will be better equipped to form meaningful, personal connections with patients and colleagues, and they will have greater insights into their own responses and feelings.&nbsp;<br /><br />Usually a panel of 4 or 5 people each present an aspect of the case from their point of view. &nbsp;After the presentations by the panelists we will open it up to questions and comments from the audience. &nbsp;Please be respectful of the comments expressed by others. &nbsp;Be open-minded and fully present for the discussion. &nbsp;Be honest and express whatever is on your mind. Listen to where others are coming from and what they are saying. Be willing to hear an opinion that is different from your own. And finally, what is said in the room, stays in the room. Maintain a focus on improving your own performance and that of the organization and the work of your team.&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "202 Light Hall",
        "description": "David Conklin, MD Bedside Matters is a relatively new venture for VUMC.  ;This is a forum that is intended to be for you, the front line workers, to help you deal with some of the difficult personal and emotional issues that arise in caring for patients.  ;We hope that it will lead to strengthened relationships between patients and care givers and that it will help to preserve the human connection in healthcare.  ; We meet in Light Hall, from 12-1. The meetings are scheduled monthly on the third Wednesday.  ;Since we are meeting at this hour, feel free to bring a brown bag lunch. CME credits are available by signing up on the sign in sheets at the live event.  ;CEU&#x2019;s are available as well. ; Bedside Matters is an outgrowth of the Schwartz Rounds, formerly held monthly in the Oncology Center. Drs. Malcolm Arnold and Barbara Murphy and social worker Cindy Tinker have for many years supported that effort, and are to be commended for it.  ;They have graciously agreed that it could be renamed and repurposed so that all of VUMC might be able to participate in it.  ;We have programs that include discussion of patients and situations arising from many areas of VUMC, including VUH, the clinics, and Children&#x2019;s Hospital and the Psychiatric Hospital.  ;If any of you have an interest in participating in the planning of future meetings please contact me, and we will be glad to include you. ; What are we about here? We intend for these rounds to help focus our attention on the delivery of compassionate healthcare. Financial pressures and administrative demands mean that you have less time with patients, and the focus on timely treatment and shortened length of stay results in less time to discern the impact that illness can have on the patient and family. On top of that, many caregivers today are frustrated and anxious and under great pressure, with no structured outlet for expressing their feelings, or with little preparation for the difficult communication issues that are inevitably a part of patient care.  ;These rounds offer a regularly scheduled time to discuss openly and honestly the social and emotional issues that arise in caring for patients and families.  ;In contrast to the typical rounds the focus here is on the human dimensions of medicine.  ;You, as care-givers, have an opportunity to share your experiences, thoughts, and feelings on thought-provoking topics drawn from actual patient cases. As a result of participating in Bedside Matters we believe that caregivers will be better equipped to form meaningful, personal connections with patients and colleagues, and they will have greater insights into their own responses and feelings. ; Usually a panel of 4 or 5 people each present an aspect of the case from their point of view.  ;After the presentations by the panelists we will open it up to questions and comments from the audience.  ;Please be respectful of the comments expressed by others.  ;Be open-minded and fully present for the discussion.  ;Be honest and express whatever is on your mind. Listen to where others are coming from and what they are saying. Be willing to hear an opinion that is different from your own. And finally, what is said in the room, stays in the room. Maintain a focus on improving your own performance and that of the organization and the work of your team. ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-19",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Wond'ry</span></div> <div class=\"description\"><p>Please join us for the next installment in the VUSM Tech Talks series with Reed Omary, MD, MS, on Wednesday, April&nbsp;19th, (12 pm at the Wond'ry).</p>\r\n<p>&nbsp;</p>\r\n<p>From his website:</p>\r\n<p>Reed A. Omary, M.D., M.S., a practicing interventional radiologist, is Chairman of the Vanderbilt University Department of Radiology and Radiological Sciences.&nbsp;&nbsp; He has served in leadership roles within the American Cancer Society, the Society of Interventional Radiology (SIR), and the Radiological Society of North America. He was Chair of the SIR Foundation Grant Review Study Section from 2007-2011, and currently participates as a full member of the NIH Medical Imaging Study Section. As a principal investigator, Dr. Omary has received NIH funding for two separate R01 projects (one clinical, one pre-clinical) to develop image-guided therapies for hepatocellular carcinoma. He was previously vice-chair of research of the Northwestern University Department of Radiology. His arrival at Vanderbilt University in 2012 has helped promote the growth of interventional oncology across the clinical, research, and training missions of the medical center. Dr. Omary has been a co-investigator on several multi-institutional clinical trials for liver-directed therapies for hepatocellular and metastatic liver cancer. He has served as a principal or co-investigator on several training grants, including the NIH T32 Graduate Training Program for Magnetic Resonance Imaging and the NIH R25 Cancer Nanotechnology in Imaging and Radiotherapy. Dr. Omary is very proud of his trainees, who have collectively been awarded 35 national and 17 local research prizes.</p>\r\n<p>&nbsp;</p></div>",
        "title": "Spring 2017 Tech Talk: Reed Omary, MD, MS",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">Wond'ry</span></div> <div class=\"description\"><p>Please join us for the next installment in the VUSM Tech Talks series with Reed Omary, MD, MS, on Wednesday, April&nbsp;19th, (12 pm at the Wond'ry).</p>\r\n<p>&nbsp;</p>\r\n<p>From his website:</p>\r\n<p>Reed A. Omary, M.D., M.S., a practicing interventional radiologist, is Chairman of the Vanderbilt University Department of Radiology and Radiological Sciences.&nbsp;&nbsp; He has served in leadership roles within the American Cancer Society, the Society of Interventional Radiology (SIR), and the Radiological Society of North America. He was Chair of the SIR Foundation Grant Review Study Section from 2007-2011, and currently participates as a full member of the NIH Medical Imaging Study Section. As a principal investigator, Dr. Omary has received NIH funding for two separate R01 projects (one clinical, one pre-clinical) to develop image-guided therapies for hepatocellular carcinoma. He was previously vice-chair of research of the Northwestern University Department of Radiology. His arrival at Vanderbilt University in 2012 has helped promote the growth of interventional oncology across the clinical, research, and training missions of the medical center. Dr. Omary has been a co-investigator on several multi-institutional clinical trials for liver-directed therapies for hepatocellular and metastatic liver cancer. He has served as a principal or co-investigator on several training grants, including the NIH T32 Graduate Training Program for Magnetic Resonance Imaging and the NIH R25 Cancer Nanotechnology in Imaging and Radiotherapy. Dr. Omary is very proud of his trainees, who have collectively been awarded 35 national and 17 local research prizes.</p>\r\n<p>&nbsp;</p></div>",
        "categories": [
            "School of Medicine"
        ],
        "location": "Wond'ry",
        "description": "Please join us for the next installment in the VUSM Tech Talks series with Reed Omary, MD, MS, on Wednesday, April ;19th, (12 pm at the Wond';ry).  ; From his website: Reed A. Omary, M.D., M.S., a practicing interventional radiologist, is Chairman of the Vanderbilt University Department of Radiology and Radiological Sciences. ; ; He has served in leadership roles within the American Cancer Society, the Society of Interventional Radiology (SIR), and the Radiological Society of North America. He was Chair of the SIR Foundation Grant Review Study Section from 2007-2011, and currently participates as a full member of the NIH Medical Imaging Study Section. As a principal investigator, Dr. Omary has received NIH funding for two separate R01 projects (one clinical, one pre-clinical) to develop image-guided therapies for hepatocellular carcinoma. He was previously vice-chair of research of the Northwestern University Department of Radiology. His arrival at Vanderbilt University in 2012 has helped promote the growth of interventional oncology across the clinical, research, and training missions of the medical center. Dr. Omary has been a co-investigator on several multi-institutional clinical trials for liver-directed therapies for hepatocellular and metastatic liver cancer. He has served as a principal or co-investigator on several training grants, including the NIH T32 Graduate Training Program for Magnetic Resonance Imaging and the NIH R25 Cancer Nanotechnology in Imaging and Radiotherapy. Dr. Omary is very proud of his trainees, who have collectively been awarded 35 national and 17 local research prizes.  ; "
    },
    {
        "time": "12:00:00",
        "date": "2017-04-19",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">ESB</span></div> <div class=\"description\"><p>Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events</p></div>",
        "title": "M.E. Graduate Student Seminar",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"12:00:00\">12:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"13:00:00\">1:00 PM</span>)</b> <div>Location: <span class=\"location\">ESB</span></div> <div class=\"description\"><p>Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events</p></div>",
        "categories": [],
        "location": "ESB",
        "description": "Students are invited to practice presenting their current research to students in order to prepare for upcoming conferences and examinations. This also quickly disseminates research ideas throughout the student body to receive immediate feedback. Utilizing a student forum improves the awareness of fellow students as to the current research within the department. General body meetings follow these events "
    },
    {
        "time": "15:00:00",
        "date": "2017-04-19",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Cultivating Wellbeing focuses on the interdependent relationship of wellness dimensions that can ultimately lead students, over a period of time, to a consistently healthy lifestyle. Students will have the opportunity to explore social wellness, occupational wellness, intellectual wellness, emotional wellness, physical wellness, and spiritual wellness. Throughout the session, students will also self-reflect on how they currently cultivate habits of each of the wellness dimensions, and they will engage in an activity to see how <em>well </em>they are . Ultimately, students will become more aware of how they can nurture various relationships, become more accountable for financial decisions, recognize whether or not career ambitions are personally satisfying, face adversity and challenges head on, implement healthy exercise and dietary habits, improve sleep quality, and examine their values, ethics, and core beliefs.</p></div>",
        "title": "Cultivating Wellbeing",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"15:00:00\">3:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"16:00:00\">4:00 PM</span>)</b> <div>Location: <span class=\"location\">Center for Student Wellbeing</span></div> <div class=\"description\"><p>Cultivating Wellbeing focuses on the interdependent relationship of wellness dimensions that can ultimately lead students, over a period of time, to a consistently healthy lifestyle. Students will have the opportunity to explore social wellness, occupational wellness, intellectual wellness, emotional wellness, physical wellness, and spiritual wellness. Throughout the session, students will also self-reflect on how they currently cultivate habits of each of the wellness dimensions, and they will engage in an activity to see how <em>well </em>they are . Ultimately, students will become more aware of how they can nurture various relationships, become more accountable for financial decisions, recognize whether or not career ambitions are personally satisfying, face adversity and challenges head on, implement healthy exercise and dietary habits, improve sleep quality, and examine their values, ethics, and core beliefs.</p></div>",
        "categories": [
            "Greek Member Experience",
            "GME - Healthy Behaviors"
        ],
        "location": "Center for Student Wellbeing",
        "description": "Cultivating Wellbeing focuses on the interdependent relationship of wellness dimensions that can ultimately lead students, over a period of time, to a consistently healthy lifestyle. Students will have the opportunity to explore social wellness, occupational wellness, intellectual wellness, emotional wellness, physical wellness, and spiritual wellness. Throughout the session, students will also self-reflect on how they currently cultivate habits of each of the wellness dimensions, and they will engage in an activity to see how well they are . Ultimately, students will become more aware of how they can nurture various relationships, become more accountable for financial decisions, recognize whether or not career ambitions are personally satisfying, face adversity and challenges head on, implement healthy exercise and dietary habits, improve sleep quality, and examine their values, ethics, and core beliefs. "
    },
    {
        "time": "19:00:00",
        "date": "2017-04-19",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom A</span></div> <div class=\"description\"><p>Join us for a celebration of the achievements and contributions of lesbian, gay, bisexual, transgender, queer, intersex, asexual, and allied graduating students as well as current student leaders. Any graduating undergraduates and graduates (May &amp; December 2017) are welcome to fill out our form in order to be recognized during the ceremony. All students, staff members, and faculty are welcome to attend the program. Full dinner will be provided and business casual attire is suggested and not required.<br /><br />Form for graduates to be recognized during Lavender Celebration:<a href=\"/form/start/122528\" target=\"_blank\" rel=\"nofollow noopener\">https://anchorlink.vanderbilt.edu/form/start/122528</a>&nbsp;(via Anchorlink and can also be found on the LGBTQI Life anchorlink page under \"forms\").</p></div>",
        "title": "Lavender Celebration",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:00:00\">7:00 PM</span></span> - <span class=\"dtend\"\ttitle=\"21:00:00\">9:00 PM</span>)</b> <div>Location: <span class=\"location\">Student Life Center Ballroom A</span></div> <div class=\"description\"><p>Join us for a celebration of the achievements and contributions of lesbian, gay, bisexual, transgender, queer, intersex, asexual, and allied graduating students as well as current student leaders. Any graduating undergraduates and graduates (May &amp; December 2017) are welcome to fill out our form in order to be recognized during the ceremony. All students, staff members, and faculty are welcome to attend the program. Full dinner will be provided and business casual attire is suggested and not required.<br /><br />Form for graduates to be recognized during Lavender Celebration:<a href=\"/form/start/122528\" target=\"_blank\" rel=\"nofollow noopener\">https://anchorlink.vanderbilt.edu/form/start/122528</a>&nbsp;(via Anchorlink and can also be found on the LGBTQI Life anchorlink page under \"forms\").</p></div>",
        "categories": [
            "LGBTQI Life",
            "Diversity & Inclusion"
        ],
        "location": "Student Life Center Ballroom A",
        "description": "Join us for a celebration of the achievements and contributions of lesbian, gay, bisexual, transgender, queer, intersex, asexual, and allied graduating students as well as current student leaders. Any graduating undergraduates and graduates (May &; December 2017) are welcome to fill out our form in order to be recognized during the ceremony. All students, staff members, and faculty are welcome to attend the program. Full dinner will be provided and business casual attire is suggested and not required. Form for graduates to be recognized during Lavender Celebration: [https://anchorlink.vanderbilt.edu/form/start/122528] (/form/start/122528)  ;(via Anchorlink and can also be found on the LGBTQI Life anchorlink page under \";forms\";). "
    },
    {
        "time": "19:30:00",
        "date": "2017-04-19",
        "text": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Library Lawn</span></div> <div class=\"description\">Cancelled <br/><br/> <p>A \"feel good\" event going into finals! There will be a showing of Finding Nemo along with some food trucks. It is a way for students to de-stress going into finals.</p></div>",
        "title": "Feel Good at Finals (Cancelled)",
        "summary": "<b><span class=\"dtstart\"><span class=\"value\" title=\"2017-04-19\">Wednesday, April 19, 2017</span> (<span\tclass=\"value\"\ttitle=\"19:30:00\">7:30 PM</span></span> - <span class=\"dtend\"\ttitle=\"22:00:00\">10:00 PM</span>)</b> <div>Location: <span class=\"location\">Library Lawn</span></div> <div class=\"description\">Cancelled <br/><br/> <p>A \"feel good\" event going into finals! There will be a showing of Finding Nemo along with some food trucks. It is a way for students to de-stress going into finals.</p></div>",
        "categories": [
            "Film/Movie"
        ],
        "location": "Library Lawn",
        "description": "Cancelled  A \";feel good\"; event going into finals! There will be a showing of Finding Nemo along with some food trucks. It is a way for students to de-stress going into finals. "
    }
]