'use strict';
const phantomjsLambdaPack = require('phantomjs-lambda-pack');
const exec = phantomjsLambdaPack.exec;
 
exports.handler = (event, context, callback) => {
    exec('-v', (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return;
        }
 		
 		//Is phantom running?
        console.log(`phantom version: ${stdout}`);
        console.log(`Should have no error: ${stderr}`);


        //Should start horseman with the correct path
        console.log(phantomjsLambdaPack.path);
		var htmlstring;
		var horseman = new Horseman({phantomPath: phantomjsLambdaPack.path})

		horseman
		  .userAgent('Mozilla/5.0 (Windows NT 6.1; WOW64; rv:27.0) Gecko/20100101 Firefox/27.0');



 
        callback(error, 'done!');
    });
};